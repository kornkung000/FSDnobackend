# แก้ปัญหา "Failed to fetch" ใน Extension

## สาเหตุที่พบบ่อย

1. Backend ไม่ได้รันอยู่ (กรณี Extension ที่เรียก Backend)
2. URL/พอร์ตของ Backend ไม่ถูกต้อง หรือถูก block โดย Firewall/Antivirus
3. อินเทอร์เน็ตมีปัญหา หรือ API ภายนอกถูกจำกัด/ถูก block (กรณี Extension ที่เรียก API ภายนอก)

---

## วิธีแก้ไข

## กรณีใช้งานแบบเรียก Backend

### 1) รัน Backend Server

```powershell
cd FakeShopDetector/server
pip install -r requirements.txt
python app.py
```

### 2) ตรวจสอบว่า Backend รันอยู่

เปิดเบราว์เซอร์ไปที่: `http://127.0.0.1:5000/fsd/health`

ควรเห็น JSON สถานะออนไลน์ (ตัวอย่าง):
```json
{
  "status": "online",
  "service": "FSD - FakeShop Detector",
  "version": "1.0.0"
}
```

### 3) ตั้งค่า Extension

1. คลิกขวาที่ Extension → **Options**
2. ตั้งค่า **Backend URL** เป็น: `http://127.0.0.1:5000`
3. คลิก **Save**

### 4) Reload Extension

1. ไปที่ `chrome://extensions/` หรือ `edge://extensions/`
2. คลิกไอคอน **Reload** ที่ Extension
3. ลองใช้งาน Extension อีกครั้ง

---

## กรณีใช้งานแบบเรียก API ภายนอก

### 1) รอสักครู่แล้วลองใหม่

API ฟรีอาจมี rate limiting - รอ 1-2 นาทีแล้วลองใหม่

### 2) ตั้งค่า API Key (ถ้ามี)

1. เปิด Developer Console (F12)
2. ไปที่แท็บ **Console**
3. รันคำสั่ง:
   ```javascript
   chrome.storage.sync.set({
     whoisApiKey: 'YOUR_API_KEY_HERE'
   });
   ```

API ที่นิยม: whoisxmlapi.com (มี free tier)

### 3) ตรวจสอบการเชื่อมต่อ

1. ตรวจสอบว่ามีการเชื่อมต่ออินเทอร์เน็ต
2. ดู error ที่ Console (F12)
3. ตรวจสอบว่า Firewall/Antivirus ไม่ได้ block

## ตรวจสอบเพิ่มเติม (ถ้ายังไม่หาย)

- ดู error ที่ Console (F12)
- ถ้าเรียก Backend ให้ดู log ที่หน้าต่างที่รัน `python app.py`
- Reload Extension แล้วลองใหม่

---

## เอกสารเพิ่มเติม

- คู่มือการใช้งาน: `FakeShopDetector/extension/คู่มือการใช้งาน.md`
- Backend README: `FakeShopDetector/server/README.md`
- Extension README: `FakeShopDetector/extension/README.md`
