document.addEventListener('DOMContentLoaded', () => {
  const analyzeBtn = document.getElementById('analyzeBtn');
  const currentTabBtn = document.getElementById('currentTabBtn');
  const urlInput = document.getElementById('urlInput');
  const status = document.getElementById('status');
  const results = document.getElementById('results');
  const resultRisk = document.getElementById('resultRisk');
  const resultDetails = document.getElementById('resultDetails');

  let currentLanguage = 'th'; // Default language

  // Load language setting and update UI
  chrome.storage.sync.get(['language'], (items) => {
    if (items.language) {
      currentLanguage = items.language;
    }
    updateUILanguage(currentLanguage);
  });

  function updateUILanguage(lang) {
    document.getElementById('popupTitle').textContent = getText('popupTitle', lang);
    document.getElementById('urlLabel').textContent = getText('urlLabel', lang);
    urlInput.placeholder = getText('urlPlaceholder', lang);
    analyzeBtn.textContent = getText('analyzeButton', lang);
    currentTabBtn.textContent = getText('currentTabButton', lang);
    currentTabBtn.title = getText('currentTabTitle', lang);
    document.getElementById('resultsTitle').textContent = getText('resultsTitle', lang);
  }

  analyzeBtn.addEventListener('click', () => {
    const url = urlInput.value.trim();
    if (!url) {
      status.textContent = getText('urlRequired', currentLanguage);
      status.style.color = '#d9534f';
      return;
    }
    status.textContent = getText('analyzing', currentLanguage);
    status.style.color = '#5cb85c';
    results.style.display = 'none';
    chrome.runtime.sendMessage({ type: 'ANALYZE_URL', url }, (response) => {
      if (response && response.success) {
        const data = response.data;
        renderResult(data, currentLanguage);
        status.textContent = getText('analysisSuccess', currentLanguage);
        status.style.color = '#5cb85c';
      } else {
        const err = response && response.error ? response.error : getText('fetchError', currentLanguage);
        status.textContent = getText('analysisError', currentLanguage) + err;
        status.style.color = '#d9534f';
        status.style.whiteSpace = 'pre-line'; // ให้แสดง newline ได้
        status.style.fontSize = '0.85em';
      }
    });
  });

  currentTabBtn.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].url) {
        urlInput.value = tabs[0].url;
        status.textContent = getText('currentTabImported', currentLanguage);
        status.style.color = '#5cb85c';
      } else {
        status.textContent = getText('currentTabError', currentLanguage);
        status.style.color = '#d9534f';
      }
    });
  });

  function renderResult(data, lang) {
    results.style.display = 'block';

    // กำหนดสี badge ตามความเสี่ยง
    let badgeColor = '#5cb85c'; // safe
    if (data.verdict === 'warn') badgeColor = '#f0ad4e'; // warning
    if (data.verdict === 'danger') badgeColor = '#d9534f'; // danger

    resultRisk.innerHTML = `
      <div style="margin-bottom: 12px;">
        <span class="badge" style="background-color: ${badgeColor}; color: white; padding: 6px 12px; border-radius: 4px; font-weight: bold;">
          ${getText('riskScore', lang)} ${data.riskScore ?? 'N/A'}
        </span>
        <span class="badge" style="background-color: ${badgeColor}; color: white; padding: 6px 12px; border-radius: 4px; font-weight: bold;">
          ${getText('verdict', lang)} ${mapVerdict(data.verdict ?? 'N/A', lang)}
        </span>
      </div>
      <div style="font-size: 0.9em; color: #666;">
        <strong>${getText('domain', lang)}</strong> ${data.domain ?? 'N/A'}
      </div>
    `;

    resultDetails.innerHTML = `
      <div style="margin-top: 12px;">
        <strong>${getText('details', lang)}</strong>
        ${Array.isArray(data.details) && data.details.length > 0
          ? data.details.map(d => `<div style="margin: 4px 0; padding: 4px 8px; background: #f5f5f5; border-left: 3px solid ${badgeColor};">• ${d}</div>`).join('')
          : `<div style="color: #888; padding: 4px 8px;">${getText('noDetails', lang)}</div>`
        }
      </div>
    `;
  }

  function mapVerdict(verdict, lang) {
    const maps = {
      'th': {
        'safe': '✓ ปลอดภัย',
        'warn': '⚠ คำเตือน',
        'danger': '✗ อันตราย'
      },
      'en': {
        'safe': '✓ Safe',
        'warn': '⚠ Warning',
        'danger': '✗ Dangerous'
      }
    };
    return maps[lang]?.[verdict] || maps['th'][verdict] || verdict;
  }
});
