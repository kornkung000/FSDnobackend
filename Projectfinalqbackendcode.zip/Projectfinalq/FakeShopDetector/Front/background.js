// Backend configuration
const DEFAULT_BACKEND_BASE = "http://127.0.0.1:5000";

let backendBaseUrl = DEFAULT_BACKEND_BASE;
let apiKey = null;

// โหลดค่า settings ตอน startup
async function loadSettings() {
  try {
    const items = await chrome.storage?.sync.get(['backendBaseUrl', 'apiKey']);
    if (items?.backendBaseUrl) backendBaseUrl = items.backendBaseUrl;
    if (items?.apiKey) apiKey = items.apiKey;
    console.log('Settings loaded:', { backendBaseUrl });
  } catch (e) {
    console.error('Failed to load settings:', e);
  }
}
loadSettings();

// ฟังก์ชันตรวจสอบว่า backend รันอยู่หรือไม่
async function checkBackendHealth() {
  try {
    const healthUrl = backendBaseUrl.replace(/\/+$/, '') + '/health';
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 seconds timeout
    
    const res = await fetch(healthUrl, {
      method: 'GET',
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    return res.ok;
  } catch (e) {
    return false;
  }
}

// ฟังก์ชันเรียก backend
async function analyzeUrl(url) {
  try {
    // ตรวจสอบว่า backend รันอยู่หรือไม่
    const isBackendOnline = await checkBackendHealth();
    if (!isBackendOnline) {
      throw new Error(`Backend server ไม่ได้รันอยู่\n\nกรุณา:\n1. รัน backend server ด้วยคำสั่ง: python app.py\n2. ตรวจสอบว่า backend URL ถูกต้อง: ${backendBaseUrl}\n3. ตรวจสอบว่า backend รันที่ port 5000`);
    }

    const endpoint = backendBaseUrl.replace(/\/+$/, '') + '/api/analyze';
    const payload = { url };

    const headers = {
      'Content-Type': 'application/json'
    };
    if (apiKey) {
      headers['Authorization'] = 'Bearer ' + apiKey;
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 seconds timeout
    
    const res = await fetch(endpoint, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Backend error: ${res.status} ${text}`);
    }

    const data = await res.json();
    return data;
  } catch (err) {
    // แสดง error message ที่ชัดเจนขึ้น
    if (err.message.includes('Failed to fetch') || err.message.includes('NetworkError')) {
      throw new Error(`ไม่สามารถเชื่อมต่อกับ backend server ได้\n\nสาเหตุที่เป็นไปได้:\n• Backend server ไม่ได้รันอยู่\n• URL ไม่ถูกต้อง: ${backendBaseUrl}\n• Firewall หรือ antivirus block การเชื่อมต่อ\n\nวิธีแก้ไข:\n1. ตรวจสอบว่า backend server รันอยู่ (ดูที่ terminal)\n2. ตรวจสอบ backend URL ใน Settings\n3. ตรวจสอบ firewall/antivirus settings`);
    }
    throw err;
  }
}

// รับ message จาก popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'ANALYZE_URL') {
    analyzeUrl(message.url)
      .then((data) => {
        sendResponse({ success: true, data });
      })
      .catch((err) => {
        sendResponse({ success: false, error: err?.message ?? 'Unknown error' });
      });
    return true;
  }
});

// ตรวจสอบการเปลี่ยนแปลง settings
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'sync' && changes.backendBaseUrl) {
    backendBaseUrl = changes.backendBaseUrl.newValue || DEFAULT_BACKEND_BASE;
    console.log('Backend URL updated:', backendBaseUrl);
  }
});
