// Language translations for SafeURL Checker extension
const languages = {
  th: {
    // Options page
    optionsTitle: "⚙️ ตั้งค่า SafeURL Checker",
    backendUrlLabel: "🔗 Backend Server URL",
    backendUrlPlaceholder: "http://127.0.0.1:5000",
    apiKeyLabel: "🔑 API Key (ถ้ามี)",
    apiKeyPlaceholder: "ปล่อยไว้ว่างถ้าไม่มี API Key",
    languageLabel: "🌐 ภาษา / Language",
    saveButton: "💾 บันทึกตั้งค่า",
    saveSuccess: "✓ บันทึกตั้งค่าสำเร็จ",
    saveError: "⚠️ กรุณากรอก Backend URL",
    instructionsTitle: "ℹ️ คำแนะนำ:",
    instruction1: "1. ตั้ง Backend URL เป็น <code style=\"background: #fff; padding: 2px 4px; border-radius: 2px;\">http://127.0.0.1:5000</code> ถ้า Server ทำงานในเครื่องเดียวกัน",
    instruction2: "2. API Key เป็นทางเลือก ใช้ถ้า Server ต้องการตรวจสอบสิทธิ์",

    // Popup page
    popupTitle: "🔒 SafeURL Checker",
    urlLabel: "URL ที่จะวิเคราะห์",
    urlPlaceholder: "https://example.com",
    analyzeButton: "วิเคราะห์",
    currentTabButton: "🔗 URL ปัจจุบัน",
    currentTabTitle: "ใช้ URL ของแท็บปัจจุบัน",
    analyzing: "กำลังวิเคราะห์...",
    analysisSuccess: "วิเคราะห์สำเร็จ ✓",
    analysisError: "เกิดข้อผิดพลาด: ",
    urlRequired: "กรุณากรอก URL ที่จะวิเคราะห์",
    currentTabImported: "นำเข้า URL ของแท็บปัจจุบัน",
    currentTabError: "ไม่พบ URL ในแท็บปัจจุบัน",
    fetchError: "ไม่สามารถวิเคราะห์ข้อมูลได้",

    // Results
    resultsTitle: "📊 ผลการวิเคราะห์",
    riskScore: "Risk Score:",
    verdict: "Verdict:",
    domain: "Domain:",
    details: "รายละเอียด:",
    noDetails: "ไม่มีรายละเอียด",
    safe: "✓ ปลอดภัย",
    warning: "⚠ คำเตือน",
    danger: "✗ อันตราย"
  },
  en: {
    // Options page
    optionsTitle: "⚙️ SafeURL Checker Settings",
    backendUrlLabel: "🔗 Backend Server URL",
    backendUrlPlaceholder: "http://127.0.0.1:5000",
    apiKeyLabel: "🔑 API Key (if any)",
    apiKeyPlaceholder: "Leave empty if no API Key",
    languageLabel: "🌐 Language / ภาษา",
    saveButton: "💾 Save Settings",
    saveSuccess: "✓ Settings saved successfully",
    saveError: "⚠️ Please enter Backend URL",
    instructionsTitle: "ℹ️ Instructions:",
    instruction1: "1. Set Backend URL to <code style=\"background: #fff; padding: 2px 4px; border-radius: 2px;\">http://127.0.0.1:5000</code> if Server runs on the same machine",
    instruction2: "2. API Key is optional, use if Server requires authentication",

    // Popup page
    popupTitle: "🔒 SafeURL Checker",
    urlLabel: "URL to analyze",
    urlPlaceholder: "https://example.com",
    analyzeButton: "Analyze",
    currentTabButton: "🔗 Current URL",
    currentTabTitle: "Use current tab URL",
    analyzing: "Analyzing...",
    analysisSuccess: "Analysis completed ✓",
    analysisError: "Error occurred: ",
    urlRequired: "Please enter URL to analyze",
    currentTabImported: "Current tab URL imported",
    currentTabError: "No URL found in current tab",
    fetchError: "Unable to analyze data",

    // Results
    resultsTitle: "📊 Analysis Results",
    riskScore: "Risk Score:",
    verdict: "Verdict:",
    domain: "Domain:",
    details: "Details:",
    noDetails: "No details available",
    safe: "✓ Safe",
    warning: "⚠ Warning",
    danger: "✗ Dangerous"
  }
};

// Function to get current language setting
function getCurrentLanguage(callback) {
  chrome.storage.sync.get(['language'], (items) => {
    const lang = items.language || 'th'; // Default to Thai
    callback(lang);
  });
}

// Function to set language
function setLanguage(lang, callback) {
  chrome.storage.sync.set({ language: lang }, callback);
}

// Function to get translated text
function getText(key, lang) {
  return languages[lang]?.[key] || languages['th'][key] || key;
}

function getTextSync(key) {
  const lang = localStorage.getItem('extension_language') || 'th';
  return getText(key, lang);
}