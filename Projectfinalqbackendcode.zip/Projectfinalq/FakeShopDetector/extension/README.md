# FakeShop Detector Extension (Online Version)

Extension สำหรับตรวจสอบความน่าเชื่อถือของร้านค้าออนไลน์ **ทำงานแบบ online โดยไม่ต้องใช้ local server**

## ✨ ฟีเจอร์

- ✅ **ทำงานแบบ Online** - ไม่ต้องรัน backend server
- ✅ **ตรวจสอบอัตโนมัติ** - ตรวจสอบทันทีเมื่อเปิด popup
- ✅ **ใช้ API หลายตัว** - มี fallback หลายชั้น
- ✅ **ตรวจสอบหลายมิติ**:
  - อายุโดเมน (ผ่าน whois API)
  - SSL Certificate
  - รูปแบบโดเมนที่น่าสงสัย
  - Domain reputation
  - ความยาวโดเมน
  - Subdomain ผิดปกติ

## 📦 การติดตั้ง

1. เปิด Chrome/Edge และไปที่:
   - Chrome: `chrome://extensions/`
   - Edge: `edge://extensions/`

2. เปิด **"Developer mode"** (มุมขวาบน)

3. คลิก **"Load unpacked"**

4. เลือกโฟลเดอร์ `extension`

5. Extension จะถูกติดตั้งและพร้อมใช้งาน

## 🚀 วิธีใช้งาน

1. เปิดเว็บไซต์ที่ต้องการตรวจสอบ
2. คลิกที่ไอคอน Extension ในแถบเครื่องมือ
3. Extension จะตรวจสอบอัตโนมัติและแสดงผลลัพธ์

## 🔧 API ที่ใช้

Extension ใช้ API หลายตัวเพื่อความแม่นยำ:

1. **whoisxmlapi.com** - ตรวจสอบอายุโดเมน (demo key - จำกัด)
2. **ip-api.com** - ตรวจสอบข้อมูล IP
3. **ipwhois.io** - ตรวจสอบข้อมูล whois
4. **Cloudflare DNS** - ตรวจสอบ DNS records

## ⚙️ การตั้งค่า API Key (Optional)

สำหรับความแม่นยำมากขึ้น สามารถตั้งค่า API key ได้:

1. เปิด Developer Tools (F12)
2. ไปที่ Console
3. รันคำสั่ง:
   ```javascript
   chrome.storage.sync.set({whoisApiKey: 'YOUR_API_KEY'});
   ```

**API ที่รองรับ:**
- whoisxmlapi.com (มี free tier)

## 📊 คะแนนความน่าเชื่อถือ

- **80-100**: ปลอดภัย ✅
- **50-79**: ควรระวัง ⚠️
- **0-49**: เสี่ยงมาก ⛔

## 🛠️ การพัฒนา

### โครงสร้างไฟล์:
```
extension/
├── manifest.json      # Extension configuration
├── popup.html         # UI ของ popup
├── popup.js           # Logic การตรวจสอบ
├── icon.svg           # ไอคอน
└── README.md          # เอกสารนี้
```

### เพิ่ม API ใหม่:

แก้ไขไฟล์ `popup.js` ในฟังก์ชัน `checkDomainAge()` เพื่อเพิ่ม API ใหม่

## ⚠️ หมายเหตุ

- Extension ใช้ API ฟรีที่มีข้อจำกัด
- สำหรับการใช้งานจริง แนะนำให้ใช้ API key
- บาง API อาจมี rate limiting
- Extension ทำงานได้โดยไม่ต้องติดตั้ง backend server

## 📝 License

MIT License
