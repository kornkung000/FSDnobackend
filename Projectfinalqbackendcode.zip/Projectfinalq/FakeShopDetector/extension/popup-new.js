// Backend URL (จะโหลดจาก storage)
let backendUrl = 'http://127.0.0.1:5000';

// โหลด backend URL จาก storage
chrome.storage.sync.get(['backendUrl'], (items) => {
    if (items.backendUrl) {
        backendUrl = items.backendUrl;
    }
});

// ดึง URL หน้าปัจจุบันและตรวจสอบ
document.addEventListener('DOMContentLoaded', function() {
    const checkBtn = document.getElementById('checkBtn');
    const loading = document.getElementById('loading');
    const result = document.getElementById('result');
    const error = document.getElementById('error');
    const currentDomainEl = document.getElementById('currentDomain');

    // ดึง URL หน้าปัจจุบัน
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs[0]) {
            const currentUrl = tabs[0].url;
            const domain = extractDomain(currentUrl);
            currentDomainEl.textContent = domain || currentUrl;

            // ตรวจสอบอัตโนมัติเมื่อเปิด popup
            checkUrlWithBackend(currentUrl);
        } else {
            currentDomainEl.textContent = 'ไม่พบ URL';
            error.textContent = 'ไม่สามารถเข้าถึง URL ของหน้านี้ได้';
            error.style.display = 'block';
        }
    });

    // เมื่อกดปุ่มตรวจสอบ
    checkBtn.addEventListener('click', function() {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if (tabs[0]) {
                const currentUrl = tabs[0].url;
                checkUrlWithBackend(currentUrl);
            }
        });
    });
});

// แยกโดเมนออกจาก URL
function extractDomain(url) {
    try {
        const urlObj = new URL(url);
        return urlObj.hostname.replace('www.', '');
    } catch (e) {
        // ถ้าไม่ใช่ URL ที่สมบูรณ์ ให้ลองแยกเอง
        return url.replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0].split('?')[0];
    }
}

// ฟังก์ชันตรวจสอบ URL ด้วย Backend
async function checkUrlWithBackend(url) {
    const checkBtn = document.getElementById('checkBtn');
    const loading = document.getElementById('loading');
    const result = document.getElementById('result');
    const error = document.getElementById('error');

    // ซ่อนผลลัพธ์เก่า
    result.style.display = 'none';
    error.style.display = 'none';

    // แสดง loading
    loading.style.display = 'block';
    checkBtn.disabled = true;

    try {
        // ตรวจสอบว่า backend รันอยู่หรือไม่
        const isBackendOnline = await checkBackendHealth();
        if (!isBackendOnline) {
            throw new Error(`Backend server ไม่ได้รันอยู่\n\nกรุณา:\n1. รัน backend server ด้วยคำสั่ง: python app.py\n2. ตรวจสอบว่า backend URL ถูกต้อง: ${backendUrl}\n3. ตรวจสอบว่า backend รันที่ port 5000\n\nหรือตั้งค่า backend URL ใน Options`);
        }

        // ส่ง URL ไปให้ backend วิเคราะห์
        const endpoint = backendUrl.replace(/\/+$/, '') + '/fsd/api/check';
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ url: url })
        });

        if (!response.ok) {
            const text = await response.text();
            throw new Error(`Backend error: ${response.status} ${text}`);
        }

        const data = await response.json();

        // แสดงผลลัพธ์จาก backend
        displayBackendResult(data);

    } catch (err) {
        console.error('Error checking URL with backend:', err);

        // แสดง error message ที่ชัดเจนขึ้น
        let errorMessage = 'เกิดข้อผิดพลาด: ';
        if (err.message.includes('Failed to fetch') || err.message.includes('NetworkError')) {
            errorMessage += 'ไม่สามารถเชื่อมต่อกับ Backend ได้\n\n';
            errorMessage += 'สาเหตุที่เป็นไปได้:\n';
            errorMessage += '• Backend server ไม่ได้รันอยู่\n';
            errorMessage += '• Backend URL ไม่ถูกต้อง\n';
            errorMessage += '• Firewall หรือ antivirus block การเชื่อมต่อ\n\n';
            errorMessage += 'วิธีแก้ไข:\n';
            errorMessage += '1. ตรวจสอบว่า backend server รันอยู่ (ดูที่ terminal)\n';
            errorMessage += '2. ตรวจสอบ backend URL ใน Extension Options\n';
            errorMessage += '3. ตรวจสอบ firewall/antivirus settings';
        } else if (err.message.includes('Backend server ไม่ได้รันอยู่')) {
            errorMessage += err.message;
        } else {
            errorMessage += err.message;
        }

        error.textContent = errorMessage;
        error.style.display = 'block';
        loading.style.display = 'none';
        checkBtn.disabled = false;
        return;
    }
}

// ฟังก์ชันตรวจสอบว่า backend รันอยู่หรือไม่
async function checkBackendHealth() {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 seconds timeout

        const healthUrl = backendUrl.replace(/\/+$/, '') + '/fsd/health';
        const response = await fetch(healthUrl, {
            method: 'GET',
            signal: controller.signal
        });

        clearTimeout(timeoutId);
        return response.ok;
    } catch (e) {
        return false;
    }
}

// ฟังก์ชันแสดงผลลัพธ์จาก backend
function displayBackendResult(data) {
    const checkBtn = document.getElementById('checkBtn');
    const loading = document.getElementById('loading');
    const result = document.getElementById('result');

    // ซ่อน loading
    loading.style.display = 'none';
    checkBtn.disabled = false;

    // แปลง verdict เป็นภาษาไทย
    const verdictMap = {
        'Safe': '✅ ปลอดภัย',
        'Risky': '⚠️ เสี่ยง',
        'Danger': '❌ อันตราย'
    };

    // แสดงผลลัพธ์
    document.getElementById('score').textContent = (data.trust_score || data.riskScore || 0) + '/100';
    document.getElementById('verdict').textContent = verdictMap[data.verdict] || data.verdict || 'ไม่ทราบ';

    const detailsList = document.getElementById('detailsList');
    detailsList.innerHTML = '';

    // แสดงรายละเอียด
    const details = data.details || data.warnings || [];
    if (details.length > 0) {
        details.forEach(detail => {
            const li = document.createElement('li');
            li.textContent = '• ' + detail;
            detailsList.appendChild(li);
        });
    } else {
        const li = document.createElement('li');
        li.textContent = '• ไม่พบปัญหาที่ตรวจพบ';
        detailsList.appendChild(li);
    }

    // เปลี่ยนสีตาม verdict
    let resultClass = 'safe';
    if (data.verdict === 'Risky' || data.verdict === 'warn') resultClass = 'risky';
    if (data.verdict === 'Danger' || data.verdict === 'danger') resultClass = 'danger';

    result.className = 'result ' + resultClass;
    result.style.display = 'block';
}