#!/bin/bash
# Script สำหรับ pack extension และเตรียมสำหรับ auto-update

echo "📦 Packing FakeShop Detector Extension..."

# อ่านเวอร์ชันจาก manifest.json
VERSION=$(grep -o '"version": "[^"]*"' manifest.json | cut -d'"' -f4)
echo "📌 Current version: $VERSION"

# สร้างโฟลเดอร์สำหรับ build
mkdir -p ../build
BUILD_DIR="../build/fakeshop-detector-v$VERSION"

# คัดลอกไฟล์ (ยกเว้นไฟล์ที่ไม่จำเป็น)
echo "📋 Copying files..."
mkdir -p "$BUILD_DIR"
cp manifest.json "$BUILD_DIR/"
cp popup.html "$BUILD_DIR/"
cp popup.js "$BUILD_DIR/"
cp icon.svg "$BUILD_DIR/" 2>/dev/null || true

# สร้างไฟล์ .zip
echo "🗜️  Creating ZIP file..."
cd "$BUILD_DIR"
zip -r "../../fakeshop-detector-v$VERSION.zip" . -x "*.md" "*.sh" "*.py"
cd - > /dev/null

echo "✅ Done! Extension packed: fakeshop-detector-v$VERSION.zip"
echo ""
echo "📝 Next steps:"
echo "1. Upload ZIP to Chrome Web Store, OR"
echo "2. Pack as .crx: chrome://extensions/ → Pack extension"
echo "3. Update updates.xml with new version"
