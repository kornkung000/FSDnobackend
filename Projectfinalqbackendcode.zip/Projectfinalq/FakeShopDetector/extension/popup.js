// Backend URL (จะโหลดจาก storage)
let backendUrl = 'http://127.0.0.1:5000';

// โหลด backend URL จาก storage
chrome.storage.sync.get(['backendUrl'], (items) => {
    if (items.backendUrl) {
        backendUrl = items.backendUrl;
    }
});

// Current extension version
const CURRENT_VERSION = chrome.runtime.getManifest().version;

// Internationalization (i18n) data for popup
const popupTranslations = {
    th: {
        extensionTitle: "🛡️ Fake Site Detector(FSD)",
        extensionSubtitle: "เช็คความปลอดภัยของเว็บไซต์",
        urlLabel: "🔗 URL ที่ต้องการเช็คความปลอดภัย:",
        currentTabBtn: "📎 ปัจจุบัน",
        currentTabBtnTooltip: "ใช้ URL ของแท็บปัจจุบัน",
        checkBtn: "🔍 เช็คความปลอดภัย",
        loadingText: "🔍 กำลังเช็คความปลอดภัย...",
        updateText: "มีเวอร์ชันใหม่ให้อัปเดท",
        updateBtn: "อัปเดทเลย",
        detailsTitle: "รายละเอียดการเช็ค:",
        noDetails: "• ไม่พบปัญหาที่ตรวจพบ",
        urlRequired: "กรุณากรอก URL ที่ต้องการเช็คความปลอดภัย",
        urlInvalid: "รูปแบบ URL ไม่ถูกต้อง กรุณาตรวจสอบ",
        tutorialTitle: "🎉 ยินดีต้อนรับ!",
        tutorialStep1Title: "ใส่ URL ที่ต้องการเช็ค",
        tutorialStep1Desc: "พิมพ์ URL ของเว็บไซต์ที่คุณต้องการตรวจสอบความปลอดภัย หรือคลิก \"📎 ปัจจุบัน\" เพื่อใช้ URL ของหน้าที่เปิดอยู่",
        tutorialStep2Title: "คลิก \"🔍 เช็คความปลอดภัย\"",
        tutorialStep2Desc: "กดปุ่มเพื่อเริ่มการตรวจสอบเว็บไซต์",
        tutorialStep3Title: "ดูผลการตรวจสอบ",
        tutorialStep3Desc: "ระบบจะแสดงคะแนนความปลอดภัยและรายละเอียดการตรวจสอบ",
        tutorialStartBtn: "เริ่มใช้งานเลย!",
        safe: "✅ ปลอดภัย",
        risky: "⚠️ เสี่ยง",
        danger: "❌ อันตราย",
        noUrl: "ไม่พบ URL",
        backBtn: "กลับ",
        settingsTitle: "⚙️ ตั้งค่า",
        settingsLanguageLabel: "ภาษา (Language):",
        settingsSaveBtn: "บันทึก",
        settingsUsageTitle: "ℹ️ วิธีใช้งาน Extension",
        settingsUsageStep1: "📌 เปิดเว็บไซต์ที่ต้องการตรวจสอบความปลอดภัย",
        settingsUsageStep2: "🔍 คลิกไอคอน Extension ในแถบเครื่องมือของเบราว์เซอร์",
        settingsUsageStep3: "✅ กดปุ่ม \"เช็คความปลอดภัย\" เพื่อเริ่มการตรวจสอบ",
        settingsUsageStep4: "📊 ดูผลลัพธ์ - Extension จะแสดงคะแนนความน่าเชื่อถือ (0-100) และรายละเอียดการตรวจสอบ",
        settingsUsageStep5: "⚠️ ระวังเว็บที่มีคะแนนต่ำ - คะแนนต่ำกว่า 50 แสดงว่าเว็บมีความเสี่ยงสูง",
        saveSuccess: "✅ บันทึกตั้งค่าสำเร็จ!",
        urlRequired: "⚠️ กรุณากรอก Backend URL",
        urlInvalid: "⚠️ URL ไม่ถูกต้อง",
        testSuccess: "✅ เชื่อมต่อ Backend สำเร็จ!",
        testFail: "⚠️ ไม่สามารถเชื่อมต่อ Backend ได้",
        testTimeout: "⚠️ Backend ไม่ตอบสนอง (Timeout)",
        detailDomainNew: "⚠️ โดเมนใหม่มาก (อายุ {age} วัน)",
        detailDomainRecent: "⚠️ โดเมนค่อนข้างใหม่ (อายุ {age} วัน)",
        detailDomainOld: "✅ โดเมนมีอายุ {age} วัน - ดูน่าเชื่อถือ",
        detailDomainCheckFailed: "⚠️ ไม่สามารถตรวจสอบข้อมูลโดเมนได้",
        detailSSL: "✅ มี SSL Certificate (HTTPS)",
        detailNoSSL: "❌ ไม่มี SSL Certificate (HTTP) - ไม่ปลอดภัย",
        detailLongDomain: "⚠️ โดเมนยาวผิดปกติ",
        detailShortDomain: "⚠️ โดเมนสั้นผิดปกติ",
        detailTooManyDigits: "⚠️ โดเมนมีตัวเลขมากผิดปกติ",
        detailSuspiciousPattern: "⚠️ โดเมนมีรูปแบบน่าสงสัย"
    },
    en: {
        extensionTitle: "🛡️ Fake Site Detector(FSD)",
        extensionSubtitle: "Check website security",
        urlLabel: "🔗 URL to check security:",
        currentTabBtn: "📎 Current",
        currentTabBtnTooltip: "Use URL of current tab",
        checkBtn: "🔍 Check Security",
        loadingText: "🔍 Checking security...",
        updateText: "New version available",
        updateBtn: "Update Now",
        detailsTitle: "Security Details:",
        noDetails: "• No issues found",
        urlRequired: "Please enter URL to check security",
        urlInvalid: "Invalid URL format, please check",
        tutorialTitle: "🎉 Welcome!",
        tutorialStep1Title: "Enter URL to check",
        tutorialStep1Desc: "Type the URL of the website you want to check security for, or click \"📎 Current\" to use the current page URL",
        tutorialStep2Title: "Click \"🔍 Check Security\"",
        tutorialStep2Desc: "Press the button to start website analysis",
        tutorialStep3Title: "View results",
        tutorialStep3Desc: "System will show security score and analysis details",
        tutorialStartBtn: "Get Started!",
        safe: "✅ Safe",
        risky: "⚠️ Risky",
        danger: "❌ Dangerous",
        noUrl: "No URL found",
        backBtn: "Back",
        settingsTitle: "⚙️ Settings",
        settingsLanguageLabel: "Language:",
        settingsSaveBtn: "Save",
        settingsUsageTitle: "ℹ️ How to Use Extension",
        settingsUsageStep1: "📌 Open the website you want to check for security",
        settingsUsageStep2: "🔍 Click the Extension icon in your browser toolbar",
        settingsUsageStep3: "✅ Press the \"Check Security\" button to start analysis",
        settingsUsageStep4: "📊 View results - Extension will show trust score (0-100) and analysis details",
        settingsUsageStep5: "⚠️ Beware of low-scored websites - Scores below 50 indicate high risk",
        saveSuccess: "✅ Settings saved successfully!",
        urlRequired: "⚠️ Please enter Backend URL",
        urlInvalid: "⚠️ Invalid URL format",
        testSuccess: "✅ Backend connection successful!",
        testFail: "⚠️ Cannot connect to Backend",
        testTimeout: "⚠️ Backend not responding (Timeout)",
        detailDomainNew: "⚠️ Very new domain (age {age} days)",
        detailDomainRecent: "⚠️ Relatively new domain (age {age} days)",
        detailDomainOld: "✅ Domain is {age} days old - looks trustworthy",
        detailDomainCheckFailed: "⚠️ Cannot check domain information",
        detailSSL: "✅ Has SSL Certificate (HTTPS)",
        detailNoSSL: "❌ No SSL Certificate (HTTP) - not secure",
        detailLongDomain: "⚠️ Abnormally long domain",
        detailShortDomain: "⚠️ Abnormally short domain",
        detailTooManyDigits: "⚠️ Domain has too many numbers",
        detailSuspiciousPattern: "⚠️ Domain has suspicious pattern"
    }
};

let currentPopupLanguage = 'th';

// Tutorial functions
function checkFirstTimeUser() {
    chrome.storage.sync.get(['tutorialCompleted'], (items) => {
        if (!items.tutorialCompleted) {
            // แสดง tutorial สำหรับผู้ใช้ใหม่
            showTutorial();
        }
    });
}

function showTutorial() {
    const tutorialOverlay = document.getElementById('tutorialOverlay');
    const t = popupTranslations[currentPopupLanguage];

    // อัปเดทข้อความ tutorial ตามภาษา
    document.querySelector('.tutorial-header h2').textContent = t.tutorialTitle;
    document.querySelector('#step1 h3').textContent = t.tutorialStep1Title;
    document.querySelector('#step1 p').textContent = t.tutorialStep1Desc;
    document.querySelector('#step2 h3').textContent = t.tutorialStep2Title;
    document.querySelector('#step2 p').textContent = t.tutorialStep2Desc;
    document.querySelector('#step3 h3').textContent = t.tutorialStep3Title;
    document.querySelector('#step3 p').textContent = t.tutorialStep3Desc;
    document.getElementById('tutorialStart').textContent = t.tutorialStartBtn;

    tutorialOverlay.style.display = 'flex';
}

function markTutorialCompleted() {
    chrome.storage.sync.set({ tutorialCompleted: true });
}

// ดึง URL หน้าปัจจุบันและตรวจสอบ
document.addEventListener('DOMContentLoaded', function() {
    const checkBtn = document.getElementById('checkBtn');
    const loading = document.getElementById('loading');
    const result = document.getElementById('result');
    const error = document.getElementById('error');
    const urlInput = document.getElementById('urlInput');
    const currentTabBtn = document.getElementById('currentTabBtn');
    const updateBtn = document.getElementById('updateBtn');
    const updateNotification = document.getElementById('updateNotification');

    // โหลดภาษาจาก storage ก่อน แล้วค่อยอัปเดท UI
    chrome.storage.sync.get(['language'], (items) => {
        if (items.language) {
            currentPopupLanguage = items.language;
        }
        // อัปเดท UI ตามภาษาที่โหลดมา
        updatePopupLanguage();
        
        // ตรวจสอบว่าเป็นการเปิดครั้งแรกหรือไม่
        checkFirstTimeUser();

        // ตรวจสอบเวอร์ชันเมื่อเปิด popup
        checkForUpdates();

        // โหลด URL ปัจจุบันเข้า input
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if (tabs[0] && tabs[0].url) {
                urlInput.value = tabs[0].url;
            }
        });
    });

    // เมื่อกดปุ่มตรวจสอบ
    checkBtn.addEventListener('click', function() {
        const url = urlInput.value.trim();
        const t = popupTranslations[currentPopupLanguage];

        if (!url) {
            showError(t.urlRequired, 'warning');
            urlInput.focus();
            return;
        }

        // ตรวจสอบรูปแบบ URL
        try {
            new URL(url);
        } catch (e) {
            showError(t.urlInvalid, 'warning');
            urlInput.focus();
            return;
        }

        checkUrlWithBackend(url);
    });

    // เมื่อกดปุ่มใส่ URL ปัจจุบัน
    currentTabBtn.addEventListener('click', function() {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if (tabs[0] && tabs[0].url) {
                urlInput.value = tabs[0].url;
                urlInput.focus();
            } else {
                showError(popupTranslations[currentPopupLanguage].noUrl, 'warning');
            }
        });
    });

    // Enter key ใน input field
    urlInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            checkBtn.click();
        }
    });

    // Settings button - show settings view
    const settingsBtn = document.getElementById('settingsBtn');
    const mainView = document.getElementById('mainView');
    const settingsView = document.getElementById('settingsView');
    settingsBtn.addEventListener('click', function() {
        showSettingsView();
    });

    // Back button - return to main view
    const backBtn = document.getElementById('backBtn');
    backBtn.addEventListener('click', function() {
        showMainView();
    });

    // Settings save button
    const settingsSaveBtn = document.getElementById('settingsSaveBtn');
    const settingsLanguageSelect = document.getElementById('settingsLanguageSelect');
    const settingsStatus = document.getElementById('settingsStatus');

    // Load settings values
    chrome.storage.sync.get(['language'], (items) => {
        if (items.language) {
            settingsLanguageSelect.value = items.language;
        }
    });

    // Save settings
    settingsSaveBtn.addEventListener('click', function() {
        const languageValue = settingsLanguageSelect.value;
        const t = popupTranslations[currentPopupLanguage];

        // Save settings
        chrome.storage.sync.set({
            language: languageValue
        }, () => {
            // Update language if changed
            if (languageValue !== currentPopupLanguage) {
                currentPopupLanguage = languageValue;
                updatePopupLanguage();
                updateSettingsLanguage();
            }
            
            showSettingsStatus(t.saveSuccess, 'success');
        });
    });

    // Language change in settings
    settingsLanguageSelect.addEventListener('change', function() {
        const newLang = settingsLanguageSelect.value;
        if (newLang !== currentPopupLanguage) {
            currentPopupLanguage = newLang;
            updateSettingsLanguage();
        }
    });

    // Update button
    updateBtn.addEventListener('click', function() {
        performUpdate();
    });

    // Tutorial event listeners
    const tutorialOverlay = document.getElementById('tutorialOverlay');
    const tutorialClose = document.getElementById('tutorialClose');
    const tutorialStart = document.getElementById('tutorialStart');

    tutorialClose.addEventListener('click', function() {
        tutorialOverlay.style.display = 'none';
        markTutorialCompleted();
    });

    tutorialStart.addEventListener('click', function() {
        tutorialOverlay.style.display = 'none';
        markTutorialCompleted();
    });

    // ปิด tutorial เมื่อคลิกพื้นหลัง
    tutorialOverlay.addEventListener('click', function(e) {
        if (e.target === tutorialOverlay) {
            tutorialOverlay.style.display = 'none';
            markTutorialCompleted();
        }
    });

    // ฟังการเปลี่ยนแปลงภาษาจาก storage
    chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName === 'sync' && changes.language) {
            currentPopupLanguage = changes.language.newValue;
            updatePopupLanguage();
        }
    });
});

// ฟังก์ชันตรวจสอบการอัปเดท
async function checkForUpdates() {
    try {
        const updateNotification = document.getElementById('updateNotification');

        // ตรวจสอบเวอร์ชันจาก backend หรือไฟล์ version.json
        const latestVersion = await getLatestVersion();

        if (latestVersion && isVersionNewer(latestVersion, CURRENT_VERSION)) {
            // แสดง notification อัปเดท
            updateNotification.style.display = 'block';
            console.log(`มีเวอร์ชันใหม่: ${latestVersion} (ปัจจุบัน: ${CURRENT_VERSION})`);
        }
    } catch (e) {
        console.log('ไม่สามารถตรวจสอบการอัปเดทได้:', e.message);
        // ไม่แสดง error ถ้าตรวจสอบไม่ได้
    }
}

// ดึงเวอร์ชันล่าสุดจาก backend หรือไฟล์
async function getLatestVersion() {
    try {
        // วิธีที่ 1: ตรวจสอบจาก backend
        const healthUrl = backendUrl.replace(/\/+$/, '') + '/fsd/health';
        const response = await fetch(healthUrl, {
            method: 'GET',
            signal: AbortSignal.timeout(5000)
        });

        if (response.ok) {
            const data = await response.json();
            // Backend อาจส่ง version กลับมา
            return data.version || null;
        }
    } catch (e) {
        console.log('ไม่สามารถตรวจสอบจาก backend:', e.message);
    }

    try {
        // วิธีที่ 2: ตรวจสอบจากไฟล์ version.json ใน extension
        const response = await fetch(chrome.runtime.getURL('version.json'), {
            method: 'GET'
        });

        if (response.ok) {
            const data = await response.json();
            return data.version;
        }
    } catch (e) {
        console.log('ไม่สามารถตรวจสอบจาก version.json:', e.message);
    }

    return null;
}

// ตรวจสอบว่า version ใหม่กว่าไหม
function isVersionNewer(latestVersion, currentVersion) {
    try {
        const latest = latestVersion.split('.').map(Number);
        const current = currentVersion.split('.').map(Number);

        for (let i = 0; i < Math.max(latest.length, current.length); i++) {
            const l = latest[i] || 0;
            const c = current[i] || 0;

            if (l > c) return true;
            if (l < c) return false;
        }

        return false; // เวอร์ชันเท่ากัน
    } catch (e) {
        console.error('Error comparing versions:', e);
        return false;
    }
}

// ดำเนินการอัปเดท
async function performUpdate() {
    const updateBtn = document.getElementById('updateBtn');

    // ปิดปุ่มอัปเดทชั่วคราว
    updateBtn.disabled = true;
    updateBtn.textContent = 'กำลังอัปเดท...';

    try {
        // รีโหลด extension
        chrome.runtime.reload();

        // หรือแสดงข้อความให้ผู้ใช้ refresh เอง
        alert('Extension ถูกอัปเดทแล้ว!\n\nกรุณาปิดและเปิด popup ใหม่ หรือ refresh หน้าเว็บนี้');

        // ซ่อน notification
        document.getElementById('updateNotification').style.display = 'none';

    } catch (e) {
        console.error('Update failed:', e);
        alert('เกิดข้อผิดพลาดในการอัปเดท: ' + e.message);

        // เปิดปุ่มกลับ
        updateBtn.disabled = false;
        updateBtn.textContent = 'อัปเดทเลย';
    }
}

// แยกโดเมนออกจาก URL
function extractDomain(url) {
    try {
        const urlObj = new URL(url);
        return urlObj.hostname.replace('www.', '');
    } catch (e) {
        // ถ้าไม่ใช่ URL ที่สมบูรณ์ ให้ลองแยกเอง
        return url.replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0].split('?')[0];
    }
}

// ฟังก์ชันตรวจสอบ URL ด้วย Backend
async function checkUrlWithBackend(url) {
    const checkBtn = document.getElementById('checkBtn');
    const loading = document.getElementById('loading');
    const result = document.getElementById('result');
    const error = document.getElementById('error');

    // ซ่อนผลลัพธ์เก่า
    result.style.display = 'none';
    error.style.display = 'none';

    // แสดง loading
    loading.style.display = 'block';
    checkBtn.disabled = true;

    try {
        // ตรวจสอบว่า backend รันอยู่หรือไม่
        const isBackendOnline = await checkBackendHealth();
        if (!isBackendOnline) {
            const t = popupTranslations[currentPopupLanguage];
            const backendErrorMsg = currentPopupLanguage === 'th' 
                ? `Backend server ไม่ได้รันอยู่\n\nกรุณา:\n1. รัน backend server ด้วยคำสั่ง: python app.py\n2. ตรวจสอบว่า backend URL ถูกต้อง: ${backendUrl}\n3. ตรวจสอบว่า backend รันที่ port 5000\n\nหรือตั้งค่า backend URL ใน Settings (กดปุ่ม ⚙️)`
                : `Backend server is not running\n\nPlease:\n1. Run backend server with command: python app.py\n2. Check if backend URL is correct: ${backendUrl}\n3. Check if backend is running on port 5000\n\nOr set backend URL in Settings (click ⚙️ button)`;
            throw new Error(backendErrorMsg);
        }

        // ส่ง URL ไปให้ backend วิเคราะห์
        const endpoint = backendUrl.replace(/\/+$/, '') + '/fsd/api/check';
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ url: url })
        });

        if (!response.ok) {
            const text = await response.text();
            throw new Error(`Backend error: ${response.status} ${text}`);
        }

        const data = await response.json();

        // แสดงผลลัพธ์จาก backend
        displayBackendResult(data);

    } catch (err) {
        console.error('Error checking URL with backend:', err);
        const t = popupTranslations[currentPopupLanguage];

        // แสดง error message ที่ชัดเจนขึ้น
        let errorMessage = '';
        if (err.message.includes('Failed to fetch') || err.message.includes('NetworkError')) {
            if (currentPopupLanguage === 'th') {
                errorMessage = 'เกิดข้อผิดพลาด: ไม่สามารถเชื่อมต่อกับ Backend ได้\n\n';
                errorMessage += 'สาเหตุที่เป็นไปได้:\n';
                errorMessage += '• Backend server ไม่ได้รันอยู่\n';
                errorMessage += '• Backend URL ไม่ถูกต้อง\n';
                errorMessage += '• Firewall หรือ antivirus block การเชื่อมต่อ\n\n';
                errorMessage += 'วิธีแก้ไข:\n';
                errorMessage += '1. ตรวจสอบว่า backend server รันอยู่ (ดูที่ terminal)\n';
                errorMessage += '2. ตรวจสอบ backend URL ใน Settings (กดปุ่ม ⚙️)\n';
                errorMessage += '3. ตรวจสอบ firewall/antivirus settings';
            } else {
                errorMessage = 'Error: Cannot connect to Backend\n\n';
                errorMessage += 'Possible causes:\n';
                errorMessage += '• Backend server is not running\n';
                errorMessage += '• Backend URL is incorrect\n';
                errorMessage += '• Firewall or antivirus blocking connection\n\n';
                errorMessage += 'How to fix:\n';
                errorMessage += '1. Check if backend server is running (check terminal)\n';
                errorMessage += '2. Check backend URL in Settings (click ⚙️ button)\n';
                errorMessage += '3. Check firewall/antivirus settings';
            }
        } else if (err.message.includes('Backend server ไม่ได้รันอยู่') || err.message.includes('Backend server is not running')) {
            errorMessage = currentPopupLanguage === 'th' ? 'เกิดข้อผิดพลาด: ' : 'Error: ';
            errorMessage += err.message;
        } else {
            errorMessage = currentPopupLanguage === 'th' ? 'เกิดข้อผิดพลาด: ' : 'Error: ';
            errorMessage += err.message;
        }

        showError(errorMessage, 'error');
        loading.style.display = 'none';
        checkBtn.disabled = false;
        return;
    }
}

// ฟังก์ชันตรวจสอบว่า backend รันอยู่หรือไม่
async function checkBackendHealth() {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 seconds timeout

        const healthUrl = backendUrl.replace(/\/+$/, '') + '/fsd/health';
        const response = await fetch(healthUrl, {
            method: 'GET',
            signal: controller.signal
        });

        clearTimeout(timeoutId);
        return response.ok;
    } catch (e) {
        return false;
    }
}

// ฟังก์ชันอัปเดทภาษาใน popup
function updatePopupLanguage() {
    const t = popupTranslations[currentPopupLanguage];

    document.getElementById('extensionTitle').textContent = t.extensionTitle;
    document.getElementById('extensionSubtitle').textContent = t.extensionSubtitle;
    document.querySelector('label[for="urlInput"]').textContent = t.urlLabel;
    const currentTabBtn = document.getElementById('currentTabBtn');
    currentTabBtn.textContent = t.currentTabBtn;
    currentTabBtn.title = t.currentTabBtnTooltip;
    document.getElementById('checkBtn').textContent = t.checkBtn;
    document.querySelector('.loading p').textContent = t.loadingText;
    document.querySelector('.update-text').textContent = t.updateText;
    document.getElementById('updateBtn').textContent = t.updateBtn;
    document.querySelector('.details h3').textContent = t.detailsTitle;
}

// ฟังก์ชันแสดงผลลัพธ์จาก backend
function displayBackendResult(data) {
    const checkBtn = document.getElementById('checkBtn');
    const loading = document.getElementById('loading');
    const result = document.getElementById('result');
    const t = popupTranslations[currentPopupLanguage];

    // ซ่อน loading
    loading.style.display = 'none';
    checkBtn.disabled = false;

    // แปลง verdict เป็นภาษาที่เลือก
    const verdictMap = {
        'Safe': t.safe,
        'safe': t.safe,
        'Risky': t.risky,
        'risky': t.risky,
        'warn': t.risky,
        'Warn': t.risky,
        'Danger': t.danger,
        'danger': t.danger
    };

    // แสดงผลลัพธ์
    document.getElementById('score').textContent = (data.trust_score || data.riskScore || 0) + '/100';
    const verdictText = verdictMap[data.verdict] || data.verdict || (currentPopupLanguage === 'th' ? 'ไม่ทราบ' : 'Unknown');
    document.getElementById('verdict').textContent = verdictText;

    const detailsList = document.getElementById('detailsList');
    detailsList.innerHTML = '';

    // แสดงรายละเอียด (แปลเป็นภาษาที่เลือก)
    const details = data.details || data.warnings || [];
    if (details.length > 0) {
        details.forEach(detail => {
            const li = document.createElement('li');
            li.textContent = '• ' + translateDetail(detail, t);
            detailsList.appendChild(li);
        });
    } else {
        const li = document.createElement('li');
        li.textContent = popupTranslations[currentPopupLanguage].noDetails;
        detailsList.appendChild(li);
    }

    // เปลี่ยนสีตาม verdict
    let resultClass = 'safe';
    if (data.verdict === 'Risky' || data.verdict === 'warn') resultClass = 'risky';
    if (data.verdict === 'Danger' || data.verdict === 'danger') resultClass = 'danger';

    result.className = 'result ' + resultClass;
    result.style.display = 'block';
}

// ฟังก์ชันแปลรายละเอียด Security Details
function translateDetail(detail, translations) {
    // ถ้าเป็นภาษาอังกฤษอยู่แล้ว (ไม่ต้องแปล)
    if (currentPopupLanguage === 'en') {
        // แปลงจากภาษาไทยเป็นภาษาอังกฤษ
        let translated = detail;
        
        // ตรวจสอบอายุโดเมน
        const domainAgeMatch = detail.match(/โดเมนใหม่มาก \(อายุ (\d+) วัน\)/);
        if (domainAgeMatch) {
            return translations.detailDomainNew.replace('{age}', domainAgeMatch[1]);
        }
        
        const domainRecentMatch = detail.match(/โดเมนค่อนข้างใหม่ \(อายุ (\d+) วัน\)/);
        if (domainRecentMatch) {
            return translations.detailDomainRecent.replace('{age}', domainRecentMatch[1]);
        }
        
        const domainOldMatch = detail.match(/โดเมนมีอายุ (\d+) วัน - ดูน่าเชื่อถือ/);
        if (domainOldMatch) {
            return translations.detailDomainOld.replace('{age}', domainOldMatch[1]);
        }
        
        // ตรวจสอบ SSL
        if (detail.includes('มี SSL Certificate (HTTPS)')) {
            return translations.detailSSL;
        }
        
        if (detail.includes('ไม่มี SSL Certificate (HTTP)') || detail.includes('ไม่ปลอดภัย')) {
            return translations.detailNoSSL;
        }
        
        // ตรวจสอบโดเมนผิดปกติ
        if (detail.includes('โดเมนยาวผิดปกติ')) {
            return translations.detailLongDomain;
        }
        
        if (detail.includes('โดเมนสั้นผิดปกติ')) {
            return translations.detailShortDomain;
        }
        
        if (detail.includes('โดเมนมีตัวเลขมากผิดปกติ')) {
            return translations.detailTooManyDigits;
        }
        
        if (detail.includes('โดเมนมีรูปแบบน่าสงสัย')) {
            // ตรวจสอบรายละเอียดเพิ่มเติม
            const patternMatch = detail.match(/โดเมนมีรูปแบบน่าสงสัย: (.+)/);
            if (patternMatch) {
                return translations.detailSuspiciousPattern + ': ' + patternMatch[1];
            }
            return translations.detailSuspiciousPattern;
        }
        
        // ตรวจสอบข้อมูลโดเมน
        if (detail.includes('ไม่สามารถตรวจสอบข้อมูลโดเมนได้')) {
            return translations.detailDomainCheckFailed;
        }
        
        // ถ้าไม่เจอ pattern ให้คืนค่าเดิม
        return detail;
    }
    
    // ถ้าเป็นภาษาไทย ไม่ต้องแปล
    return detail;
}

// ฟังก์ชันแสดง error อย่างสวยงาม
function showError(message, type = 'error') {
    const error = document.getElementById('error');
    error.textContent = message;
    error.className = 'error ' + type;
    error.style.display = 'block';
}

// ฟังก์ชันแสดง/ซ่อนหน้า Settings
function showSettingsView() {
    const mainView = document.getElementById('mainView');
    const settingsView = document.getElementById('settingsView');
    const settingsBtn = document.getElementById('settingsBtn');
    
    mainView.classList.add('hidden');
    settingsView.classList.add('active');
    settingsBtn.style.display = 'none';
    
    // โหลดค่าตั้งค่าปัจจุบันและอัปเดทภาษา
    chrome.storage.sync.get(['language'], (items) => {
        if (items.language) {
            currentPopupLanguage = items.language;
            document.getElementById('settingsLanguageSelect').value = items.language;
        }
        // อัปเดทภาษาในหน้า Settings หลังจากโหลดเสร็จ
        updateSettingsLanguage();
    });
}

function showMainView() {
    const mainView = document.getElementById('mainView');
    const settingsView = document.getElementById('settingsView');
    const settingsBtn = document.getElementById('settingsBtn');
    
    mainView.classList.remove('hidden');
    settingsView.classList.remove('active');
    settingsBtn.style.display = 'block';
}

// อัปเดทภาษาในหน้า Settings
function updateSettingsLanguage() {
    const t = popupTranslations[currentPopupLanguage];
    
    document.getElementById('backBtnText').textContent = t.backBtn;
    document.getElementById('settingsTitle').textContent = t.settingsTitle;
    document.getElementById('settingsLanguageLabel').textContent = t.settingsLanguageLabel;
    document.getElementById('settingsSaveBtnText').textContent = t.settingsSaveBtn;
    document.getElementById('settingsUsageTitle').textContent = t.settingsUsageTitle;
    
    const usageList = document.getElementById('settingsUsageList');
    usageList.innerHTML = `
        <li>${t.settingsUsageStep1}</li>
        <li>${t.settingsUsageStep2}</li>
        <li>${t.settingsUsageStep3}</li>
        <li>${t.settingsUsageStep4}</li>
        <li>${t.settingsUsageStep5}</li>
    `;
}

// แสดงสถานะในหน้า Settings
function showSettingsStatus(message, type) {
    const status = document.getElementById('settingsStatus');
    status.textContent = message;
    status.className = `settings-status ${type}`;
    status.style.display = 'block';
    
    if (type === 'success') {
        setTimeout(() => {
            status.style.display = 'none';
        }, 3000);
    }
}

// ทดสอบการเชื่อมต่อ Backend
async function testBackendConnection(url) {
    const t = popupTranslations[currentPopupLanguage];
    
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);
        
        const healthUrl = url.replace(/\/+$/, '') + '/fsd/health';
        const response = await fetch(healthUrl, {
            method: 'GET',
            signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        if (response.ok) {
            showSettingsStatus(t.testSuccess, 'success');
        } else {
            showSettingsStatus(t.testFail, 'error');
        }
    } catch (e) {
        if (e.name === 'AbortError') {
            showSettingsStatus(t.testTimeout, 'error');
        } else {
            showSettingsStatus(t.testFail, 'error');
        }
    }
}