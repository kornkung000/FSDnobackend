# 🔄 ระบบ Auto-Update สำหรับ FakeShop Detector

## 📌 สรุป

Extension นี้รองรับ **Auto-Update** ซึ่งหมายความว่า:
- ✅ ผู้ใช้โหลด extension **เพียงครั้งเดียว**
- ✅ หลังจากนั้น extension จะ **อัพเดทอัตโนมัติ**
- ✅ ไม่ต้องโหลดใหม่ทุกครั้งที่มีอัพเดท

---

## 🚀 วิธีใช้งาน (สำหรับผู้ใช้)

### ติดตั้งครั้งแรก:

1. **โหลด Extension:**
   - ไปที่ `chrome://extensions/`
   - เปิด Developer mode
   - Load unpacked → เลือกโฟลเดอร์ `extension`

2. **เสร็จ!** Extension จะอัพเดทอัตโนมัติในอนาคต

---

## 🛠️ วิธีตั้งค่า Auto-Update (สำหรับ Developer)

### วิธีที่ 1: ใช้ GitHub Releases (แนะนำ - ฟรี)

**ขั้นตอน:**

1. **Pack Extension:**
   ```bash
   # Windows
   pack-extension.bat
   
   # Linux/Mac
   ./pack-extension.sh
   ```

2. **สร้าง GitHub Release:**
   - ไปที่ GitHub repository
   - Releases → Create a new release
   - Tag: `v1.0.0`
   - อัพโหลดไฟล์ `.zip` หรือ `.crx`

3. **อัพเดท updates.xml:**
   - แก้ไข `updates.xml` ให้ชี้ไป GitHub Releases
   - อัพเดท version

4. **Host updates.xml:**
   - ใช้ GitHub Pages หรือ raw.githubusercontent.com

5. **อัพเดท manifest.json:**
   ```json
   {
     "update_url": "https://raw.githubusercontent.com/USERNAME/REPO/main/extension/updates.xml"
   }
   ```

**อ่านเพิ่มเติม:** ดู `คู่มือ-Auto-Update-แบบง่าย.md`

---

### วิธีที่ 2: ใช้ Chrome Web Store (แนะนำสำหรับ Production)

**ขั้นตอน:**

1. **อัพโหลดไป Chrome Web Store:**
   - ไปที่ https://chrome.google.com/webstore/devconsole
   - สร้าง Developer account ($5 ครั้งแรก)
   - อัพโหลด extension
   - Submit for review

2. **หลังจากผ่าน Review:**
   - Extension จะมี update URL อัตโนมัติ
   - ผู้ใช้ติดตั้งจาก Chrome Web Store
   - อัพเดทอัตโนมัติทุกครั้งที่ publish

**ข้อดี:**
- ✅ ปลอดภัย
- ✅ อัพเดทอัตโนมัติ
- ✅ ไม่ต้อง host server เอง

---

### วิธีที่ 3: Self-Hosted

**ขั้นตอน:**

1. **Pack Extension:**
   - ใช้ Chrome: `chrome://extensions/` → Pack extension
   - จะได้ไฟล์ `.crx`

2. **อัพโหลดไป Web Server:**
   - อัพโหลด `.crx` ไปยัง web server
   - อัพโหลด `updates.xml` ไปยัง web server
   - **ต้องใช้ HTTPS!**

3. **อัพเดท manifest.json:**
   ```json
   {
     "update_url": "https://your-domain.com/extension/updates.xml"
   }
   ```

4. **รัน Update Server (Optional):**
   ```bash
   cd server
   python update_server.py
   ```

---

## 📝 ไฟล์ที่เกี่ยวข้อง

- `manifest.json` - มี `update_url` สำหรับ auto-update
- `updates.xml` - Update manifest ที่บอก Chrome ว่ามีเวอร์ชันใหม่อะไร
- `update_server.py` - Server สำหรับ host update manifest (optional)
- `pack-extension.bat` / `pack-extension.sh` - Script สำหรับ pack extension

---

## 🔄 วิธีอัพเดท Extension

เมื่อต้องการอัพเดท:

1. **อัพเดท version ใน manifest.json:**
   ```json
   {
     "version": "1.0.1"
   }
   ```

2. **Pack extension ใหม่**

3. **อัพโหลด .crx ใหม่**

4. **อัพเดท updates.xml:**
   ```xml
   <updatecheck 
     codebase='https://.../fakeshop-detector-v1.0.1.crx' 
     version='1.0.1' 
   />
   ```

5. **อัพโหลด updates.xml**

6. **เสร็จ!** Extension จะอัพเดทอัตโนมัติภายใน 5-6 ชั่วโมง

---

## ⚠️ ข้อควรระวัง

1. **Extension ID ต้องเหมือนกัน** - ต้องใช้ key เดิมทุกครั้ง
2. **HTTPS เท่านั้น** - Update URL ต้องใช้ HTTPS
3. **Version Format** - ใช้ `MAJOR.MINOR.PATCH`
4. **Update Frequency** - Chrome ตรวจสอบทุก 5-6 ชั่วโมง

---

## 📚 เอกสารเพิ่มเติม

- `คู่มือ-Auto-Update-แบบง่าย.md` - คู่มือแบบละเอียด
- `auto-update-setup.md` - คู่มือแบบเต็มรูปแบบ

---

## 🎉 พร้อมใช้งาน!

หลังจากตั้งค่าแล้ว extension จะอัพเดทอัตโนมัติ!
