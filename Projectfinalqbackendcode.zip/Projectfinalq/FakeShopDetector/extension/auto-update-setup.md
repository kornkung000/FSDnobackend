# 🔄 ตั้งค่าระบบ Auto-Update สำหรับ Extension

## 📋 ภาพรวม

ระบบ auto-update จะทำให้ extension อัพเดทอัตโนมัติโดยไม่ต้องโหลดใหม่ทุกครั้ง

## 🎯 วิธีที่ 1: ใช้ Chrome Web Store (แนะนำ)

### ขั้นตอน:

1. **เตรียม Extension Package:**
   ```bash
   # สร้างไฟล์ .zip ของ extension
   cd extension
   zip -r ../fakeshop-detector.zip . -x "*.md" "*.py"
   ```

2. **อัพโหลดไป Chrome Web Store:**
   - ไปที่ https://chrome.google.com/webstore/devconsole
   - สร้าง Developer account (ครั้งแรก $5)
   - อัพโหลดไฟล์ .zip
   - กรอกข้อมูล extension
   - Publish

3. **อัพเดท manifest.json:**
   ```json
   {
     "update_url": "https://clients2.google.com/service/update2/crx"
   }
   ```
   (Chrome จะเติมให้อัตโนมัติเมื่ออัพโหลดไป Web Store)

### ข้อดี:
- ✅ อัพเดทอัตโนมัติ
- ✅ ปลอดภัย (ผ่าน Chrome Web Store)
- ✅ ไม่ต้อง host server เอง

---

## 🎯 วิธีที่ 2: Self-Hosted Update Server

### ขั้นตอนที่ 1: เตรียม Extension ID

1. **ติดตั้ง Extension ครั้งแรก:**
   - เปิด `chrome://extensions/`
   - เปิด Developer mode
   - Load unpacked → เลือกโฟลเดอร์ `extension`
   - **คัดลอก Extension ID** (เช่น: `abcdefghijklmnopqrstuvwxyz123456`)

2. **อัพเดท manifest.json:**
   ```json
   {
     "key": "YOUR_PUBLIC_KEY_HERE"
   }
   ```
   - สร้าง key ด้วย: `chrome://extensions/` → Developer mode → Pack extension
   - หรือใช้ Extension ID ที่ได้

### ขั้นตอนที่ 2: สร้างไฟล์ updates.xml

แก้ไขไฟล์ `extension/updates.xml`:

```xml
<?xml version='1.0' encoding='UTF-8'?>
<gupdate xmlns='http://www.google.com/update2/response' protocol='2.0'>
  <app appid='YOUR_EXTENSION_ID_HERE'>
    <updatecheck 
      codebase='https://your-domain.com/extension/fakeshop-detector-v1.0.1.crx' 
      version='1.0.1' 
    />
  </app>
</gupdate>
```

**เปลี่ยน:**
- `YOUR_EXTENSION_ID_HERE` → Extension ID ของคุณ
- `https://your-domain.com` → Domain ของคุณ
- `version='1.0.1'` → เวอร์ชันใหม่

### ขั้นตอนที่ 3: สร้าง .crx File

1. **Pack Extension:**
   - ไปที่ `chrome://extensions/`
   - เปิด Developer mode
   - คลิก "Pack extension"
   - เลือกโฟลเดอร์ `extension`
   - คลิก "Pack Extension"
   - จะได้ไฟล์ `.crx` และ `.pem`

2. **อัพโหลด .crx ไป Server:**
   - อัพโหลดไฟล์ `.crx` ไปยัง web server ของคุณ
   - ตั้งชื่อตามเวอร์ชัน เช่น `fakeshop-detector-v1.0.1.crx`

### ขั้นตอนที่ 4: ตั้งค่า Update Server

1. **รัน Update Server:**
   ```bash
   cd server
   python update_server.py
   ```

2. **อัพเดท manifest.json:**
   ```json
   {
     "update_url": "https://your-domain.com/extension/updates.xml"
   }
   ```

3. **Deploy ไป Production:**
   - อัพโหลดไฟล์ไป web server (เช่น GitHub Pages, Netlify, Vercel)
   - หรือใช้ hosting service

---

## 🚀 วิธีที่ 3: ใช้ GitHub Releases (ง่ายที่สุด)

### ขั้นตอน:

1. **สร้าง GitHub Repository:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/yourusername/fakeshop-detector.git
   git push -u origin main
   ```

2. **สร้าง Release:**
   - ไปที่ GitHub repository
   - คลิก "Releases" → "Create a new release"
   - Tag version: `v1.0.0`
   - อัพโหลดไฟล์ `.crx`
   - Publish release

3. **ตั้งค่า updates.xml:**
   ```xml
   <updatecheck 
     codebase='https://github.com/yourusername/fakeshop-detector/releases/download/v1.0.1/fakeshop-detector-v1.0.1.crx' 
     version='1.0.1' 
   />
   ```

4. **Host updates.xml:**
   - ใช้ GitHub Pages หรือ
   - ใช้ raw.githubusercontent.com

---

## 📝 Checklist สำหรับ Auto-Update

### ✅ ก่อนอัพเดท:

- [ ] อัพเดท version ใน `manifest.json`
- [ ] ทดสอบ extension ว่าทำงานถูกต้อง
- [ ] Pack extension เป็น `.crx`
- [ ] อัพเดท `updates.xml` ให้ชี้ไปเวอร์ชันใหม่
- [ ] อัพโหลด `.crx` ไปยัง server
- [ ] ทดสอบว่า updates.xml ทำงาน

### ✅ หลังอัพเดท:

- [ ] ตรวจสอบว่า extension อัพเดทอัตโนมัติ
- [ ] ทดสอบฟีเจอร์ใหม่
- [ ] ตรวจสอบ logs ใน `chrome://extensions/`

---

## 🔧 การทดสอบ Auto-Update

### วิธีทดสอบ:

1. **ติดตั้ง Extension เวอร์ชันเก่า:**
   - ติดตั้ง extension เวอร์ชัน 1.0.0

2. **อัพเดท updates.xml:**
   - เปลี่ยนเวอร์ชันเป็น 1.0.1 ใน `updates.xml`
   - อัพโหลด `.crx` เวอร์ชันใหม่

3. **ตรวจสอบการอัพเดท:**
   - เปิด `chrome://extensions/`
   - Extension จะอัพเดทอัตโนมัติภายใน 5-6 ชั่วโมง
   - หรือกด "Update extensions now" (Developer mode)

---

## ⚠️ หมายเหตุสำคัญ

1. **Extension ID ต้องเหมือนกัน:**
   - Extension ID จะเปลี่ยนถ้าเปลี่ยน key
   - ต้องใช้ key เดิมทุกครั้ง

2. **HTTPS เท่านั้น:**
   - Update URL ต้องใช้ HTTPS
   - ไม่สามารถใช้ HTTP ได้

3. **Version Format:**
   - ใช้ format: `MAJOR.MINOR.PATCH`
   - เช่น: `1.0.0`, `1.0.1`, `1.1.0`

4. **Update Frequency:**
   - Chrome ตรวจสอบอัพเดททุก 5-6 ชั่วโมง
   - หรือเมื่อเปิด browser ใหม่

---

## 📞 Troubleshooting

### Extension ไม่อัพเดท:

1. ตรวจสอบ `updates.xml` ว่า accessible
2. ตรวจสอบ version ใน `updates.xml` ใหม่กว่าเวอร์ชันปัจจุบัน
3. ตรวจสอบ Extension ID ตรงกัน
4. ตรวจสอบว่า `.crx` file accessible

### ตรวจสอบ Update Status:

- ไปที่ `chrome://extensions/`
- เปิด Developer mode
- ดู "Last updated" และ "Update URL"

---

## 🎉 เสร็จแล้ว!

หลังจากตั้งค่าแล้ว:
- ✅ Extension จะอัพเดทอัตโนมัติ
- ✅ ไม่ต้องโหลดใหม่ทุกครั้ง
- ✅ ผู้ใช้จะได้เวอร์ชันล่าสุดเสมอ
