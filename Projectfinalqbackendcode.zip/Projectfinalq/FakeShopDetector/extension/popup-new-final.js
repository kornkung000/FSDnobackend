// Backend URL (จะโหลดจาก storage)
let backendUrl = 'http://127.0.0.1:5000';

// โหลด backend URL จาก storage
chrome.storage.sync.get(['backendUrl'], (items) => {
    if (items.backendUrl) {
        backendUrl = items.backendUrl;
    }
});

// Current extension version
const CURRENT_VERSION = chrome.runtime.getManifest().version;

// ดึง URL หน้าปัจจุบันและตรวจสอบ
document.addEventListener('DOMContentLoaded', function() {
    const checkBtn = document.getElementById('checkBtn');
    const loading = document.getElementById('loading');
    const result = document.getElementById('result');
    const error = document.getElementById('error');
    const urlInput = document.getElementById('urlInput');
    const currentTabBtn = document.getElementById('currentTabBtn');
    const updateBtn = document.getElementById('updateBtn');
    const updateNotification = document.getElementById('updateNotification');

    // ตรวจสอบเวอร์ชันเมื่อเปิด popup
    checkForUpdates();

    // โหลด URL ปัจจุบันเข้า input
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs[0] && tabs[0].url) {
            urlInput.value = tabs[0].url;
        }
    });

    // เมื่อกดปุ่มตรวจสอบ
    checkBtn.addEventListener('click', function() {
        const url = urlInput.value.trim();
        if (!url) {
            showError('กรุณากรอก URL ที่ต้องการตรวจสอบ', 'warning');
            urlInput.focus();
            return;
        }

        // ตรวจสอบรูปแบบ URL
        try {
            new URL(url);
        } catch (e) {
            showError('รูปแบบ URL ไม่ถูกต้อง กรุณาตรวจสอบ', 'warning');
            urlInput.focus();
            return;
        }

        checkUrlWithBackend(url);
    });

    // เมื่อกดปุ่มใส่ URL ปัจจุบัน
    currentTabBtn.addEventListener('click', function() {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if (tabs[0] && tabs[0].url) {
                urlInput.value = tabs[0].url;
                urlInput.focus();
            } else {
                showError('ไม่สามารถเข้าถึง URL ของแท็บนี้ได้', 'warning');
            }
        });
    });

    // Enter key ใน input field
    urlInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            checkBtn.click();
        }
    });
});

// ฟังก์ชันตรวจสอบการอัปเดท
async function checkForUpdates() {
    try {
        const updateNotification = document.getElementById('updateNotification');

        // ตรวจสอบเวอร์ชันจาก backend หรือไฟล์ version.json
        const latestVersion = await getLatestVersion();

        if (latestVersion && isVersionNewer(latestVersion, CURRENT_VERSION)) {
            // แสดง notification อัปเดท
            updateNotification.style.display = 'block';
            console.log(`มีเวอร์ชันใหม่: ${latestVersion} (ปัจจุบัน: ${CURRENT_VERSION})`);
        }
    } catch (e) {
        console.log('ไม่สามารถตรวจสอบการอัปเดทได้:', e.message);
        // ไม่แสดง error ถ้าตรวจสอบไม่ได้
    }
}

// ดึงเวอร์ชันล่าสุดจาก backend หรือไฟล์
async function getLatestVersion() {
    try {
        // วิธีที่ 1: ตรวจสอบจาก backend
        const healthUrl = backendUrl.replace(/\/+$/, '') + '/fsd/health';
        const response = await fetch(healthUrl, {
            method: 'GET',
            signal: AbortSignal.timeout(5000)
        });

        if (response.ok) {
            const data = await response.json();
            // Backend อาจส่ง version กลับมา
            return data.version || null;
        }
    } catch (e) {
        console.log('ไม่สามารถตรวจสอบจาก backend:', e.message);
    }

    try {
        // วิธีที่ 2: ตรวจสอบจากไฟล์ version.json ใน extension
        const response = await fetch(chrome.runtime.getURL('version.json'), {
            method: 'GET'
        });

        if (response.ok) {
            const data = await response.json();
            return data.version;
        }
    } catch (e) {
        console.log('ไม่สามารถตรวจสอบจาก version.json:', e.message);
    }

    return null;
}

// ตรวจสอบว่า version ใหม่กว่าไหม
function isVersionNewer(latestVersion, currentVersion) {
    try {
        const latest = latestVersion.split('.').map(Number);
        const current = currentVersion.split('.').map(Number);

        for (let i = 0; i < Math.max(latest.length, current.length); i++) {
            const l = latest[i] || 0;
            const c = current[i] || 0;

            if (l > c) return true;
            if (l < c) return false;
        }

        return false; // เวอร์ชันเท่ากัน
    } catch (e) {
        console.error('Error comparing versions:', e);
        return false;
    }
}

// ดำเนินการอัปเดท
async function performUpdate() {
    const updateBtn = document.getElementById('updateBtn');

    // ปิดปุ่มอัปเดทชั่วคราว
    updateBtn.disabled = true;
    updateBtn.textContent = 'กำลังอัปเดท...';

    try {
        // รีโหลด extension
        chrome.runtime.reload();

        // หรือแสดงข้อความให้ผู้ใช้ refresh เอง
        alert('Extension ถูกอัปเดทแล้ว!\n\nกรุณาปิดและเปิด popup ใหม่ หรือ refresh หน้าเว็บนี้');

        // ซ่อน notification
        document.getElementById('updateNotification').style.display = 'none';

    } catch (e) {
        console.error('Update failed:', e);
        alert('เกิดข้อผิดพลาดในการอัปเดท: ' + e.message);

        // เปิดปุ่มกลับ
        updateBtn.disabled = false;
        updateBtn.textContent = 'อัปเดทเลย';
    }
}

// แยกโดเมนออกจาก URL
function extractDomain(url) {
    try {
        const urlObj = new URL(url);
        return urlObj.hostname.replace('www.', '');
    } catch (e) {
        // ถ้าไม่ใช่ URL ที่สมบูรณ์ ให้ลองแยกเอง
        return url.replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0].split('?')[0];
    }
}

// ฟังก์ชันตรวจสอบ URL ด้วย Backend
async function checkUrlWithBackend(url) {
    const checkBtn = document.getElementById('checkBtn');
    const loading = document.getElementById('loading');
    const result = document.getElementById('result');
    const error = document.getElementById('error');

    // ซ่อนผลลัพธ์เก่า
    result.style.display = 'none';
    error.style.display = 'none';

    // แสดง loading
    loading.style.display = 'block';
    checkBtn.disabled = true;

    try {
        // ตรวจสอบว่า backend รันอยู่หรือไม่
        const isBackendOnline = await checkBackendHealth();
        if (!isBackendOnline) {
            throw new Error(`Backend server ไม่ได้รันอยู่\n\nกรุณา:\n1. รัน backend server ด้วยคำสั่ง: python app.py\n2. ตรวจสอบว่า backend URL ถูกต้อง: ${backendUrl}\n3. ตรวจสอบว่า backend รันที่ port 5000\n\nหรือตั้งค่า backend URL ใน Options`);
        }

        // ส่ง URL ไปให้ backend วิเคราะห์
        const endpoint = backendUrl.replace(/\/+$/, '') + '/fsd/api/check';
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ url: url })
        });

        if (!response.ok) {
            const text = await response.text();
            throw new Error(`Backend error: ${response.status} ${text}`);
        }

        const data = await response.json();

        // แสดงผลลัพธ์จาก backend
        displayBackendResult(data);

    } catch (err) {
        console.error('Error checking URL with backend:', err);

        // แสดง error message ที่ชัดเจนขึ้น
        let errorMessage = 'เกิดข้อผิดพลาด: ';
        if (err.message.includes('Failed to fetch') || err.message.includes('NetworkError')) {
            errorMessage += 'ไม่สามารถเชื่อมต่อกับ Backend ได้\n\n';
            errorMessage += 'สาเหตุที่เป็นไปได้:\n';
            errorMessage += '• Backend server ไม่ได้รันอยู่\n';
            errorMessage += '• Backend URL ไม่ถูกต้อง\n';
            errorMessage += '• Firewall หรือ antivirus block การเชื่อมต่อ\n\n';
            errorMessage += 'วิธีแก้ไข:\n';
            errorMessage += '1. ตรวจสอบว่า backend server รันอยู่ (ดูที่ terminal)\n';
            errorMessage += '2. ตรวจสอบ backend URL ใน Extension Options\n';
            errorMessage += '3. ตรวจสอบ firewall/antivirus settings';
        } else if (err.message.includes('Backend server ไม่ได้รันอยู่')) {
            errorMessage += err.message;
        } else {
            errorMessage += err.message;
        }

        showError(errorMessage, 'error');
        loading.style.display = 'none';
        checkBtn.disabled = false;
        return;
    }
}

// ฟังก์ชันตรวจสอบว่า backend รันอยู่หรือไม่
async function checkBackendHealth() {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 seconds timeout

        const healthUrl = backendUrl.replace(/\/+$/, '') + '/fsd/health';
        const response = await fetch(healthUrl, {
            method: 'GET',
            signal: controller.signal
        });

        clearTimeout(timeoutId);
        return response.ok;
    } catch (e) {
        return false;
    }
}

// ฟังก์ชันแสดงผลลัพธ์จาก backend
function displayBackendResult(data) {
    const checkBtn = document.getElementById('checkBtn');
    const loading = document.getElementById('loading');
    const result = document.getElementById('result');

    // ซ่อน loading
    loading.style.display = 'none';
    checkBtn.disabled = false;

    // แปลง verdict เป็นภาษาไทย
    const verdictMap = {
        'Safe': '✅ ปลอดภัย',
        'Risky': '⚠️ เสี่ยง',
        'Danger': '❌ อันตราย'
    };

    // แสดงผลลัพธ์
    document.getElementById('score').textContent = (data.trust_score || data.riskScore || 0) + '/100';
    document.getElementById('verdict').textContent = verdictMap[data.verdict] || data.verdict || 'ไม่ทราบ';

    const detailsList = document.getElementById('detailsList');
    detailsList.innerHTML = '';

    // แสดงรายละเอียด
    const details = data.details || data.warnings || [];
    if (details.length > 0) {
        details.forEach(detail => {
            const li = document.createElement('li');
            li.textContent = '• ' + detail;
            detailsList.appendChild(li);
        });
    } else {
        const li = document.createElement('li');
        li.textContent = '• ไม่พบปัญหาที่ตรวจพบ';
        detailsList.appendChild(li);
    }

    // เปลี่ยนสีตาม verdict
    let resultClass = 'safe';
    if (data.verdict === 'Risky' || data.verdict === 'warn') resultClass = 'risky';
    if (data.verdict === 'Danger' || data.verdict === 'danger') resultClass = 'danger';

    result.className = 'result ' + resultClass;
    result.style.display = 'block';
}

// ฟังก์ชันแสดง error อย่างสวยงาม
function showError(message, type = 'error') {
    const error = document.getElementById('error');
    error.textContent = message;
    error.className = 'error ' + type;
    error.style.display = 'block';
}