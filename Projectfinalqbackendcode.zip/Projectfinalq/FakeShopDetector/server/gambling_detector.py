"""
Gambling Website Detector Module
ตรวจสอบเว็บไซต์ว่ามีเนื้อหาหรือข้อความที่เกี่ยวข้องกับการพนัน
รวมถึงการตรวจสอบรูปภาพด้วย OCR
"""

import re
from urllib.parse import urlparse, urljoin
from typing import Dict, List, Tuple, Optional
import requests
from io import BytesIO

# Try to import BeautifulSoup (optional dependency)
try:
    from bs4 import BeautifulSoup
    BS4_AVAILABLE = True
except ImportError:
    BS4_AVAILABLE = False
    print("Warning: beautifulsoup4 not installed. Image URL extraction will use basic regex.")

# Try to import OCR libraries (optional dependencies)
try:
    import easyocr
    OCR_AVAILABLE = True
except ImportError:
    OCR_AVAILABLE = False
    print("Warning: easyocr not installed. Image OCR detection will be disabled.")

try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    print("Warning: Pillow not installed. Image processing will be limited.")

# Try to import BeautifulSoup
try:
    from bs4 import BeautifulSoup
    BS4_AVAILABLE = True
except ImportError:
    BS4_AVAILABLE = False
    print("Warning: beautifulsoup4 not installed. Image URL extraction will be disabled.")

# ============================================
# Gambling Keywords & Patterns
# ============================================

# Keywords ภาษาไทยที่เกี่ยวข้องกับการพนัน
THAI_GAMBLING_KEYWORDS = [
    # การพนันทั่วไป
    'พนัน', 'เดิมพัน', 'แทง', 'แทงบอล', 'แทงม้า', 'แทงหวย',
    'บาคาร่า', 'สล็อต', 'คาสิโน', 'รูเล็ต', 'ไพ่', 'โป๊กเกอร์',
    'เกมส์คาสิโน', 'เกมคาสิโน', 'เกมส์พนัน', 'เกมพนัน',
    
    # คำที่เกี่ยวข้องกับการเดิมพัน
    'เดิมพันออนไลน์', 'พนันออนไลน์', 'แทงออนไลน์',
    'เว็บพนัน', 'เว็บเดิมพัน', 'เว็บแทง', 'เว็บคาสิโน',
    'เว็บไซต์พนัน', 'เว็บไซต์เดิมพัน',
    
    # คำโปรโมชั่น
    'สมัคร', 'สมัครสมาชิก', 'ฝากเงิน', 'ถอนเงิน', 'ฝากถอน',
    'โปรโมชั่น', 'โบนัส', 'โบนัสพิเศษ', 'เงินรางวัล', 'รางวัล',
    'รวย', 'ลุ้นรางวัล', 'ลุ้น', 'รางวัลใหญ่',
    
    # คำเฉพาะเจาะจง
    'ยูฟ่า', 'ufa', 'ufabet', 'gclub', 'g club', 'sa gaming',
    'sbobet', 'ibcbet', 'maxbet', 'm8bet', 'pragmatic play',
    'sexy gaming', 'evoplay', 'joker gaming', 'pg slot',
    'jili', 'wm casino', 'allbet', 'pretty gaming',
    
    # เกมส์เฉพาะ
    'เกมส์สล็อต', 'เกมสล็อต', 'slot', 'สล็อตออนไลน์',
    'บอลออนไลน์', 'ฟุตบอลออนไลน์', 'ดูบอลสด',
    'แจ็คพอต', 'แจคพอต', 'jackpot', 'สลากกินแบ่ง',
    
    # คำที่ใช้ในโฆษณา
    'ถอนได้ไม่จำกัด', 'ฝากถอนออโต้', 'ฝากถอนเร็ว',
    'ไม่มีขั้นต่ำ', 'ได้เงินจริง', 'ถอนง่าย',
    'โปรโมชั่นพิเศษ', 'โบนัสต้อนรับ', 'โบนัสสมาชิกใหม่'
]

# Keywords ภาษาอังกฤษที่เกี่ยวข้องกับการพนัน
ENGLISH_GAMBLING_KEYWORDS = [
    # General gambling
    'gambling', 'betting', 'casino', 'poker', 'roulette',
    'blackjack', 'baccarat', 'slots', 'slot machine',
    'online casino', 'online betting', 'sports betting',
    'live casino', 'jackpot', 'lottery',
    
    # Betting platforms
    'bet', 'wager', 'stake', 'odds', 'bookmaker',
    'betting site', 'casino site', 'gambling site',
    
    # Promotions
    'bonus', 'promotion', 'promo', 'reward', 'prize',
    'sign up', 'register', 'deposit', 'withdraw',
    'welcome bonus', 'free bet', 'cashback',
    
    # Specific brands (partial matches for domain detection)
    'ufabet', 'sbobet', 'ibcbet', 'maxbet', 'bet365',
    'pragmatic', 'pg slot', 'joker', 'gclub'
]

# Domain patterns ที่บ่งชี้ว่าเป็นเว็บพนัน
GAMBLING_DOMAIN_PATTERNS = [
    r'ufa.*',
    r'.*bet.*',
    r'.*casino.*',
    r'.*slot.*',
    r'.*poker.*',
    r'.*gambling.*',
    r'.*gclub.*',
    r'.*g-club.*',
    r'[0-9]{3,}.*',  # ตัวเลขหลายตัว (เช่น 666, 888)
]

# Meta keywords และ title patterns
GAMBLING_META_PATTERNS = [
    r'casino.*online',
    r'online.*casino',
    r'sports.*betting',
    r'betting.*site',
    r'gambling.*site',
    r'.*slot.*machine.*',
    r'.*poker.*online.*',
]

# Banner/Ad text patterns (จากที่เห็นในรูปภาพ)
BANNER_PATTERNS = [
    r'สมัคร.*คลิก',
    r'สมัครสมาชิก.*',
    r'ฝากถอน.*ออโต้',
    r'ถอน.*บาท',
    r'โบนัส.*',
    r'โปรโมชั่น.*',
    r'รวย.*',
    r'ลุ้นรางวัล.*',
    r'ได้เงิน.*',
    r'register.*click',
    r'sign.*up.*now',
    r'deposit.*withdraw',
    r'welcome.*bonus',
    r'free.*bet',
]

# Keywords ที่สำคัญมากสำหรับตรวจสอบในรูปภาพ (banner keywords)
IMAGE_GAMBLING_KEYWORDS = [
    # คำสำคัญที่พบใน banner
    'เดิมพัน',
    'แทง',
    'บิด',
    '666',
    '888',
    '777',
    # เพิ่มคำอื่นๆ ที่สำคัญ
    'สมัคร',
    'โบนัส',
    'คาสิโน',
    'สล็อต',
]


# ============================================
# Content Extraction Functions
# ============================================

def extract_text_content(html_content: str) -> Dict[str, str]:
    """
    ดึงข้อความสำคัญจาก HTML content
    Returns: dict with 'title', 'meta_description', 'body_text', 'all_text'
    """
    if not html_content:
        return {
            'title': '',
            'meta_description': '',
            'body_text': '',
            'all_text': ''
        }
    
    text_content = {
        'title': '',
        'meta_description': '',
        'body_text': '',
        'all_text': ''
    }
    
    try:
        # Extract title
        title_match = re.search(r'<title[^>]*>(.*?)</title>', html_content, re.IGNORECASE | re.DOTALL)
        if title_match:
            text_content['title'] = re.sub(r'<[^>]+>', '', title_match.group(1)).strip()
        
        # Extract meta description
        meta_match = re.search(r'<meta[^>]*name=["\']description["\'][^>]*content=["\']([^"\']*)["\']', 
                              html_content, re.IGNORECASE)
        if meta_match:
            text_content['meta_description'] = meta_match.group(1).strip()
        
        # Extract body text (remove scripts and styles)
        body_match = re.search(r'<body[^>]*>(.*?)</body>', html_content, re.IGNORECASE | re.DOTALL)
        if body_match:
            body_html = body_match.group(1)
            # Remove script and style tags
            body_html = re.sub(r'<script[^>]*>.*?</script>', '', body_html, flags=re.IGNORECASE | re.DOTALL)
            body_html = re.sub(r'<style[^>]*>.*?</style>', '', body_html, flags=re.IGNORECASE | re.DOTALL)
            # Extract text
            text_content['body_text'] = re.sub(r'<[^>]+>', ' ', body_html).strip()
        
        # Combine all text
        text_content['all_text'] = ' '.join([
            text_content['title'],
            text_content['meta_description'],
            text_content['body_text']
        ]).lower()
        
    except Exception as e:
        print(f"Error extracting text content: {e}")
    
    return text_content


# ============================================
# Image OCR Functions
# ============================================

def check_image_url_for_gambling(image_url: str) -> Tuple[bool, List[str]]:
    """
    ตรวจสอบ URL ของรูปภาพว่าบ่งชี้ว่าเป็นเว็บพนันหรือไม่
    (เร็วกว่า OCR มาก - ไม่ต้อง download หรือ OCR)
    Returns: (is_gambling_banner, matched_keywords)
    """
    url_lower = image_url.lower()
    matched_keywords = []
    
    # ตรวจสอบ keywords ใน URL หรือ filename
    gambling_url_keywords = [
        'bet', 'casino', 'slot', 'gambling', 'poker', 'ufa', 'gclub',
        'เดิมพัน', 'แทง', 'พนัน', 'คาสิโน', 'สล็อต',
        '666', '888', '777', 'promo', 'bonus', 'jackpot'
    ]
    
    for keyword in gambling_url_keywords:
        if keyword.lower() in url_lower:
            matched_keywords.append(keyword)
    
    # ถ้าพบ keywords แสดงว่าเป็น banner การพนัน
    is_gambling = len(matched_keywords) >= 1
    
    return is_gambling, matched_keywords

def extract_image_urls(html_content: str, base_url: str) -> List[str]:
    """
    ดึง URL ของรูปภาพทั้งหมดจาก HTML
    Returns: list of image URLs
    """
    image_urls = []
    if not html_content:
        return image_urls
    
    try:
        if BS4_AVAILABLE:
            # ใช้ BeautifulSoup (แม่นยำกว่า)
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # หา tag img ทั้งหมด
            img_tags = soup.find_all('img')
            for img in img_tags:
                src = img.get('src') or img.get('data-src') or img.get('data-lazy-src')
                if src:
                    # แปลง relative URL เป็น absolute URL
                    absolute_url = urljoin(base_url, src)
                    image_urls.append(absolute_url)
            
            # หา background images จาก style attributes
            for element in soup.find_all(style=re.compile(r'background.*image')):
                style = element.get('style', '')
                url_match = re.search(r'url\(["\']?([^"\')]+)["\']?\)', style)
                if url_match:
                    absolute_url = urljoin(base_url, url_match.group(1))
                    image_urls.append(absolute_url)
        else:
            # ใช้ regex แทน (ถ้าไม่มี BeautifulSoup)
            # หา img tags
            img_pattern = r'<img[^>]+(?:src|data-src|data-lazy-src)=["\']([^"\']+)["\']'
            img_matches = re.findall(img_pattern, html_content, re.IGNORECASE)
            for src in img_matches:
                absolute_url = urljoin(base_url, src)
                image_urls.append(absolute_url)
            
            # หา background images
            bg_pattern = r'background[^:]*:\s*url\(["\']?([^"\')]+)["\']?\)'
            bg_matches = re.findall(bg_pattern, html_content, re.IGNORECASE)
            for bg_url in bg_matches:
                absolute_url = urljoin(base_url, bg_url)
                image_urls.append(absolute_url)
        
        # จำกัดจำนวนรูปที่ตรวจสอบ (เพื่อประสิทธิภาพ)
        return image_urls[:20]  # ตรวจสอบสูงสุด 20 รูป
    
    except Exception as e:
        print(f"Error extracting image URLs: {e}")
        return []


def download_image(image_url: str) -> Optional[BytesIO]:
    """
    Download รูปภาพจาก URL
    Returns: BytesIO object หรือ None ถ้าไม่สามารถ download ได้
    """
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        response = requests.get(image_url, headers=headers, timeout=3, stream=True)
        if response.status_code == 200:
            # ตรวจสอบว่าเป็นรูปภาพหรือไม่
            content_type = response.headers.get('content-type', '')
            if 'image' in content_type:
                return BytesIO(response.content)
    except Exception as e:
        print(f"Error downloading image {image_url}: {e}")
    return None


# Global OCR reader (initialize once, reuse many times)
_ocr_reader = None

def get_ocr_reader():
    """Get or initialize OCR reader (singleton pattern)"""
    global _ocr_reader
    if _ocr_reader is None and OCR_AVAILABLE:
        try:
            print("Initializing EasyOCR reader (first time only, this may take a moment)...")
            _ocr_reader = easyocr.Reader(['th', 'en'], gpu=False, verbose=False)
            print("EasyOCR reader initialized successfully.")
        except Exception as e:
            print(f"Error initializing OCR reader: {e}")
            return None
    return _ocr_reader

def ocr_image(image_data: BytesIO) -> str:
    """
    ใช้ OCR เพื่ออ่านข้อความจากรูปภาพ
    Returns: ข้อความที่อ่านได้
    """
    if not OCR_AVAILABLE:
        return ""
    
    try:
        reader = get_ocr_reader()
        if not reader:
            return ""
        
        # Read text from image
        results = reader.readtext(image_data.getvalue())
        
        # รวมข้อความทั้งหมด
        text = ' '.join([result[1] for result in results])
        return text
    
    except Exception as e:
        print(f"Error in OCR: {e}")
        return ""


def check_image_for_gambling_keywords(image_url: str) -> Tuple[bool, List[str]]:
    """
    ตรวจสอบรูปภาพว่ามี keywords ที่เกี่ยวข้องกับการพนันหรือไม่
    Returns: (is_gambling_banner, matched_keywords)
    """
    if not OCR_AVAILABLE:
        return False, []
    
    try:
        # Download image
        image_data = download_image(image_url)
        if not image_data:
            return False, []
        
        # OCR
        ocr_text = ocr_image(image_data)
        if not ocr_text:
            return False, []
        
        ocr_text_lower = ocr_text.lower()
        matched_keywords = []
        
        # ตรวจสอบ keywords สำคัญ
        for keyword in IMAGE_GAMBLING_KEYWORDS:
            if keyword.lower() in ocr_text_lower:
                matched_keywords.append(keyword)
        
        # ถ้าพบ keywords สำคัญ (เดิมพัน, แทง, บิด, 666, 888, 777) แสดงว่าเป็น banner การพนันแน่นอน
        critical_keywords = ['เดิมพัน', 'แทง', 'บิด', '666', '888', '777']
        is_critical = any(keyword.lower() in ocr_text_lower for keyword in critical_keywords)
        
        return is_critical or len(matched_keywords) >= 2, matched_keywords
    
    except Exception as e:
        print(f"Error checking image {image_url}: {e}")
        return False, []


def scan_images_for_gambling(html_content: str, base_url: str, use_ocr: bool = False) -> Dict:
    """
    สแกนรูปภาพทั้งหมดในเว็บไซต์เพื่อหาข้อความการพนัน
    
    Args:
        html_content: HTML content
        base_url: Base URL for resolving relative paths
        use_ocr: ถ้า True จะใช้ OCR (ช้า แต่แม่นยำ), ถ้า False จะตรวจสอบแค่ URL (เร็ว)
    
    Returns: {
        'found_gambling_images': bool,
        'gambling_image_count': int,
        'total_images_scanned': int,
        'matched_keywords': list,
        'details': list
    }
    """
    result = {
        'found_gambling_images': False,
        'gambling_image_count': 0,
        'total_images_scanned': 0,
        'matched_keywords': [],
        'details': []
    }
    
    try:
        # ดึง URL ของรูปภาพทั้งหมด
        image_urls = extract_image_urls(html_content, base_url)
        result['total_images_scanned'] = len(image_urls)
        
        if not image_urls:
            return result
        
        all_matched_keywords = []
        gambling_images = []
        
        # ขั้นตอนที่ 1: ตรวจสอบ URL ของรูปภาพ (เร็วมาก - ไม่ต้องใช้ OCR)
        for img_url in image_urls:
            is_gambling_url, matched_url = check_image_url_for_gambling(img_url)
            if is_gambling_url:
                result['gambling_image_count'] += 1
                gambling_images.append(img_url)
                all_matched_keywords.extend(matched_url)
        
        # ขั้นตอนที่ 2: ถ้าเปิดใช้ OCR และยังไม่พบอะไร ให้ลอง OCR (ช้ากว่า แต่แม่นยำกว่า)
        if use_ocr and OCR_AVAILABLE and result['gambling_image_count'] == 0:
            # ตรวจสอบแค่รูปแรกๆ เพื่อความเร็ว (สูงสุด 5 รูป)
            for img_url in image_urls[:5]:
                is_gambling, matched = check_image_for_gambling_keywords(img_url)
                if is_gambling:
                    result['gambling_image_count'] += 1
                    gambling_images.append(img_url)
                    all_matched_keywords.extend(matched)
                    # ถ้าพบแล้ว ให้หยุด (เพื่อความเร็ว)
                    break
        
        result['matched_keywords'] = list(set(all_matched_keywords))
        result['found_gambling_images'] = result['gambling_image_count'] > 0
        
        if result['found_gambling_images']:
            result['details'].append(
                f"❌ พบรูปภาพที่น่าสงสัย {result['gambling_image_count']} รูป (ตรวจสอบ {result['total_images_scanned']} รูป)"
            )
            if result['matched_keywords']:
                result['details'].append(
                    f"⚠️ พบคำสำคัญใน URL รูปภาพ: {', '.join(result['matched_keywords'][:5])}"
                )
    
    except Exception as e:
        print(f"Error scanning images: {e}")
        result['details'].append("⚠️ เกิดข้อผิดพลาดในการสแกนรูปภาพ")
    
    return result


# ============================================
# Detection Functions
# ============================================

def check_gambling_keywords(text: str) -> Tuple[int, List[str]]:
    """
    ตรวจสอบว่ามี keywords ที่เกี่ยวข้องกับการพนันหรือไม่
    Returns: (count, matched_keywords)
    """
    text_lower = text.lower()
    matched_keywords = []
    count = 0
    
    # ตรวจสอบ keywords ภาษาไทย
    for keyword in THAI_GAMBLING_KEYWORDS:
        if keyword.lower() in text_lower:
            matched_keywords.append(keyword)
            count += 1
    
    # ตรวจสอบ keywords ภาษาอังกฤษ
    for keyword in ENGLISH_GAMBLING_KEYWORDS:
        if keyword.lower() in text_lower:
            matched_keywords.append(keyword)
            count += 1
    
    return count, list(set(matched_keywords))  # Remove duplicates


def check_domain_gambling_patterns(domain: str) -> Tuple[bool, List[str]]:
    """
    ตรวจสอบว่า domain มีรูปแบบที่บ่งชี้ว่าเป็นเว็บพนันหรือไม่
    Returns: (is_gambling, matched_patterns)
    """
    domain_lower = domain.lower()
    matched_patterns = []
    is_gambling = False
    
    for pattern in GAMBLING_DOMAIN_PATTERNS:
        if re.search(pattern, domain_lower, re.IGNORECASE):
            matched_patterns.append(pattern)
            is_gambling = True
    
    return is_gambling, matched_patterns


def check_banner_patterns(text: str) -> Tuple[int, List[str]]:
    """
    ตรวจสอบข้อความใน banner/advertisement
    Returns: (count, matched_patterns)
    """
    text_lower = text.lower()
    matched_patterns = []
    count = 0
    
    for pattern in BANNER_PATTERNS:
        if re.search(pattern, text_lower, re.IGNORECASE):
            matched_patterns.append(pattern)
            count += 1
    
    return count, matched_patterns


def analyze_gambling_content(html_content: str, domain: str, base_url: str = None) -> Dict:
    """
    วิเคราะห์เนื้อหาเว็บไซต์ว่ามีการพนันหรือไม่
    Returns: {
        'is_gambling': bool,
        'gambling_score': int (0-100),
        'confidence': float,
        'details': list,
        'matched_keywords': list,
        'domain_suspicious': bool,
        'banner_count': int
    }
    """
    result = {
        'is_gambling': False,
        'gambling_score': 0,  # 0 = ไม่มี, 100 = มีแน่นอน
        'confidence': 0.0,
        'details': [],
        'matched_keywords': [],
        'domain_suspicious': False,
        'banner_count': 0,
        'keyword_count': 0
    }
    
    # 1. ตรวจสอบ domain patterns
    domain_suspicious, domain_patterns = check_domain_gambling_patterns(domain)
    result['domain_suspicious'] = domain_suspicious
    if domain_suspicious:
        result['gambling_score'] += 30
        result['details'].append(f"⚠️ โดเมนมีรูปแบบที่น่าสงสัย: {', '.join(domain_patterns[:3])}")
    
    # 2. Extract และตรวจสอบ text content
    if html_content:
        text_content = extract_text_content(html_content)
        
        # ตรวจสอบ keywords ในเนื้อหา
        keyword_count, matched_keywords = check_gambling_keywords(text_content['all_text'])
        result['keyword_count'] = keyword_count
        result['matched_keywords'] = matched_keywords[:10]  # เก็บแค่ 10 ตัวแรก
        
        # คำนวณคะแนนจาก keywords
        if keyword_count > 0:
            # ยิ่งมี keywords มาก ยิ่งได้คะแนนมาก
            keyword_score = min(50, keyword_count * 5)  # สูงสุด 50 คะแนน
            result['gambling_score'] += keyword_score
            
            if keyword_count >= 5:
                result['details'].append(f"⚠️ พบคำที่เกี่ยวข้องกับการพนัน {keyword_count} คำ: {', '.join(matched_keywords[:5])}")
            elif keyword_count >= 3:
                result['details'].append(f"⚠️ พบคำที่เกี่ยวข้องกับการพนัน {keyword_count} คำ")
            else:
                result['details'].append(f"⚠️ พบคำที่เกี่ยวข้องกับการพนันบ้าง")
        
        # ตรวจสอบ banner patterns
        banner_count, banner_patterns = check_banner_patterns(text_content['all_text'])
        result['banner_count'] = banner_count
        if banner_count > 0:
            banner_score = min(20, banner_count * 5)  # สูงสุด 20 คะแนน
            result['gambling_score'] += banner_score
            result['details'].append(f"⚠️ พบข้อความในโฆษณา/แบนเนอร์ {banner_count} รูปแบบ")
        
        # ตรวจสอบ title และ meta
        if text_content['title']:
            title_keywords, _ = check_gambling_keywords(text_content['title'])
            if title_keywords > 0:
                result['gambling_score'] += 15
                result['details'].append(f"⚠️ Title มีคำที่เกี่ยวข้องกับการพนัน")
        
        if text_content['meta_description']:
            meta_keywords, _ = check_gambling_keywords(text_content['meta_description'])
            if meta_keywords > 0:
                result['gambling_score'] += 10
                result['details'].append(f"⚠️ Meta description มีคำที่เกี่ยวข้องกับการพนัน")
    
    # 4. ตรวจสอบรูปภาพ (ใช้การตรวจสอบ URL - เร็วมาก, ไม่ใช้ OCR - ช้า)
    if html_content and base_url:
        try:
            # ตั้งค่า use_ocr=False เพื่อความเร็ว (ตรวจสอบแค่ URL/filename)
            # ตั้งค่า use_ocr=True ถ้าต้องการ OCR (ช้ากว่าแต่แม่นยำกว่า)
            use_ocr = False  # ปิด OCR เป็น default เพื่อความเร็ว
            image_scan_result = scan_images_for_gambling(html_content, base_url, use_ocr=use_ocr)
            
            if image_scan_result['found_gambling_images']:
                # ถ้าพบรูปภาพที่มีข้อความการพนัน ให้เพิ่มคะแนนมาก (เพราะเป็นหลักฐานชัดเจน)
                image_score = 40 + (image_scan_result['gambling_image_count'] * 10)
                result['gambling_score'] += min(50, image_score)  # สูงสุด 50 คะแนน
                result['details'].extend(image_scan_result['details'])
                
                # ถ้าพบ critical keywords (เดิมพัน, แทง, บิด, 666, 888, 777) ในรูปภาพ
                # ให้มั่นใจว่านี่คือเว็บพนันแน่นอน
                critical_found = any(keyword in image_scan_result['matched_keywords'] 
                                    for keyword in ['เดิมพัน', 'แทง', 'บิด', '666', '888', '777'])
                if critical_found:
                    result['gambling_score'] = 100  # ให้คะแนนเต็ม (แน่นอนว่าเป็นเว็บพนัน)
                    result['details'].append("❌ พบข้อความสำคัญในรูปภาพ (เดิมพัน/แทง/บิด/666/888/777) - รับประกันว่าเป็นเว็บพนัน")
        except Exception as e:
            print(f"Error in image scanning: {e}")
            result['details'].append("⚠️ ไม่สามารถตรวจสอบรูปภาพได้")
    
    # คำนวณ confidence
    result['gambling_score'] = min(100, result['gambling_score'])
    
    if result['gambling_score'] >= 50:
        result['is_gambling'] = True
        result['confidence'] = min(1.0, result['gambling_score'] / 100.0)
    elif result['gambling_score'] >= 30:
        result['confidence'] = result['gambling_score'] / 100.0
    else:
        result['confidence'] = 0.0
    
    return result


# ============================================
# Main Detection Function
# ============================================

def detect_gambling_website(url: str, html_content: Optional[str] = None, domain: Optional[str] = None, base_url: Optional[str] = None) -> Dict:
    """
    ฟังก์ชันหลักสำหรับตรวจสอบว่าเว็บไซต์เป็นเว็บพนันหรือไม่
    
    Args:
        url: URL ของเว็บไซต์
        html_content: HTML content (optional, ถ้าไม่มีจะต้อง fetch เอง)
        domain: Domain name (optional, จะ extract จาก URL ถ้าไม่ระบุ)
    
    Returns:
        dict with detection results
    """
    if not domain:
        try:
            parsed = urlparse(url)
            domain = parsed.netloc.replace('www.', '')
        except:
            domain = url
    
    # ใช้ base_url ถ้าไม่ได้ระบุ
    if not base_url:
        base_url = url
    
    # ใช้ html_content ที่ส่งมาหรือ None (จะต้อง fetch เองภายนอก)
    if html_content:
        result = analyze_gambling_content(html_content, domain, base_url)
    else:
        # ถ้าไม่มี HTML content ให้ตรวจสอบแค่ domain
        domain_suspicious, domain_patterns = check_domain_gambling_patterns(domain)
        result = {
            'is_gambling': domain_suspicious,
            'gambling_score': 30 if domain_suspicious else 0,
            'confidence': 0.3 if domain_suspicious else 0.0,
            'details': [f"⚠️ โดเมนมีรูปแบบที่น่าสงสัย"] if domain_suspicious else [],
            'matched_keywords': [],
            'domain_suspicious': domain_suspicious,
            'banner_count': 0,
            'keyword_count': 0
        }
    
    return result
