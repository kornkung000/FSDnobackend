#!/usr/bin/env python3
"""
FSD Backend Server Runner
สคริปต์สำหรับรัน FSD Backend Server พร้อมระบบ License Key
"""
import os
import sys
import subprocess
import argparse
from license import FSDLicenseManager

def main():
    """ฟังก์ชันหลัก"""
    parser = argparse.ArgumentParser(description='FSD Backend Server Runner')
    parser.add_argument('--generate-license', action='store_true',
                       help='สร้าง License Key ใหม่')
    parser.add_argument('--license-days', type=int, default=365,
                       help='จำนวนวันที่ License จะใช้งานได้ (สำหรับ --generate-license)')
    parser.add_argument('--license-info', action='store_true',
                       help='ดูข้อมูล License ปัจจุบัน')
    parser.add_argument('--port', type=int, default=5000,
                       help='Port ที่จะใช้รัน server')
    parser.add_argument('--host', default='127.0.0.1',
                       help='Host ที่จะใช้รัน server')
    parser.add_argument('--license-key', type=str,
                       help='License Key ที่จะใช้ (ไม่ต้องพิมพ์ซ้ำ)')

    args = parser.parse_args()

    # จัดการ License
    license_manager = FSDLicenseManager()

    if args.generate_license:
        print("[+] Generating new License Key...")
        key, info = license_manager.generate_license_key(args.license_days)
        print("[OK] License Key created successfully!")
        print(f"[KEY] License Key: {key}")
        print(f"[INFO] Validity: {args.license_days} days")
        print(f"[INFO] Expires: {info['expires_at']}")
        print("\n[WARNING] Keep this License Key secure!")
        print("          If lost, it cannot be recovered")
        print("\n[TIP] How to use:")
        print("   python run_fsd_server.py --license-key YOUR_KEY_HERE")
        return

    if args.license_info:
        print(license_manager.get_license_info())
        return

    # รัน server
    print("[+] Starting FSD Backend Server...")
    print(f"[INFO] Host: {args.host}")
    print(f"[INFO] Port: {args.port}")

    # เตรียม environment variables
    env = os.environ.copy()
    if args.license_key:
        env['FSD_LICENSE_KEY'] = args.license_key
    env['PORT'] = str(args.port)
    env['HOST'] = args.host

    try:
        # รัน app.py
        subprocess.run([sys.executable, 'app.py'], env=env, check=True)
    except KeyboardInterrupt:
        print("\n\n[STOP] Server stopped")
    except subprocess.CalledProcessError as e:
        print(f"\n[ERROR] Failed to run server: {e}")
        print("\n[CHECK] Verify:")
        print("   - License Key is valid")
        print("   - Port is not used by other programs")
        print("   - All dependencies are installed")
    except FileNotFoundError:
        print("\n[ERROR] app.py file not found")
    except Exception as e:
        print(f"\n[ERROR] An error occurred: {e}")

if __name__ == '__main__':
    main()