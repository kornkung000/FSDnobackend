"""
FakeShop Detector - Main Backend Server
Backend สำหรับตรวจสอบความน่าเชื่อถือของร้านค้าออนไลน์
"""
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import whois
from datetime import datetime
import os
import re
import secrets
import json
import requests
import sys
from gambling_detector import detect_gambling_website
from license import FSDLicenseManager, prompt_license_key

# สร้าง Flask app
app = Flask(__name__, template_folder='templates')
CORS(app)  # อนุญาตให้ extension เรียก API ได้

# กำหนด path ของ template folder
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, 'templates')

# Storage สำหรับ integration tokens (ใน production ควรใช้ database)
INTEGRATIONS = {}
INTEGRATIONS_FILE = os.path.join(BASE_DIR, 'integrations.json')

# โหลด integrations จากไฟล์
def load_integrations():
    global INTEGRATIONS
    if os.path.exists(INTEGRATIONS_FILE):
        try:
            with open(INTEGRATIONS_FILE, 'r', encoding='utf-8') as f:
                INTEGRATIONS = json.load(f)
        except:
            INTEGRATIONS = {}

# บันทึก integrations ลงไฟล์
def save_integrations():
    try:
        with open(INTEGRATIONS_FILE, 'w', encoding='utf-8') as f:
            json.dump(INTEGRATIONS, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"Error saving integrations: {e}")

# โหลด integrations ตอนเริ่มต้น
load_integrations()

# ============================================
# Routes สำหรับ Web Interface
# ============================================

@app.route('/')
@app.route('/fsd')
@app.route('/FSD')
def index():
    """หน้าแรกสำหรับแสดงเว็บอินเทอร์เฟซ"""
    return render_template('index.html')

@app.route('/health')
@app.route('/fsd/health')
@app.route('/FSD/health')
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'online',
        'service': 'FSD - FakeShop Detector',
        'version': '1.0.0',
        'timestamp': datetime.now().isoformat()
    })

# ============================================
# Integration & Webhook Endpoints
# ============================================

@app.route('/api/integration/create', methods=['POST'])
@app.route('/fsd/api/integration/create', methods=['POST'])
@app.route('/FSD/api/integration/create', methods=['POST'])
def create_integration():
    """
    สร้าง Integration URL สำหรับเชื่อมต่อกับ backend อื่น
    Request: {"name": "My Backend", "callback_url": "https://your-backend.com/webhook"}
    Response: {"integration_url": "...", "token": "...", "api_key": "..."}
    """
    try:
        data = request.get_json() or {}
        name = data.get('name', 'Unnamed Integration')
        callback_url = data.get('callback_url', '')
        description = data.get('description', '')
        
        # สร้าง token และ API key
        token = secrets.token_urlsafe(32)
        api_key = secrets.token_urlsafe(32)
        
        # เก็บข้อมูล integration
        INTEGRATIONS[token] = {
            'name': name,
            'description': description,
            'callback_url': callback_url,
            'api_key': api_key,
            'created_at': datetime.now().isoformat(),
            'last_used': None,
            'usage_count': 0
        }
        
        save_integrations()
        
        # สร้าง integration URL (ใช้ FSD prefix)
        base_url = request.host_url.rstrip('/')
        integration_url = f"{base_url}/fsd/api/integration/{token}"
        webhook_url = f"{base_url}/fsd/api/webhook/{token}"
        
        return jsonify({
            'success': True,
            'integration_url': integration_url,
            'webhook_url': webhook_url,
            'token': token,
            'api_key': api_key,
            'callback_url': callback_url,
            'message': 'Integration created successfully',
            'endpoints': {
                'check_url': f"{base_url}/fsd/api/check",
                'analyze_url': f"{base_url}/fsd/api/analyze",
                'webhook_url': webhook_url,
                'integration_info': integration_url
            }
        }), 201
    
    except Exception as e:
        return jsonify({
            "error": f"Error creating integration: {str(e)}"
        }), 500

@app.route('/api/integration/<token>', methods=['GET'])
@app.route('/fsd/api/integration/<token>', methods=['GET'])
@app.route('/FSD/api/integration/<token>', methods=['GET'])
def get_integration_info(token):
    """ดูข้อมูล integration"""
    if token not in INTEGRATIONS:
        return jsonify({"error": "Integration not found"}), 404
    
    integration = INTEGRATIONS[token].copy()
    # ไม่ส่ง API key กลับ (เพื่อความปลอดภัย)
    integration.pop('api_key', None)
    
    base_url = request.host_url.rstrip('/')
    
    return jsonify({
        'integration': integration,
        'endpoints': {
            'check_url': f"{base_url}/fsd/api/check",
            'analyze_url': f"{base_url}/fsd/api/analyze",
            'webhook_url': f"{base_url}/fsd/api/webhook/{token}",
            'integration_info': f"{base_url}/fsd/api/integration/{token}"
        }
    })

@app.route('/api/integration/<token>', methods=['DELETE'])
@app.route('/fsd/api/integration/<token>', methods=['DELETE'])
@app.route('/FSD/api/integration/<token>', methods=['DELETE'])
def delete_integration(token):
    """ลบ integration"""
    if token not in INTEGRATIONS:
        return jsonify({"error": "Integration not found"}), 404
    
    del INTEGRATIONS[token]
    save_integrations()
    
    return jsonify({
        'success': True,
        'message': 'Integration deleted successfully'
    })

@app.route('/api/integration/list', methods=['GET'])
@app.route('/fsd/api/integration/list', methods=['GET'])
@app.route('/FSD/api/integration/list', methods=['GET'])
def list_integrations():
    """ดูรายการ integrations ทั้งหมด (ต้องมี API key)"""
    api_key = request.headers.get('X-API-Key')
    if not api_key:
        return jsonify({"error": "API key required"}), 401
    
    # หา integration ที่มี API key นี้
    matching_integrations = []
    for token, integration in INTEGRATIONS.items():
        if integration.get('api_key') == api_key:
            integration_info = integration.copy()
            integration_info.pop('api_key', None)
            integration_info['token'] = token
            matching_integrations.append(integration_info)
    
    if not matching_integrations:
        return jsonify({"error": "Invalid API key"}), 401
    
    return jsonify({
        'integrations': matching_integrations,
        'count': len(matching_integrations)
    })

@app.route('/api/webhook/<token>', methods=['POST'])
@app.route('/fsd/api/webhook/<token>', methods=['POST'])
@app.route('/FSD/api/webhook/<token>', methods=['POST'])
def webhook(token):
    """
    Webhook endpoint สำหรับรับข้อมูลจาก backend อื่น
    และส่งผลลัพธ์กลับไปยัง callback URL (ถ้ามี)
    """
    try:
        if token not in INTEGRATIONS:
            return jsonify({"error": "Invalid token"}), 404
        
        integration = INTEGRATIONS[token]
        data = request.get_json()
        
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        url = data.get('url')
        if not url:
            return jsonify({"error": "URL is required"}), 400
        
        # ตรวจสอบ URL
        domain = extract_domain(url)
        score = 100
        details = []
        warnings = []
        
        # ตรวจสอบอายุโดเมน
        domain_age_result = check_domain_age(domain)
        if domain_age_result:
            age_days = domain_age_result['age_days']
            if age_days < 30:
                score -= 50
                details.append(f"⚠️ โดเมนใหม่มาก (อายุ {age_days} วัน)")
                warnings.append("new_domain")
            elif age_days < 180:
                score -= 20
                details.append(f"⚠️ โดเมนค่อนข้างใหม่ (อายุ {age_days} วัน)")
                warnings.append("new_domain")
            else:
                details.append(f"✅ โดเมนมีอายุ {age_days} วัน - ดูน่าเชื่อถือ")
        else:
            score -= 10
            details.append("⚠️ ไม่สามารถตรวจสอบข้อมูลโดเมนได้")
        
        # ตรวจสอบรูปแบบโดเมน
        domain_pattern_result = check_domain_pattern(domain)
        if domain_pattern_result['suspicious']:
            score -= domain_pattern_result['penalty']
            details.append(domain_pattern_result['reason'])
            warnings.extend(domain_pattern_result['warnings'])
        
        # ตรวจสอบ SSL
        if url.startswith('https://'):
            details.append("✅ มี SSL Certificate (HTTPS)")
        elif url.startswith('http://'):
            score -= 30
            details.append("❌ ไม่มี SSL Certificate (HTTP) - ไม่ปลอดภัย")
            warnings.append("no_ssl")
        
        # คำนวณ verdict
        if score >= 80:
            verdict = "Safe"
        elif score >= 50:
            verdict = "Risky"
        else:
            verdict = "Danger"
        
        result = {
            "domain": domain,
            "url": url,
            "trust_score": max(0, min(100, score)),
            "details": details,
            "warnings": warnings,
            "verdict": verdict,
            "timestamp": datetime.now().isoformat(),
            "integration_token": token
        }
        
        # อัพเดท usage
        INTEGRATIONS[token]['last_used'] = datetime.now().isoformat()
        INTEGRATIONS[token]['usage_count'] = INTEGRATIONS[token].get('usage_count', 0) + 1
        save_integrations()
        
        # ส่งผลลัพธ์กลับไปยัง callback URL (ถ้ามี)
        callback_url = integration.get('callback_url')
        if callback_url:
            try:
                import requests
                requests.post(callback_url, json=result, timeout=5)
            except Exception as e:
                print(f"Error sending to callback: {e}")
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({
            "error": f"Webhook error: {str(e)}"
        }), 500

# ============================================
# API Endpoints
# ============================================

@app.route('/api/check', methods=['POST'])
@app.route('/fsd/api/check', methods=['POST'])
@app.route('/FSD/api/check', methods=['POST'])
def check_url():
    """
    API สำหรับตรวจสอบ URL
    Request: {"url": "https://example.com"}
    Response: {"domain": "...", "trust_score": 100, "details": [...], "verdict": "Safe"}
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        url = data.get('url')
        if not url:
            return jsonify({"error": "URL is required"}), 400
        
        # แยก domain จาก URL
        domain = extract_domain(url)
        
        # เริ่มตรวจสอบ
        score = 100
        details = []
        warnings = []
        
        # 1. ตรวจสอบอายุโดเมน
        domain_age_result = check_domain_age(domain)
        if domain_age_result:
            age_days = domain_age_result['age_days']
            if age_days < 30:
                score -= 50
                details.append(f"⚠️ โดเมนใหม่มาก (อายุ {age_days} วัน)")
                warnings.append("new_domain")
            elif age_days < 180:
                score -= 20
                details.append(f"⚠️ โดเมนค่อนข้างใหม่ (อายุ {age_days} วัน)")
                warnings.append("new_domain")
            else:
                details.append(f"✅ โดเมนมีอายุ {age_days} วัน - ดูน่าเชื่อถือ")
        else:
            score -= 10
            details.append("⚠️ ไม่สามารถตรวจสอบข้อมูลโดเมนได้")
        
        # 2. ตรวจสอบรูปแบบโดเมน
        domain_pattern_result = check_domain_pattern(domain)
        if domain_pattern_result['suspicious']:
            score -= domain_pattern_result['penalty']
            details.append(domain_pattern_result['reason'])
            warnings.extend(domain_pattern_result['warnings'])
        
        # 3. ตรวจสอบเนื้อหาการพนัน (Gambling Detection)
        try:
            html_content = fetch_website_content(url)
            gambling_result = detect_gambling_website(url, html_content, domain, url)
            
            if gambling_result['is_gambling']:
                # ถ้าพบว่าเป็นเว็บพนัน ให้ลดคะแนนมาก
                gambling_penalty = min(60, gambling_result['gambling_score'])
                score -= gambling_penalty
                details.append(f"❌ พบเนื้อหาการพนัน (คะแนนความเสี่ยง: {gambling_result['gambling_score']}/100)")
                warnings.append("gambling_content")
                
                # เพิ่มรายละเอียดเพิ่มเติม
                if gambling_result['keyword_count'] > 0:
                    details.append(f"⚠️ พบคำที่เกี่ยวข้องกับการพนัน {gambling_result['keyword_count']} คำ")
                if gambling_result['banner_count'] > 0:
                    details.append(f"⚠️ พบข้อความในโฆษณาการพนัน")
                if gambling_result['domain_suspicious']:
                    details.append("⚠️ โดเมนมีรูปแบบเว็บพนัน")
            
            elif gambling_result['gambling_score'] >= 30:
                # มีแนวโน้มแต่ไม่แน่ใจ
                score -= 20
                details.append(f"⚠️ พบข้อความที่น่าสงสัยเกี่ยวกับการพนัน")
                warnings.append("possible_gambling")
        except Exception as e:
            print(f"Error in gambling detection: {e}")
            # ถ้าไม่สามารถตรวจสอบได้ ไม่ต้องทำอะไร
        
        # 4. ตรวจสอบ SSL (ถ้ามี URL)
        if url.startswith('https://'):
            details.append("✅ มี SSL Certificate (HTTPS)")
        elif url.startswith('http://'):
            score -= 30
            details.append("❌ ไม่มี SSL Certificate (HTTP) - ไม่ปลอดภัย")
            warnings.append("no_ssl")
        
        # คำนวณ verdict
        if score >= 80:
            verdict = "Safe"
        elif score >= 50:
            verdict = "Risky"
        else:
            verdict = "Danger"
        
        return jsonify({
            "domain": domain,
            "url": url,
            "trust_score": max(0, min(100, score)),
            "details": details,
            "warnings": warnings,
            "verdict": verdict,
            "timestamp": datetime.now().isoformat()
        })
    
    except Exception as e:
        return jsonify({
            "error": f"Server error: {str(e)}"
        }), 500

@app.route('/api/analyze', methods=['POST'])
@app.route('/fsd/api/analyze', methods=['POST'])
@app.route('/FSD/api/analyze', methods=['POST'])
def analyze_url():
    """
    API สำหรับวิเคราะห์ URL แบบละเอียด (compatible กับ extension)
    Request: {"url": "https://example.com"}
    Response: {"domain": "...", "riskScore": 100, "verdict": "safe", ...}
    """
    try:
        data = request.get_json()
        url = data.get('url')
        
        if not url:
            return jsonify({"error": "URL is required"}), 400
        
        # ตรวจสอบ URL format
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        domain = extract_domain(url)
        
        riskScore = 100
        details = []
        categories = []
        
        try:
            # 1. เช็คอายุโดเมน
            domain_info = whois.whois(domain)
            creation_date = domain_info.creation_date
            
            if isinstance(creation_date, list):
                creation_date = creation_date[0]
            
            age_days = (datetime.now() - creation_date).days
            
            if age_days < 30:
                riskScore -= 50
                categories.append("new_domain")
                details.append(f"โดเมนใหม่มาก (อายุ {age_days} วัน)")
            elif age_days < 180:
                riskScore -= 20
                categories.append("new_domain")
                details.append(f"โดเมนค่อนข้างใหม่ (อายุ {age_days} วัน)")
            else:
                details.append(f"โดเมนอายุ {age_days} วัน (น่าเชื่อถือ)")
                
        except Exception as e:
            riskScore -= 10
            categories.append("domain_check_failed")
            details.append(f"ไม่สามารถตรวจสอบข้อมูลโดเมนได้: {str(e)}")
        
        # 2. ตรวจสอบเนื้อหาการพนัน (Gambling Detection)
        try:
            html_content = fetch_website_content(url)
            gambling_result = detect_gambling_website(url, html_content, domain, url)
            
            if gambling_result['is_gambling']:
                # ถ้าพบว่าเป็นเว็บพนัน ให้ลดคะแนนมาก
                gambling_penalty = min(60, gambling_result['gambling_score'])
                riskScore -= gambling_penalty
                categories.append("gambling_content")
                details.append(f"พบเนื้อหาการพนัน (คะแนนความเสี่ยง: {gambling_result['gambling_score']}/100)")
                
                # เพิ่มรายละเอียดเพิ่มเติม
                if gambling_result['keyword_count'] > 0:
                    details.append(f"พบคำที่เกี่ยวข้องกับการพนัน {gambling_result['keyword_count']} คำ")
                if gambling_result['banner_count'] > 0:
                    details.append(f"พบข้อความในโฆษณาการพนัน")
                if gambling_result['domain_suspicious']:
                    details.append("โดเมนมีรูปแบบเว็บพนัน")
            
            elif gambling_result['gambling_score'] >= 30:
                # มีแนวโน้มแต่ไม่แน่ใจ
                riskScore -= 20
                categories.append("possible_gambling")
                details.append(f"พบข้อความที่น่าสงสัยเกี่ยวกับการพนัน")
        except Exception as e:
            print(f"Error in gambling detection: {e}")
            # ถ้าไม่สามารถตรวจสอบได้ ไม่ต้องทำอะไร
        
        # คำนวณ verdict
        if riskScore >= 80:
            verdict = "safe"
        elif riskScore >= 50:
            verdict = "warn"
        else:
            verdict = "danger"
        
        return jsonify({
            "url": url,
            "domain": domain,
            "riskScore": max(0, riskScore),
            "verdict": verdict,
            "categories": categories,
            "details": details
        })
    
    except Exception as e:
        return jsonify({
            "error": f"Analysis error: {str(e)}"
        }), 500

# ============================================
# Helper Functions
# ============================================

def extract_domain(url):
    """แยก domain จาก URL"""
    try:
        # ลบ protocol
        domain = url.replace('https://', '').replace('http://', '')
        # ลบ path, query, fragment
        domain = domain.split('/')[0].split('?')[0].split('#')[0]
        # ลบ www.
        domain = domain.replace('www.', '')
        return domain
    except:
        return url

def check_domain_age(domain):
    """ตรวจสอบอายุโดเมน"""
    try:
        domain_info = whois.whois(domain)
        creation_date = domain_info.creation_date
        
        if not creation_date:
            return None
        
        if isinstance(creation_date, list):
            creation_date = creation_date[0]
        
        age_days = (datetime.now() - creation_date).days
        return {
            'age_days': age_days,
            'creation_date': creation_date.isoformat() if hasattr(creation_date, 'isoformat') else str(creation_date)
        }
    except Exception as e:
        print(f"Error checking domain age: {e}")
        return None

def fetch_website_content(url):
    """
    ดึง HTML content จาก URL (พร้อม error handling)
    Returns: HTML content string หรือ None ถ้าไม่สามารถดึงได้
    """
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=5, allow_redirects=True)
        if response.status_code == 200:
            return response.text
    except Exception as e:
        print(f"Error fetching website content: {e}")
    return None

def check_domain_pattern(domain):
    """ตรวจสอบรูปแบบโดเมนที่น่าสงสัย"""
    result = {
        'suspicious': False,
        'penalty': 0,
        'reason': '',
        'warnings': []
    }
    
    # ตรวจสอบโดเมนยาวผิดปกติ
    if len(domain) > 30:
        result['suspicious'] = True
        result['penalty'] += 10
        result['reason'] = "⚠️ โดเมนยาวผิดปกติ"
        result['warnings'].append("long_domain")
    
    # ตรวจสอบโดเมนสั้นผิดปกติ
    if len(domain) < 5:
        result['suspicious'] = True
        result['penalty'] += 5
        result['reason'] = "⚠️ โดเมนสั้นผิดปกติ"
        result['warnings'].append("short_domain")
    
    # ตรวจสอบตัวเลขมากผิดปกติ
    digit_count = len(re.findall(r'\d', domain))
    if digit_count > len(domain) * 0.5:
        result['suspicious'] = True
        result['penalty'] += 15
        result['reason'] = "⚠️ โดเมนมีตัวเลขมากผิดปกติ"
        result['warnings'].append("too_many_digits")
    
    # ตรวจสอบรูปแบบน่าสงสัย
    suspicious_patterns = [
        (r'^[0-9]+', "ขึ้นต้นด้วยตัวเลข"),
        (r'[0-9]{4,}', "มีตัวเลขหลายตัวติดกัน"),
        (r'(shop|store|buy|sale|deal)[0-9]+', "คำ + ตัวเลข"),
    ]
    
    for pattern, description in suspicious_patterns:
        if re.search(pattern, domain, re.IGNORECASE):
            result['suspicious'] = True
            result['penalty'] += 10
            result['reason'] = f"⚠️ โดเมนมีรูปแบบน่าสงสัย: {description}"
            result['warnings'].append("suspicious_pattern")
            break
    
    return result

# ============================================
# Main
# ============================================

def validate_license_and_run():
    """ตรวจสอบ License Key และรัน server"""
    import sys
    import io

    # แก้ปัญหา encoding สำหรับ Windows console
    if sys.platform == 'win32':
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

    print("=" * 60)
    print("🛡️  FSD - FakeShop Detector Backend Server")
    print("🔐 License Authentication Required")
    print("=" * 60)

    # ตรวจสอบ License Key
    license_manager = FSDLicenseManager()

    # ตรวจสอบว่ามี environment variable FSD_LICENSE_KEY หรือไม่
    license_key = os.environ.get('FSD_LICENSE_KEY')

    if not license_key:
        # ถ้าไม่มี environment variable ให้ถามผู้ใช้
        license_key = prompt_license_key()

    # ตรวจสอบ License Key
    print("🔍 กำลังตรวจสอบ License Key...")
    is_valid, message = license_manager.validate_license(license_key)

    if not is_valid:
        print(message)
        print("\n❌ ไม่สามารถเริ่ม Backend Server ได้")
        print("📞 กรุณาติดต่อผู้พัฒนาเพื่อขอ License Key")
        print("   หรือตรวจสอบ License Key ให้ถูกต้อง")
        sys.exit(1)

    print(message)
    print("=" * 60)

    # License ถูกต้องแล้ว เริ่มรัน server
    # ตรวจสอบ environment variables สำหรับ production
    port = int(os.environ.get('PORT', 5000))
    host = os.environ.get('HOST', '0.0.0.0')
    debug = os.environ.get('DEBUG', 'True').lower() == 'true'

    print("=" * 60)
    print("🛡️  FSD - FakeShop Detector Backend Server")
    print("✅ License ถูกต้อง - กำลังเริ่ม Server...")
    print("=" * 60)
    print(f"🌐 Web Interface: http://{host}:{port}/fsd")
    print(f"📡 API Endpoint: http://{host}:{port}/fsd/api/check")
    print(f"📡 API Endpoint (Legacy): http://{host}:{port}/fsd/api/analyze")
    print(f"💚 Health Check: http://{host}:{port}/fsd/health")
    print("=" * 60)
    print("\n🔗 Integration & Webhook Endpoints:")
    print("POST /fsd/api/integration/create - สร้าง Integration URL")
    print("GET  /fsd/api/integration/<token> - ดูข้อมูล Integration")
    print("POST /fsd/api/webhook/<token> - Webhook endpoint")
    print("GET  /fsd/api/integration/list - ดูรายการ Integrations (ต้องมี API key)")
    print("=" * 60)
    print("\n📝 API Usage:")
    print(f"POST http://{host}:{port}/fsd/api/check")
    print('Body: {"url": "https://example.com"}')
    print("\n📝 Integration Usage:")
    print(f"POST http://{host}:{port}/fsd/api/integration/create")
    print('Body: {"name": "My Backend", "callback_url": "https://your-backend.com/webhook"}')
    print("=" * 60)

    app.run(debug=debug, host=host, port=port)

if __name__ == '__main__':
    validate_license_and_run()
