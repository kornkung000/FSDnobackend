"""
Update Server สำหรับ FakeShop Detector Extension
Server นี้จะ serve ไฟล์ updates.xml และ extension package
"""
from flask import Flask, send_file, send_from_directory, jsonify
import os
from datetime import datetime

app = Flask(__name__)

# กำหนด path ของ extension files
EXTENSION_DIR = os.path.join(os.path.dirname(__file__), '..', 'extension')
UPDATE_MANIFEST = os.path.join(EXTENSION_DIR, 'updates.xml')

@app.route('/extension/updates.xml')
def updates_xml():
    """Serve update manifest file"""
    try:
        return send_file(UPDATE_MANIFEST, mimetype='application/xml')
    except Exception as e:
        return jsonify({'error': str(e)}), 404

@app.route('/extension/version')
def get_version():
    """API สำหรับตรวจสอบเวอร์ชันล่าสุด"""
    try:
        # อ่านเวอร์ชันจาก manifest.json
        manifest_path = os.path.join(EXTENSION_DIR, 'manifest.json')
        if os.path.exists(manifest_path):
            import json
            with open(manifest_path, 'r', encoding='utf-8') as f:
                manifest = json.load(f)
                return jsonify({
                    'version': manifest.get('version', '1.0.0'),
                    'last_updated': datetime.now().isoformat()
                })
        return jsonify({'version': '1.0.0'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/extension/download/<version>')
def download_extension(version):
    """Download extension package (ถ้ามี .crx file)"""
    try:
        crx_file = f'fakeshop-detector-v{version}.crx'
        crx_path = os.path.join(EXTENSION_DIR, crx_file)
        
        if os.path.exists(crx_path):
            return send_file(crx_path, as_attachment=True)
        else:
            return jsonify({'error': 'Extension package not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/extension/status')
def status():
    """Health check endpoint"""
    return jsonify({
        'status': 'online',
        'service': 'FakeShop Detector Update Server',
        'timestamp': datetime.now().isoformat()
    })

if __name__ == '__main__':
    print("=" * 60)
    print("🔄 FakeShop Detector Update Server")
    print("=" * 60)
    print("📡 Update Manifest: http://127.0.0.1:5001/extension/updates.xml")
    print("📦 Version API: http://127.0.0.1:5001/extension/version")
    print("=" * 60)
    app.run(debug=True, host='0.0.0.0', port=5001)
