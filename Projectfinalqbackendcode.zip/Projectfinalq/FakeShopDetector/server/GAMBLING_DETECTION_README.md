# Gambling Detection Feature

## 📋 ภาพรวม

Feature นี้ถูกออกแบบมาเพื่อตรวจจับเว็บไซต์ที่มีเนื้อหาหรือข้อความที่เกี่ยวข้องกับการพนันออนไลน์ โดยจะวิเคราะห์:

1. **Keywords** - คำที่เกี่ยวข้องกับการพนัน (ภาษาไทยและอังกฤษ)
2. **Domain Patterns** - รูปแบบโดเมนที่น่าสงสัย
3. **Banner/Ad Content** - ข้อความในโฆษณาและแบนเนอร์
4. **Meta Tags** - Title และ Meta Description

## 🎯 ฟีเจอร์ที่ตรวจจับ

### 1. Keywords Detection
ระบบจะตรวจสอบคำที่เกี่ยวข้องกับการพนัน เช่น:
- ภาษาไทย: พนัน, แทง, บาคาร่า, สล็อต, คาสิโน, เว็บพนัน, ยูฟ่า, ฝากถอน, โบนัส
- ภาษาอังกฤษ: gambling, betting, casino, poker, slots, online casino

### 2. Domain Pattern Detection
ตรวจสอบรูปแบบโดเมนที่น่าสงสัย เช่น:
- `ufa*`, `*bet*`, `*casino*`, `*slot*`
- ตัวเลขหลายตัว (เช่น 666, 888)

### 3. Banner/Advertisement Detection
ตรวจสอบข้อความในโฆษณาและแบนเนอร์ เช่น:
- "สมัครคลิก", "ฝากถอนออโต้", "โบนัส", "โปรโมชั่น"

## 📊 การให้คะแนน (Scoring System)

### Gambling Score
- **0-29**: ไม่พบการพนันหรือมีแนวโน้มน้อย
- **30-49**: มีแนวโน้ม (Possible Gambling)
- **50-100**: พบเนื้อหาการพนันแน่นอน (Confirmed Gambling)

### Penalty System
- ถ้า `gambling_score >= 50`: ลด trust score ไป **สูงสุด 60 คะแนน**
- ถ้า `gambling_score >= 30`: ลด trust score ไป **20 คะแนน**

## 🔧 การใช้งาน

### ใน API Response

เมื่อเรียกใช้ `/fsd/api/check` หรือ `/fsd/api/analyze` ระบบจะ:

1. ดึง HTML content จาก URL
2. วิเคราะห์เนื้อหาโดยใช้ `gambling_detector.py`
3. เพิ่มผลการตรวจสอบเข้าไปใน details และ warnings

### ตัวอย่าง Response

```json
{
  "domain": "example.com",
  "url": "https://example.com",
  "trust_score": 30,
  "verdict": "Danger",
  "details": [
    "❌ พบเนื้อหาการพนัน (คะแนนความเสี่ยง: 75/100)",
    "⚠️ พบคำที่เกี่ยวข้องกับการพนัน 12 คำ",
    "⚠️ พบข้อความในโฆษณาการพนัน",
    "⚠️ โดเมนมีรูปแบบเว็บพนัน"
  ],
  "warnings": ["gambling_content"]
}
```

## 📁 ไฟล์ที่เกี่ยวข้อง

- `gambling_detector.py` - Module หลักสำหรับการตรวจจับ
- `app.py` - Integration เข้ากับ API endpoints

## 🔍 การปรับแต่ง

### เพิ่ม Keywords ใหม่

แก้ไขไฟล์ `gambling_detector.py`:

```python
THAI_GAMBLING_KEYWORDS = [
    # เพิ่มคำใหม่ที่นี่
    'คำใหม่',
    'อีกคำ',
]
```

### ปรับ Penalty Score

แก้ไขใน `app.py`:

```python
if gambling_result['is_gambling']:
    gambling_penalty = min(60, gambling_result['gambling_score'])  # ปรับค่าที่นี่
    score -= gambling_penalty
```

### เพิ่ม Domain Patterns

แก้ไขใน `gambling_detector.py`:

```python
GAMBLING_DOMAIN_PATTERNS = [
    r'pattern.*ใหม่',  # เพิ่ม pattern ใหม่
]
```

## ⚠️ ข้อควรระวัง

1. **Performance**: การดึง HTML content อาจใช้เวลาสักครู่ ระบบจะ timeout ภายใน 5 วินาที
2. **False Positives**: บางเว็บอาจมีคำที่เกี่ยวข้องแต่ไม่ได้เป็นเว็บพนัน (เช่น news site ที่เขียนเรื่องการพนัน)
3. **Content Changes**: เว็บไซต์อาจเปลี่ยนเนื้อหาได้ตลอดเวลา

## 🚀 การพัฒนาต่อ

### แนวทางในการปรับปรุง:

1. **Machine Learning**: ใช้ ML model เพื่อให้การตรวจจับแม่นยำขึ้น
2. **Image Analysis**: วิเคราะห์รูปภาพใน banner/advertisements
3. **Behavioral Analysis**: วิเคราะห์พฤติกรรมของเว็บไซต์
4. **Database**: เก็บ blacklist ของเว็บพนันที่ยืนยันแล้ว

## 📝 License

Feature นี้เป็นส่วนหนึ่งของ FakeShop Detector project
