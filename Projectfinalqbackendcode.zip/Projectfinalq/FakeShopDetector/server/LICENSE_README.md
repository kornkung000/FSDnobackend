# 🔐 FSD Backend Server - License System

ระบบ License Key สำหรับ FSD Backend Server เพื่อความปลอดภัยและการควบคุมการใช้งาน

## 📋 ภาพรวม

Backend Server ของ FSD ต้องการ **License Key** ก่อนที่จะสามารถรันได้ เพื่อป้องกันการใช้งานโดยไม่ได้รับอนุญาต

## 🎯 License Key ของคุณ

```
716d1ef8e6c761690cd5883005417540f6aa00891f16603d35cdabe7323788fc
```

**⚠️ สำคัญ:** เก็บ License Key นี้ไว้ให้ปลอดภัย หากสูญหายจะไม่สามารถกู้คืนได้

## 🚀 วิธีรัน Backend Server

### วิธีที่ 1: ใช้ Environment Variable (แนะนำ)

```bash
# ตั้งค่า Environment Variable ก่อน
export FSD_LICENSE_KEY=716d1ef8e6c761690cd5883005417540f6aa00891f16603d35cdabe7323788fc

# รัน Server
python app.py
```

### วิธีที่ 2: ใช้ Script Runner

```bash
python run_fsd_server.py --license-key 716d1ef8e6c761690cd5883005417540f6aa00891f16603d35cdabe7323788fc
```

### วิธีที่ 3: ใช้ Batch File (Windows)

```bash
# ดับเบิลคลิกที่ไฟล์ start_server.bat
start_server.bat
```

### วิธีที่ 4: ป้อน License Key ด้วยตนเอง

```bash
python app.py
# แล้วป้อน License Key เมื่อถูกถาม
```

## 🛠️ จัดการ License

### ดูข้อมูล License ปัจจุบัน

```bash
python license.py --info
```

### สร้าง License Key ใหม่

```bash
python license.py --generate --days 365
```

### ตรวจสอบ License Key

```bash
python license.py --validate YOUR_LICENSE_KEY
```

### ปิดใช้งาน License

```bash
python license.py --deactivate
```

## 📊 รายละเอียด License

- **อายุ:** 365 วัน (จนถึง 2027-01-11)
- **สถานะ:** ใช้งานได้
- **การเข้ารหัส:** SHA-256 Hash

## 🔒 ระบบความปลอดภัย

1. **License Key** จะถูก hash ด้วย SHA-256 ก่อนเก็บ
2. Server จะตรวจสอบ License ทุกครั้งที่รัน
3. License มีวันหมดอายุ
4. สามารถปิดใช้งาน License ได้

## 🚨 การแก้ปัญหา

### ปัญหา: "License Key ไม่ถูกต้อง"

**แก้ไข:**
- ตรวจสอบ License Key ให้ถูกต้อง
- ตรวจสอบไม่มี space เพิ่มเติม
- ตรวจสอบ License ยังไม่หมดอายุ

### ปัญหา: "License หมดอายุแล้ว"

**แก้ไข:**
- สร้าง License Key ใหม่
- ติดต่อผู้พัฒนาเพื่อขอ License ใหม่

### ปัญหา: "ไม่พบข้อมูล License ในระบบ"

**แก้ไข:**
- ตรวจสอบไฟล์ `fsd_license.json` มีอยู่
- สร้าง License Key ใหม่

## 📁 ไฟล์ที่เกี่ยวข้อง

- `license.py` - จัดการระบบ License
- `app.py` - Backend Server (แก้ไขแล้วให้ใช้ License)
- `run_fsd_server.py` - Script สำหรับรัน Server
- `start_server.bat` - Batch file สำหรับ Windows
- `fsd_license.json` - ไฟล์เก็บข้อมูล License

## 🎉 สรุป

ตอนนี้ Backend Server ของคุณมีระบบความปลอดภัยแล้ว!
- ✅ ต้องมี License Key ก่อนรัน
- ✅ License มีวันหมดอายุ
- ✅ สามารถจัดการ License ได้ง่าย
- ✅ ปลอดภัยและควบคุมได้