# คำแนะนำการติดตั้ง Dependencies

## 🔧 วิธีติดตั้งที่แนะนำ

### วิธีที่ 1: ติดตั้งทีละตัว (แนะนำสำหรับ Windows)

เปิด PowerShell ในโฟลเดอร์ `FakeShopDetector/server` แล้วรันคำสั่งทีละตัว:

```powershell
# Dependencies พื้นฐาน (จำเป็น)
pip install Flask==3.0.0
pip install python-whois==0.8.0
pip install flask-cors==4.0.0
pip install requests==2.31.0
pip install beautifulsoup4==4.12.2

# Pillow (อาจมีปัญหาใน Windows บางเวอร์ชัน)
pip install Pillow

# EasyOCR (optional - ถ้าติดตั้งไม่ได้ไม่เป็นไร)
pip install easyocr
```

### วิธีที่ 2: ใช้ไฟล์ script

รันไฟล์ `install_dependencies.bat` (Windows) หรือ `install_dependencies.ps1` (PowerShell):

```powershell
# PowerShell
.\install_dependencies.ps1

# หรือ Command Prompt
install_dependencies.bat
```

### วิธีที่ 3: ติดตั้งเฉพาะที่จำเป็น (ถ้ามีปัญหา)

ถ้ามีปัญหาในการติดตั้ง Pillow หรือ EasyOCR ให้ติดตั้งแค่ที่จำเป็นก่อน:

```powershell
pip install Flask==3.0.0
pip install python-whois==0.8.0
pip install flask-cors==4.0.0
pip install requests==2.31.0
pip install beautifulsoup4==4.12.2
```

ระบบจะทำงานได้แต่จะไม่มีฟีเจอร์ OCR (การตรวจสอบรูปภาพ)

## ⚠️ แก้ไขปัญหา Pillow

ถ้าติดตั้ง Pillow ไม่ได้:

1. **อัพเกรด pip:**
   ```powershell
   python -m pip install --upgrade pip
   ```

2. **ติดตั้ง pre-built wheel:**
   ```powershell
   pip install Pillow --prefer-binary
   ```

3. **หรือติดตั้งเวอร์ชันเก่ากว่า:**
   ```powershell
   pip install Pillow==9.5.0
   ```

## ⚠️ EasyOCR เป็น Optional

EasyOCR **ไม่จำเป็น** สำหรับการทำงานพื้นฐาน:
- ระบบจะทำงานได้ปกติ แต่จะไม่มีฟีเจอร์ OCR
- ถ้าติดตั้งไม่ได้ ให้ข้ามไปก่อนได้
- สามารถติดตั้งทีหลังเมื่อต้องการใช้ OCR

## ✅ ตรวจสอบการติดตั้ง

รันคำสั่งนี้เพื่อตรวจสอบว่าติดตั้งสำเร็จหรือไม่:

```powershell
python -c "import flask; import requests; from bs4 import BeautifulSoup; print('Dependencies พื้นฐาน: OK')"
```

## 🚀 เริ่มใช้งาน

หลังจากติดตั้งเสร็จแล้ว:

```powershell
python app.py
```

ระบบจะแสดง warning ถ้า dependencies บางตัวไม่ได้ติดตั้ง แต่จะยังทำงานได้
