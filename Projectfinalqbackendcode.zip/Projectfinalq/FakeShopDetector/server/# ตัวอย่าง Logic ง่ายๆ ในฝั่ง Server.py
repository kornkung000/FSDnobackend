# ตัวอย่าง Logic ง่ายๆ ในฝั่ง Server
from flask import Flask, request, jsonify, render_template
import whois
from datetime import datetime
import os

# กำหนด path ของ template folder ให้ถูกต้อง
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, 'templates')

app = Flask(__name__, template_folder=TEMPLATE_DIR)

@app.route('/')
def index():
    """หน้าแรกสำหรับแสดงเว็บอินเทอร์เฟซ"""
    return render_template('index.html')

@app.route('/check_url', methods=['POST'])
@app.route('/fsd/api/check', methods=['POST'])
@app.route('/FSD/api/check', methods=['POST'])
def check_url():
    url = request.json.get('url')
    domain = url.replace('https://', '').replace('http://', '').split('/')[0]
    
    score = 100
    details = []

    try:
        # 1. เช็คอายุโดเมน
        domain_info = whois.whois(domain)
        creation_date = domain_info.creation_date
        
        if isinstance(creation_date, list): # บางทีมันคืนค่ามาหลายวัน
            creation_date = creation_date[0]
            
        age_days = (datetime.now() - creation_date).days
        
        if age_days < 30:
            score -= 50
            details.append(f"โดเมนใหม่มาก (อายุ {age_days} วัน)")
        elif age_days < 180:
            score -= 20
            details.append(f"โดเมนค่อนข้างใหม่ (อายุ {age_days} วัน)")
            
    except:
        score -= 10
        details.append("ไม่สามารถตรวจสอบข้อมูลโดเมนได้")

    # 2. คืนค่ากลับไปให้ Extension
    return jsonify({
        "domain": domain,
        "trust_score": score,
        "details": details,
        "verdict": "Safe" if score > 80 else "Risky"
    })

if __name__ == '__main__':
    print("=" * 50)
    print("🛡️  FakeShop Detector Server")
    print("=" * 50)
    print("🌐 เปิดเบราว์เซอร์ไปที่: http://127.0.0.1:5000")
    print("=" * 50)
    app.run(debug=True, host='127.0.0.1', port=5000)