# 🔗 คู่มือ Integration - เชื่อมต่อ Backend อื่น

## 📌 ภาพรวม

Backend นี้สามารถสร้าง **Integration URL** เพื่อเชื่อมต่อกับ backend อื่นได้ โดยแต่ละ integration จะมี:
- **Integration URL** - URL สำหรับดูข้อมูล integration
- **Webhook URL** - URL สำหรับส่งข้อมูลมาให้ backend นี้ตรวจสอบ
- **Token** - สำหรับ authentication
- **API Key** - สำหรับเรียก API อื่นๆ

---

## 🚀 วิธีสร้าง Integration

### 1. สร้าง Integration

**Endpoint:** `POST /api/integration/create`

**Request:**
```json
{
  "name": "My Backend",
  "description": "Backend สำหรับร้านค้าออนไลน์",
  "callback_url": "https://your-backend.com/webhook"
}
```

**Response:**
```json
{
  "success": true,
  "integration_url": "http://127.0.0.1:5000/api/integration/TOKEN_HERE",
  "webhook_url": "http://127.0.0.1:5000/api/webhook/TOKEN_HERE",
  "token": "TOKEN_HERE",
  "api_key": "API_KEY_HERE",
  "callback_url": "https://your-backend.com/webhook",
  "message": "Integration created successfully",
  "endpoints": {
    "check_url": "http://127.0.0.1:5000/api/check",
    "analyze_url": "http://127.0.0.1:5000/api/analyze",
    "webhook_url": "http://127.0.0.1:5000/api/webhook/TOKEN_HERE",
    "integration_info": "http://127.0.0.1:5000/api/integration/TOKEN_HERE"
  }
}
```

**ตัวอย่างการใช้ curl:**
```bash
curl -X POST http://127.0.0.1:5000/api/integration/create \
  -H "Content-Type: application/json" \
  -d '{
    "name": "My Backend",
    "callback_url": "https://my-backend.com/webhook"
  }'
```

---

## 📡 วิธีใช้งาน Webhook

### 2. ส่งข้อมูลไปยัง Webhook

**Endpoint:** `POST /api/webhook/<token>`

**Request:**
```json
{
  "url": "https://example-shop.com"
}
```

**Response:**
```json
{
  "domain": "example-shop.com",
  "url": "https://example-shop.com",
  "trust_score": 85,
  "details": [
    "✅ โดเมนมีอายุ 1825 วัน - ดูน่าเชื่อถือ",
    "✅ มี SSL Certificate (HTTPS)"
  ],
  "warnings": [],
  "verdict": "Safe",
  "timestamp": "2024-01-01T12:00:00",
  "integration_token": "TOKEN_HERE"
}
```

**ตัวอย่างการใช้ curl:**
```bash
curl -X POST http://127.0.0.1:5000/api/webhook/YOUR_TOKEN \
  -H "Content-Type: application/json" \
  -d '{"url": "https://example-shop.com"}'
```

**หมายเหตุ:** 
- ถ้ามี `callback_url` ระบบจะส่งผลลัพธ์กลับไปยัง callback URL อัตโนมัติ
- ระบบจะบันทึก usage count และ last_used timestamp

---

## 🔍 ดูข้อมูล Integration

### 3. ดูข้อมูล Integration

**Endpoint:** `GET /api/integration/<token>`

**Response:**
```json
{
  "integration": {
    "name": "My Backend",
    "description": "Backend สำหรับร้านค้าออนไลน์",
    "callback_url": "https://my-backend.com/webhook",
    "created_at": "2024-01-01T12:00:00",
    "last_used": "2024-01-01T12:30:00",
    "usage_count": 5
  },
  "endpoints": {
    "check_url": "http://127.0.0.1:5000/api/check",
    "analyze_url": "http://127.0.0.1:5000/api/analyze",
    "webhook_url": "http://127.0.0.1:5000/api/webhook/TOKEN_HERE",
    "integration_info": "http://127.0.0.1:5000/api/integration/TOKEN_HERE"
  }
}
```

---

## 📋 ดูรายการ Integrations

### 4. ดูรายการ Integrations ทั้งหมด

**Endpoint:** `GET /api/integration/list`

**Headers:**
```
X-API-Key: YOUR_API_KEY
```

**Response:**
```json
{
  "integrations": [
    {
      "name": "My Backend",
      "description": "Backend สำหรับร้านค้าออนไลน์",
      "callback_url": "https://my-backend.com/webhook",
      "created_at": "2024-01-01T12:00:00",
      "last_used": "2024-01-01T12:30:00",
      "usage_count": 5,
      "token": "TOKEN_HERE"
    }
  ],
  "count": 1
}
```

---

## 🗑️ ลบ Integration

### 5. ลบ Integration

**Endpoint:** `DELETE /api/integration/<token>`

**Response:**
```json
{
  "success": true,
  "message": "Integration deleted successfully"
}
```

---

## 💻 ตัวอย่างการใช้งานใน Backend อื่น

### Python Example:

```python
import requests

# 1. สร้าง Integration
response = requests.post('http://127.0.0.1:5000/api/integration/create', json={
    'name': 'My Backend',
    'callback_url': 'https://my-backend.com/webhook'
})
integration = response.json()
token = integration['token']
webhook_url = integration['webhook_url']

# 2. ใช้ Webhook เพื่อตรวจสอบ URL
result = requests.post(webhook_url, json={
    'url': 'https://example-shop.com'
})
check_result = result.json()
print(f"Trust Score: {check_result['trust_score']}")
print(f"Verdict: {check_result['verdict']}")
```

### JavaScript/Node.js Example:

```javascript
const axios = require('axios');

// 1. สร้าง Integration
const integrationResponse = await axios.post('http://127.0.0.1:5000/api/integration/create', {
  name: 'My Backend',
  callback_url: 'https://my-backend.com/webhook'
});
const { token, webhook_url } = integrationResponse.data;

// 2. ใช้ Webhook เพื่อตรวจสอบ URL
const checkResponse = await axios.post(webhook_url, {
  url: 'https://example-shop.com'
});
console.log(`Trust Score: ${checkResponse.data.trust_score}`);
console.log(`Verdict: ${checkResponse.data.verdict}`);
```

---

## 🔄 Flow การทำงาน

```
Backend อื่น (Your Backend)
    ↓
1. สร้าง Integration
    POST /api/integration/create
    ↓
2. ได้รับ Integration URL และ Webhook URL
    ↓
3. เมื่อต้องการตรวจสอบ URL
    POST /api/webhook/<token>
    Body: {"url": "https://example.com"}
    ↓
4. Backend นี้ตรวจสอบและส่งผลลัพธ์กลับ
    ↓
5. (ถ้ามี callback_url) ส่งผลลัพธ์ไปยัง callback URL
```

---

## 📝 ข้อมูลที่เก็บใน Integration

- `name` - ชื่อ integration
- `description` - คำอธิบาย
- `callback_url` - URL สำหรับส่งผลลัพธ์กลับ
- `api_key` - API key สำหรับ authentication
- `created_at` - วันที่สร้าง
- `last_used` - วันที่ใช้งานล่าสุด
- `usage_count` - จำนวนครั้งที่ใช้งาน

---

## ⚠️ ข้อควรระวัง

1. **Token และ API Key** - เก็บไว้เป็นความลับ
2. **Callback URL** - ต้องเป็น HTTPS (แนะนำ)
3. **Rate Limiting** - ยังไม่มี rate limiting (ควรเพิ่มใน production)
4. **Storage** - ข้อมูลเก็บในไฟล์ `integrations.json` (ควรใช้ database ใน production)

---

## 🎯 Use Cases

1. **E-commerce Platform** - ตรวจสอบร้านค้าก่อนแสดงผล
2. **Payment Gateway** - ตรวจสอบความน่าเชื่อถือก่อนรับชำระเงิน
3. **Link Shortener** - ตรวจสอบ URL ก่อน redirect
4. **Security Scanner** - เพิ่มการตรวจสอบ URL ในระบบ

---

## 📞 Troubleshooting

### Integration ไม่ทำงาน?
- ตรวจสอบว่า token ถูกต้อง
- ตรวจสอบว่า callback_url accessible (ถ้ามี)
- ดู logs ใน console

### Callback ไม่ได้รับข้อมูล?
- ตรวจสอบว่า callback_url ถูกต้อง
- ตรวจสอบว่า callback URL รองรับ POST request
- ตรวจสอบ network/firewall

---

## 🎉 พร้อมใช้งาน!

ตอนนี้คุณสามารถเชื่อมต่อ backend อื่นกับ FakeShop Detector Backend ได้แล้ว!
