# ตัวอย่าง Logic ง่ายๆ ในฝั่ง Server
from flask import Flask, request, jsonify, render_template
import whois
from datetime import datetime
import os

# กำหนด path ของ template folder ให้ถูกต้อง
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, 'templates')

app = Flask(__name__, template_folder=TEMPLATE_DIR)

@app.route('/')
def index():
    """หน้าแรกสำหรับแสดงเว็บอินเทอร์เฟซ"""
    return render_template('index.html')

@app.route('/api/analyze', methods=['POST'])
def analyze_url():
    """API endpoint สำหรับวิเคราะห์ URL ปลอดภัย"""
    try:
        data = request.get_json()
        url = data.get('url')
        
        if not url:
            return jsonify({"error": "URL is required"}), 400
        
        # ตรวจสอบ URL format
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        domain = url.replace('https://', '').replace('http://', '').split('/')[0]
        
        riskScore = 100
        details = []
        categories = []
        
        try:
            # 1. เช็คอายุโดเมน
            domain_info = whois.whois(domain)
            creation_date = domain_info.creation_date
            
            if isinstance(creation_date, list):
                creation_date = creation_date[0]
                
            age_days = (datetime.now() - creation_date).days
            
            if age_days < 30:
                riskScore -= 50
                categories.append("new_domain")
                details.append(f"โดเมนใหม่มาก (อายุ {age_days} วัน)")
            elif age_days < 180:
                riskScore -= 20
                categories.append("new_domain")
                details.append(f"โดเมนค่อนข้างใหม่ (อายุ {age_days} วัน)")
            else:
                details.append(f"โดเมนอายุ {age_days} วัน (น่าเชื่อถือ)")
                
        except Exception as e:
            riskScore -= 10
            categories.append("domain_check_failed")
            details.append(f"ไม่สามารถตรวจสอบข้อมูลโดเมนได้: {str(e)}")
        
        # คำนวณ verdict
        if riskScore >= 80:
            verdict = "safe"
        elif riskScore >= 50:
            verdict = "warn"
        else:
            verdict = "danger"
        
        return jsonify({
            "url": url,
            "domain": domain,
            "riskScore": max(0, riskScore),
            "verdict": verdict,
            "categories": categories,
            "details": details
        })
    
    except Exception as e:
        return jsonify({
            "error": f"Analysis error: {str(e)}"
        }), 500

if __name__ == '__main__':
    import sys
    import io
    # แก้ปัญหา encoding สำหรับ Windows console
    if sys.platform == 'win32':
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    
    print("=" * 50)
    print("SafeURL Checker Server")
    print("=" * 50)
    print("Server API: http://127.0.0.1:5000")
    print("API Endpoint: POST /api/analyze")
    print("=" * 50)
    print("\nการตั้งค่า Extension:")
    print("1. เปิด Extension Settings")
    print("2. ตั้ง Backend URL เป็น: http://127.0.0.1:5000")
    print("3. บันทึก Settings")
    print("=" * 50)
    app.run(debug=True, host='127.0.0.1', port=5000)
