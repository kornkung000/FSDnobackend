# สคริปต์สำหรับรัน Backend Server
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "🛡️  FSD - FakeShop Detector Backend" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# ตรวจสอบว่า Python ติดตั้งหรือไม่
Write-Host "📋 กำลังตรวจสอบ Python..." -ForegroundColor Yellow
$pythonVersion = python --version 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ ไม่พบ Python! กรุณาติดตั้ง Python ก่อน" -ForegroundColor Red
    exit 1
}
Write-Host "✅ $pythonVersion" -ForegroundColor Green
Write-Host ""

# ตรวจสอบว่า dependencies ติดตั้งหรือไม่
Write-Host "📦 กำลังตรวจสอบ dependencies..." -ForegroundColor Yellow
$flaskInstalled = python -m pip list | Select-String -Pattern "Flask"
if (-not $flaskInstalled) {
    Write-Host "⚠️  ยังไม่ได้ติดตั้ง dependencies" -ForegroundColor Yellow
    Write-Host "📥 กำลังติดตั้ง dependencies..." -ForegroundColor Yellow
    python -m pip install -r requirements.txt
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ ไม่สามารถติดตั้ง dependencies ได้" -ForegroundColor Red
        exit 1
    }
    Write-Host "✅ ติดตั้ง dependencies สำเร็จ" -ForegroundColor Green
} else {
    Write-Host "✅ Dependencies ติดตั้งครบแล้ว" -ForegroundColor Green
}
Write-Host ""

# รัน server
Write-Host "🚀 กำลังเริ่มต้น Backend Server..." -ForegroundColor Yellow
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "🌐 Web Interface: http://127.0.0.1:5000/fsd" -ForegroundColor Green
Write-Host "📡 API Endpoint: http://127.0.0.1:5000/fsd/api/check" -ForegroundColor Green
Write-Host "💚 Health Check: http://127.0.0.1:5000/fsd/health" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "💡 กด Ctrl+C เพื่อหยุด server" -ForegroundColor Yellow
Write-Host ""

# รัน Python server
python app.py
