# วิธีรัน Backend Server

## วิธีที่ 1: ใช้สคริปต์ (Windows)

เปิดโฟลเดอร์ `FakeShopDetector/server` แล้วรันอย่างใดอย่างหนึ่ง:
- PowerShell: `run-server.ps1`
- Command Prompt: `run-server.bat`

หมายเหตุ: ถ้า double-click `run-server.bat` ได้ ก็ใช้วิธีนั้นได้

## วิธีที่ 2: รันด้วยคำสั่ง Python

```powershell
cd FakeShopDetector/server
pip install -r requirements.txt
python app.py
```

---

## ตรวจสอบว่า Server รันอยู่

เมื่อรันสำเร็จ ให้ทดสอบ:

- Health check: `http://127.0.0.1:5000/fsd/health`
- Web UI: `http://127.0.0.1:5000/fsd`

ตัวอย่างผลลัพธ์จาก health:
```
{
  "status": "online",
  "service": "FSD - FakeShop Detector",
  "version": "1.0.0"
}
```

---

## แก้ไขปัญหา

### ปัญหา: Port 5000 ถูกใช้งานแล้ว

1. หา process ที่ใช้พอร์ต:
```powershell
netstat -ano | findstr :5000
taskkill /PID <PID> /F
```

2. หรือเปลี่ยนพอร์ตใน `app.py` (ตัวอย่าง 5001)

### ปัญหา: ModuleNotFoundError

```powershell
pip install -r requirements.txt
```

### ปัญหา: Python ไม่พบคำสั่ง

ตรวจสอบเวอร์ชัน:
```powershell
python --version
```

## หมายเหตุ

- Server จะทำงานจนกว่าจะกด Ctrl+C และต้องเปิดหน้าต่าง terminal ทิ้งไว้

## เอกสารเพิ่มเติม

- Backend README: `FakeShopDetector/server/README.md`
