# แก้ไข Extension ให้เรียก Backend เท่านั้น

## เป้าหมาย

ทำให้ Extension ในโฟลเดอร์ `extension/` ทำหน้าที่แค่:
- ส่ง URL ไปให้ Backend วิเคราะห์
- รับผลลัพธ์กลับมา
- แสดงผลให้ผู้ใช้

Extension ไม่ทำการวิเคราะห์เองในฝั่ง Frontend

---

## ไฟล์ที่เกี่ยวข้อง

### 1. `manifest.json`
- เพิ่ม `"options_page": "options.html"`
- ปรับ `host_permissions` ให้รองรับการเรียก Backend

### 2. `options.html` (สร้างใหม่)
- หน้าตั้งค่า Backend URL และทดสอบการเชื่อมต่อ

### 3. `options.js` (สร้างใหม่)
- จัดการบันทึก/โหลด Backend URL ใน Chrome Storage และทดสอบการเชื่อมต่อ

### 4. `popup.js`
- ตัด logic วิเคราะห์ใน frontend และเรียก Backend แทน
- ฟังก์ชันหลัก: `checkUrlWithBackend()`, `checkBackendHealth()`, `displayBackendResult()`

---

## Flow การทำงาน

### ก่อนหน้านี้ (วิเคราะห์ใน Frontend):
```
1. ผู้ใช้เปิดเว็บไซต์
2. Extension เรียก API ภายนอกหลายตัว
3. Extension คำนวณคะแนนเอง
4. แสดงผลลัพธ์
```

### ตอนนี้ (ส่งไปให้ Backend):
```
1. ผู้ใช้เปิดเว็บไซต์
2. Extension ส่ง URL ไปยัง Backend (/fsd/api/check)
3. Backend วิเคราะห์ URL และคำนวณคะแนน
4. Backend ส่งผลลัพธ์กลับ
5. Extension แสดงผลลัพธ์
```

---

## การตั้งค่า Extension

1. เปิดหน้า Extensions: `chrome://extensions/` (Chrome) หรือ `edge://extensions/` (Edge)
2. เข้าไปที่หน้า Options ของ Extension
3. ตั้งค่า Backend URL เป็น `http://127.0.0.1:5000` แล้วกดบันทึก
4. Reload Extension 1 ครั้ง

---

## การใช้งาน

### 1) รัน Backend Server
```bash
cd FakeShopDetector/server
python app.py
```

### 2) ใช้งาน Extension
- เปิดเว็บไซต์ที่ต้องการตรวจสอบ
- เปิด popup ของ Extension
- กดตรวจสอบ แล้วดูคะแนน/รายละเอียด

---

## API ที่ Extension เรียก

### Health Check:
```
GET http://127.0.0.1:5000/fsd/health
```

### ตรวจสอบ URL:
```
POST http://127.0.0.1:5000/fsd/api/check
Content-Type: application/json

{
  "url": "https://example.com"
}
```

Response จะมี `trust_score`, `verdict`, `details`, `warnings`

---

## ข้อดี/ข้อจำกัด

- ข้อดี: Frontend เบาขึ้น, แก้ logic ที่ Backend ได้ง่าย, ลดปัญหา API ภายนอกจำกัดการเรียกใช้งาน
- ข้อจำกัด: ต้องมี Backend ทำงานอยู่ และตั้งค่า Backend URL ให้ถูกต้อง

---

## แก้ปัญหาเบื้องต้น

### ปัญหา: "Backend server ไม่ได้รันอยู่"

1. รัน Backend: `python app.py`
2. เปิด `http://127.0.0.1:5000/fsd/health` เพื่อตรวจสอบ

### ปัญหา: "ไม่สามารถเชื่อมต่อกับ Backend ได้"

1. ตรวจสอบ Backend URL ใน Options
2. ตรวจสอบ Firewall/Antivirus
3. ลองใช้ `http://127.0.0.1:5000` แทน `localhost`

### ปัญหา: Extension ไม่แสดง Options

1. รีโหลด Extension ในหน้า Extensions
2. ตรวจสอบว่าไฟล์ `options.html` และ `options.js` อยู่ในโฟลเดอร์

---

## สรุป

Extension ทำหน้าที่เรียก Backend และแสดงผลเท่านั้น ทำให้โครงสร้างชัดเจนและดูแลง่าย