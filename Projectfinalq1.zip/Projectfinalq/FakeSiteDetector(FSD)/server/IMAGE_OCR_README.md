# Image OCR Detection Feature

## 📋 ภาพรวม

Feature นี้เพิ่มการตรวจสอบรูปภาพในเว็บไซต์ด้วย OCR (Optical Character Recognition) เพื่อตรวจจับข้อความที่เกี่ยวข้องกับการพนันในรูปภาพและ banner

## 🎯 Features

### การตรวจจับ:
1. **สแกนรูปภาพทั้งหมด** ในหน้าเว็บ (สูงสุด 20 รูป)
2. **OCR อ่านข้อความ** จากรูปภาพ (รองรับภาษาไทยและอังกฤษ)
3. **ตรวจสอบ Keywords สำคัญ** ในรูปภาพ:
   - `เดิมพัน`
   - `แทง`
   - `บิด`
   - `666`
   - `888`
   - `777`

### การให้คะแนน:
- ถ้าพบ **Critical Keywords** (เดิมพัน/แทง/บิด/666/888/777) ในรูปภาพ → **Gambling Score = 100** (รับประกันว่าเป็นเว็บพนัน)
- ถ้าพบรูปภาพที่มีข้อความการพนัน → เพิ่มคะแนน 40-50 คะแนน

## 📦 Dependencies

เพิ่ม dependencies ใหม่:
```
easyocr==1.7.0
Pillow==10.1.0
beautifulsoup4==4.12.2
```

ติดตั้งด้วย:
```bash
pip install -r requirements.txt
```

**หมายเหตุ**: EasyOCR จะดาวน์โหลดโมเดลภาษาไทยและอังกฤษครั้งแรกที่รัน (ประมาณ 200-300 MB)

## 🔧 วิธีการทำงาน

### 1. Extract Image URLs
- ดึง URL ของรูปภาพทั้งหมดจาก HTML
- รองรับ `<img src="">`, `background-image`, และ lazy loading

### 2. Download Images
- ดาวน์โหลดรูปภาพจาก URL
- ตรวจสอบ content-type ว่าเป็นรูปภาพจริงๆ
- Timeout 3 วินาทีต่อรูป

### 3. OCR Processing
- ใช้ EasyOCR อ่านข้อความจากรูปภาพ
- รองรับภาษาไทยและอังกฤษ

### 4. Keyword Detection
- ตรวจสอบว่ามี keywords ที่เกี่ยวข้องกับการพนันหรือไม่
- หากพบ critical keywords → ให้คะแนนเต็ม

## 📊 Scoring System

```python
# ถ้าพบ Critical Keywords (เดิมพัน/แทง/บิด/666/888/777)
Gambling Score = 100  # รับประกันว่าเป็นเว็บพนัน

# ถ้าพบรูปภาพที่มีข้อความการพนัน
Gambling Score += 40 + (จำนวนรูป * 10)  # สูงสุด 50 คะแนน
```

## ⚠️ Performance Considerations

1. **Processing Time**: การ OCR รูปภาพอาจใช้เวลานาน (1-3 วินาทีต่อรูป)
2. **Memory Usage**: EasyOCR ใช้หน่วยความจำมาก (แนะนำ RAM ≥ 4GB)
3. **Network**: ต้องดาวน์โหลดรูปภาพจาก URL

## 🔍 ตัวอย่างผลลัพธ์

```json
{
  "gambling_score": 100,
  "is_gambling": true,
  "details": [
    "❌ พบรูปภาพที่มีข้อความการพนัน 3 รูป (ตรวจสอบ 15 รูป)",
    "⚠️ พบคำสำคัญในรูปภาพ: เดิมพัน, แทง, 666",
    "❌ พบข้อความสำคัญในรูปภาพ (เดิมพัน/แทง/บิด/666/888/777) - รับประกันว่าเป็นเว็บพนัน"
  ]
}
```

## 🛠️ การปรับแต่ง

### เพิ่ม Keywords สำคัญ

แก้ไข `IMAGE_GAMBLING_KEYWORDS` ใน `gambling_detector.py`:

```python
IMAGE_GAMBLING_KEYWORDS = [
    'เดิมพัน',
    'แทง',
    'บิด',
    '666',
    '888',
    '777',
    # เพิ่มคำใหม่ที่นี่
    'คำใหม่',
]
```

### ปรับจำนวนรูปที่ตรวจสอบ

แก้ไขใน `extract_image_urls()`:

```python
return image_urls[:20]  # เปลี่ยนเป็นจำนวนที่ต้องการ
```

## 🐛 Troubleshooting

### EasyOCR ไม่ทำงาน
- ตรวจสอบว่าได้ติดตั้ง `easyocr` แล้ว
- ตรวจสอบว่าโมเดลภาษาได้ถูกดาวน์โหลดแล้ว (ครั้งแรกจะดาวน์โหลดอัตโนมัติ)

### OCR ช้าเกินไป
- ลดจำนวนรูปที่ตรวจสอบ
- ใช้ GPU (ถ้ามี): `reader = easyocr.Reader(['th', 'en'], gpu=True)`

### Memory Error
- ลดจำนวนรูปที่ตรวจสอบ
- เพิ่ม RAM หรือใช้ cloud service ที่มี RAM เพียงพอ

## 📝 License

Feature นี้เป็นส่วนหนึ่งของ FakeShop Detector project
