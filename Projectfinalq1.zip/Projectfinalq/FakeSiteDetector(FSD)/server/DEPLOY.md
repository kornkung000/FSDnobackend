# 🚀 คู่มือ Deploy Backend เป็น Online

## 📌 ภาพรวม

คู่มือนี้จะสอนวิธี deploy FakeShop Detector Backend ให้สามารถเข้าถึงได้จากอินเทอร์เน็ต

---

## 🌐 วิธีที่ 1: Deploy บน Railway (แนะนำ - ฟรี)

### ขั้นตอน:

1. **สร้าง Account:**
   - ไปที่ https://railway.app
   - สร้าง account ด้วย GitHub

2. **Deploy:**
   - คลิก "New Project"
   - เลือก "Deploy from GitHub repo"
   - เลือก repository ของคุณ
   - Railway จะ detect Dockerfile อัตโนมัติ

3. **ตั้งค่า Environment Variables:**
   ```
   PORT=5000
   HOST=0.0.0.0
   DEBUG=False
   ```

4. **เสร็จ!** Railway จะให้ URL เช่น: `https://your-app.railway.app`

---

## 🌐 วิธีที่ 2: Deploy บน Render (ฟรี)

### ขั้นตอน:

1. **สร้าง Account:**
   - ไปที่ https://render.com
   - สร้าง account

2. **Deploy:**
   - คลิก "New +" → "Web Service"
   - เชื่อมต่อ GitHub repository
   - ตั้งค่า:
     - **Build Command:** `pip install -r requirements.txt`
     - **Start Command:** `python app.py`
     - **Environment:** Python 3

3. **ตั้งค่า Environment Variables:**
   ```
   PORT=5000
   HOST=0.0.0.0
   DEBUG=False
   ```

4. **เสร็จ!** Render จะให้ URL เช่น: `https://your-app.onrender.com`

---

## 🌐 วิธีที่ 3: Deploy บน Heroku

### ขั้นตอน:

1. **ติดตั้ง Heroku CLI:**
   ```bash
   # Windows
   winget install Heroku.HerokuCLI
   
   # หรือดาวน์โหลดจาก https://devcenter.heroku.com/articles/heroku-cli
   ```

2. **Login:**
   ```bash
   heroku login
   ```

3. **สร้าง App:**
   ```bash
   cd server
   heroku create your-app-name
   ```

4. **Deploy:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git push heroku main
   ```

5. **ตั้งค่า Environment Variables:**
   ```bash
   heroku config:set PORT=5000
   heroku config:set HOST=0.0.0.0
   heroku config:set DEBUG=False
   ```

6. **เสร็จ!** Heroku จะให้ URL เช่น: `https://your-app-name.herokuapp.com`

---

## 🌐 วิธีที่ 4: Deploy ด้วย Docker

### ขั้นตอน:

1. **Build Docker Image:**
   ```bash
   cd server
   docker build -t fakeshop-detector .
   ```

2. **Run Container:**
   ```bash
   docker run -d -p 5000:5000 \
     -e PORT=5000 \
     -e HOST=0.0.0.0 \
     -e DEBUG=False \
     fakeshop-detector
   ```

3. **Deploy ไปยัง Cloud:**
   - **Docker Hub:** Push image ไป Docker Hub แล้ว deploy
   - **AWS ECS:** ใช้ AWS Elastic Container Service
   - **Google Cloud Run:** Deploy container ไป Cloud Run
   - **Azure Container Instances:** Deploy ไป Azure

---

## 🌐 วิธีที่ 5: Deploy บน VPS (Virtual Private Server)

### ขั้นตอน:

1. **เช่า VPS:**
   - DigitalOcean, Linode, Vultr, หรือ AWS EC2

2. **ติดตั้ง Dependencies:**
   ```bash
   # บน Ubuntu/Debian
   sudo apt update
   sudo apt install python3 python3-pip nginx
   ```

3. **Clone และ Setup:**
   ```bash
   git clone your-repo
   cd server
   pip3 install -r requirements.txt
   ```

4. **ใช้ systemd สำหรับรัน service:**
   สร้างไฟล์ `/etc/systemd/system/fakeshop-detector.service`:
   ```ini
   [Unit]
   Description=FakeShop Detector Backend
   After=network.target

   [Service]
   User=www-data
   WorkingDirectory=/path/to/server
   Environment="PORT=5000"
   Environment="HOST=0.0.0.0"
   Environment="DEBUG=False"
   ExecStart=/usr/bin/python3 app.py
   Restart=always

   [Install]
   WantedBy=multi-user.target
   ```

5. **Start Service:**
   ```bash
   sudo systemctl enable fakeshop-detector
   sudo systemctl start fakeshop-detector
   ```

6. **ตั้งค่า Nginx (Reverse Proxy):**
   สร้างไฟล์ `/etc/nginx/sites-available/fakeshop-detector`:
   ```nginx
   server {
       listen 80;
       server_name your-domain.com;

       location / {
           proxy_pass http://127.0.0.1:5000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
       }
   }
   ```

7. **Enable Site:**
   ```bash
   sudo ln -s /etc/nginx/sites-available/fakeshop-detector /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl restart nginx
   ```

---

## 🔒 ตั้งค่า HTTPS (SSL Certificate)

### ใช้ Let's Encrypt (ฟรี):

```bash
# ติดตั้ง Certbot
sudo apt install certbot python3-certbot-nginx

# สร้าง SSL Certificate
sudo certbot --nginx -d your-domain.com

# Auto-renewal
sudo certbot renew --dry-run
```

---

## 📝 Environment Variables

ตั้งค่า environment variables ตาม platform:

### Railway/Render:
```
PORT=5000
HOST=0.0.0.0
DEBUG=False
```

### Heroku:
```bash
heroku config:set PORT=5000 HOST=0.0.0.0 DEBUG=False
```

### Docker:
```bash
docker run -e PORT=5000 -e HOST=0.0.0.0 -e DEBUG=False ...
```

---

## ✅ Checklist หลัง Deploy

- [ ] Backend ทำงานได้ (ตรวจสอบ `/health`)
- [ ] API endpoints ทำงาน (`/api/check`)
- [ ] Integration endpoints ทำงาน (`/api/integration/create`)
- [ ] Webhook ทำงาน (`/api/webhook/<token>`)
- [ ] HTTPS ตั้งค่าแล้ว (ถ้าใช้ domain)
- [ ] CORS ทำงานถูกต้อง
- [ ] Error handling ทำงาน

---

## 🧪 ทดสอบหลัง Deploy

```bash
# Health Check
curl https://your-app.com/health

# Test API
curl -X POST https://your-app.com/api/check \
  -H "Content-Type: application/json" \
  -d '{"url": "https://example.com"}'

# Test Integration
curl -X POST https://your-app.com/api/integration/create \
  -H "Content-Type: application/json" \
  -d '{"name": "Test"}'
```

---

## 🔧 Troubleshooting

### Backend ไม่ทำงาน?
- ตรวจสอบ logs ใน platform
- ตรวจสอบ environment variables
- ตรวจสอบ port และ host settings

### CORS Error?
- ตรวจสอบว่า `flask-cors` ติดตั้งแล้ว
- ตรวจสอบ CORS settings ใน code

### Database/Storage Issues?
- ตรวจสอบว่า `integrations.json` มี permissions
- ใช้ external storage (S3, etc.) สำหรับ production

---

## 📚 Resources

- **Railway:** https://railway.app
- **Render:** https://render.com
- **Heroku:** https://heroku.com
- **Docker:** https://docker.com
- **Let's Encrypt:** https://letsencrypt.org

---

## 🎉 เสร็จแล้ว!

ตอนนี้ backend ของคุณสามารถเข้าถึงได้จากอินเทอร์เน็ตแล้ว!
