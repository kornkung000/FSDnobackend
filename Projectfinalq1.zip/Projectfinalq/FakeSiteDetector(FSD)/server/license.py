"""
FSD - License Management System
ระบบจัดการ License Key สำหรับ FSD Backend Server
"""
import hashlib
import os
import json
import secrets
from datetime import datetime, timedelta
import argparse
import getpass

class FSDLicenseManager:
    """จัดการระบบ License Key สำหรับ FSD Backend Server"""

    def __init__(self, license_file="fsd_license.json"):
        self.license_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), license_file)
        self.license_data = self._load_license()

    def _load_license(self):
        """โหลดข้อมูล license จากไฟล์"""
        if os.path.exists(self.license_file):
            try:
                with open(self.license_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}

    def _save_license(self):
        """บันทึกข้อมูล license ลงไฟล์"""
        try:
            with open(self.license_file, 'w', encoding='utf-8') as f:
                json.dump(self.license_data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"[ERROR] Error saving license: {e}")

    def generate_license_key(self, validity_days=365):
        """สร้าง license key ใหม่"""
        # สร้าง key แบบสุ่ม
        raw_key = secrets.token_hex(32)

        # Hash key เพื่อเก็บในระบบ
        hashed_key = hashlib.sha256(raw_key.encode()).hexdigest()

        # กำหนดวันหมดอายุ
        expiry_date = datetime.now() + timedelta(days=validity_days)

        license_info = {
            'key_hash': hashed_key,
            'created_at': datetime.now().isoformat(),
            'expires_at': expiry_date.isoformat(),
            'is_active': True,
            'validity_days': validity_days
        }

        # บันทึก license
        self.license_data['current_license'] = license_info
        self._save_license()

        return raw_key, license_info

    def validate_license(self, provided_key):
        """ตรวจสอบ license key"""
        if not provided_key:
            return False, "[ERROR] License Key not found"

        # Hash key ที่ผู้ใช้ใส่
        provided_hash = hashlib.sha256(provided_key.encode()).hexdigest()

        # ตรวจสอบกับ license ที่เก็บไว้
        current_license = self.license_data.get('current_license', {})

        if not current_license:
            return False, "[ERROR] No license data found in system"

        stored_hash = current_license.get('key_hash')
        expires_at = current_license.get('expires_at')
        is_active = current_license.get('is_active', False)

        # ตรวจสอบ hash
        if provided_hash != stored_hash:
            return False, "[ERROR] Invalid License Key"

        # ตรวจสอบสถานะ
        if not is_active:
            return False, "[ERROR] License is deactivated"

        # ตรวจสอบวันหมดอายุ
        if expires_at:
            expiry_date = datetime.fromisoformat(expires_at)
            if datetime.now() > expiry_date:
                return False, "[ERROR] License has expired"

        return True, "[OK] License Key is valid"

    def get_license_info(self):
        """ดูข้อมูล license ปัจจุบัน"""
        current_license = self.license_data.get('current_license', {})
        if not current_license:
            return "[ERROR] No license data found"

        info = []
        info.append("[INFO] License Information:")
        info.append(f"  Created: {current_license.get('created_at', 'N/A')}")
        info.append(f"  Expires: {current_license.get('expires_at', 'N/A')}")
        info.append(f"  Status: {'[OK] Active' if current_license.get('is_active', False) else '[DISABLED] Deactivated'}")
        info.append(f"  Validity: {current_license.get('validity_days', 0)} days")

        return "\n".join(info)

    def deactivate_license(self):
        """ปิดใช้งาน license"""
        if 'current_license' in self.license_data:
            self.license_data['current_license']['is_active'] = False
            self._save_license()
            return "[OK] License deactivated successfully"
        return "[ERROR] No license found to deactivate"

def main():
    """ฟังก์ชันหลักสำหรับจัดการ license ผ่าน command line"""
    parser = argparse.ArgumentParser(description='FSD License Manager')
    parser.add_argument('--generate', action='store_true', help='สร้าง License Key ใหม่')
    parser.add_argument('--validate', type=str, help='ตรวจสอบ License Key')
    parser.add_argument('--info', action='store_true', help='ดูข้อมูล License ปัจจุบัน')
    parser.add_argument('--deactivate', action='store_true', help='ปิดใช้งาน License')
    parser.add_argument('--days', type=int, default=365, help='จำนวนวันที่ License จะใช้งานได้ (สำหรับ --generate)')

    args = parser.parse_args()

    manager = FSDLicenseManager()

    if args.generate:
        print("[+] Generating new License Key...")
        key, info = manager.generate_license_key(args.days)
        print("[OK] License Key created successfully!")
        print(f"[KEY] License Key: {key}")
        print(f"[INFO] Validity: {args.days} days")
        print(f"[INFO] Expires: {info['expires_at']}")
        print("\n[WARNING] Keep this License Key secure!")
        print("          If lost, it cannot be recovered")

    elif args.validate:
        print(f"🔍 กำลังตรวจสอบ License Key: {args.validate[:10]}...")
        is_valid, message = manager.validate_license(args.validate)
        print(message)

    elif args.info:
        print(manager.get_license_info())

    elif args.deactivate:
        print(manager.deactivate_license())

    else:
        print("[FSD] FSD License Manager")
        print("=" * 40)
        print("คำสั่งที่ใช้ได้:")
        print("  --generate          สร้าง License Key ใหม่")
        print("  --validate <key>    ตรวจสอบ License Key")
        print("  --info              ดูข้อมูล License ปัจจุบัน")
        print("  --deactivate        ปิดใช้งาน License")
        print("\nตัวอย่าง:")
        print("  python license.py --generate --days 30")
        print("  python license.py --validate YOUR_KEY_HERE")
        print("  python license.py --info")

def prompt_license_key():
    """ฟังก์ชันสำหรับถาม License Key จากผู้ใช้"""
    print("\n[FSD] FSD Backend Server - License Required")
    print("=" * 50)
    print("Please enter License Key to start Backend Server")
    print("(Contact developer if you don't have License Key)")
    print("=" * 50)

    # ถาม License Key
    while True:
        try:
            license_key = getpass.getpass("[INPUT] License Key: ").strip()
            if not license_key:
                print("[ERROR] Please enter License Key")
                continue
            return license_key
        except KeyboardInterrupt:
            print("\n\n[EXIT] Operation cancelled")
            exit(1)
        except Exception as e:
            print(f"[ERROR] Error occurred: {e}")
            continue

if __name__ == '__main__':
    main()