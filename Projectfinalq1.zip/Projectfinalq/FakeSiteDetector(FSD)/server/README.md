# 🛡️ FakeShop Detector - Backend Server

Backend สำหรับตรวจสอบความน่าเชื่อถือของร้านค้าออนไลน์

## 📁 ไฟล์ Backend

### ไฟล์หลัก:
- **`app.py`** - Main backend server (แนะนำให้ใช้)
- **`server.py`** - Backend แบบเดิม (compatible)
- **`# ตัวอย่าง Logic ง่ายๆ ในฝั่ง Server.py`** - Backend แบบง่าย
- **`update_server.py`** - Server สำหรับ auto-update extension

## 🚀 วิธีรัน Backend

### 1. ติดตั้ง Dependencies
```bash
cd server
pip install -r requirements.txt
```

### 2. รัน Server
```bash
# วิธีที่ 1: ใช้ app.py (แนะนำ)
python app.py

# วิธีที่ 2: ใช้ server.py
python server.py

# วิธีที่ 3: ใช้ไฟล์เดิม
python "# ตัวอย่าง Logic ง่ายๆ ในฝั่ง Server.py"
```

### 3. เปิดเบราว์เซอร์
- Web Interface: http://127.0.0.1:5000
- API Endpoint: http://127.0.0.1:5000/api/check
- Health Check: http://127.0.0.1:5000/health

## 📡 API Endpoints

### 1. GET `/` - หน้าเว็บ
แสดงเว็บอินเทอร์เฟซสำหรับตรวจสอบ URL

### 2. POST `/api/check` - ตรวจสอบ URL
**Request:**
```json
{
  "url": "https://example.com"
}
```

**Response:**
```json
{
  "domain": "example.com",
  "url": "https://example.com",
  "trust_score": 100,
  "details": [
    "✅ โดเมนมีอายุ 1825 วัน - ดูน่าเชื่อถือ",
    "✅ มี SSL Certificate (HTTPS)"
  ],
  "warnings": [],
  "verdict": "Safe",
  "timestamp": "2024-01-01T12:00:00"
}
```

### 3. POST `/api/analyze` - วิเคราะห์ URL (Legacy)
**Request:**
```json
{
  "url": "https://example.com"
}
```

**Response:**
```json
{
  "url": "https://example.com",
  "domain": "example.com",
  "riskScore": 100,
  "verdict": "safe",
  "categories": [],
  "details": ["โดเมนอายุ 1825 วัน (น่าเชื่อถือ)"]
}
```

### 4. GET `/health` - Health Check
**Response:**
```json
{
  "status": "online",
  "service": "FakeShop Detector Backend",
  "version": "1.0.0",
  "timestamp": "2024-01-01T12:00:00"
}
```

## 🔍 ฟีเจอร์การตรวจสอบ

1. **ตรวจสอบอายุโดเมน**
   - โดเมนใหม่มาก (< 30 วัน): -50 คะแนน
   - โดเมนค่อนข้างใหม่ (< 180 วัน): -20 คะแนน
   - โดเมนเก่า (> 180 วัน): +0 คะแนน (ดี)

2. **ตรวจสอบรูปแบบโดเมน**
   - โดเมนยาวผิดปกติ (> 30 ตัวอักษร): -10 คะแนน
   - โดเมนสั้นผิดปกติ (< 5 ตัวอักษร): -5 คะแนน
   - มีตัวเลขมากผิดปกติ: -15 คะแนน
   - รูปแบบน่าสงสัย: -10 คะแนน

3. **ตรวจสอบ SSL**
   - มี SSL (HTTPS): +0 คะแนน (ดี)
   - ไม่มี SSL (HTTP): -30 คะแนน

## 📊 คะแนนความน่าเชื่อถือ

- **80-100**: Safe ✅
- **50-79**: Risky ⚠️
- **0-49**: Danger ❌

## 🛠️ Development

### โครงสร้าง:
```
server/
├── app.py                          # Main backend (แนะนำ)
├── server.py                       # Backend แบบเดิม
├── update_server.py                # Update server
├── requirements.txt                # Dependencies
└── templates/
    └── index.html                  # Web interface
```

### Testing API:
```bash
# ใช้ curl
curl -X POST http://127.0.0.1:5000/api/check \
  -H "Content-Type: application/json" \
  -d '{"url": "https://example.com"}'

# ใช้ Python
import requests
response = requests.post('http://127.0.0.1:5000/api/check', 
                        json={'url': 'https://example.com'})
print(response.json())
```

## ⚠️ หมายเหตุ

- Backend ต้องรันอยู่เพื่อให้ extension ใช้งานได้ (ถ้าใช้ backend)
- Extension แบบ online ไม่ต้องใช้ backend
- ต้องติดตั้ง `python-whois` สำหรับตรวจสอบอายุโดเมน
