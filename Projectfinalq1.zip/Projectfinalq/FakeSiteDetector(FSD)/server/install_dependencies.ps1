# PowerShell script สำหรับติดตั้ง dependencies
# สำหรับ Windows

Write-Host "กำลังติดตั้ง dependencies..." -ForegroundColor Green

# ติดตั้ง dependencies พื้นฐานก่อน (ที่จำเป็น)
Write-Host "`n1. ติดตั้ง Flask..." -ForegroundColor Yellow
pip install Flask==3.0.0

Write-Host "`n2. ติดตั้ง python-whois..." -ForegroundColor Yellow
pip install python-whois==0.8.0

Write-Host "`n3. ติดตั้ง flask-cors..." -ForegroundColor Yellow
pip install flask-cors==4.0.0

Write-Host "`n4. ติดตั้ง requests..." -ForegroundColor Yellow
pip install requests==2.31.0

Write-Host "`n5. ติดตั้ง beautifulsoup4..." -ForegroundColor Yellow
pip install beautifulsoup4==4.12.2

# ติดตั้ง Pillow (อาจจะมีปัญหาใน Windows บางเวอร์ชัน)
Write-Host "`n6. ติดตั้ง Pillow..." -ForegroundColor Yellow
pip install Pillow

# EasyOCR เป็น optional (ถ้าติดตั้งไม่ได้ก็ไม่เป็นไร)
Write-Host "`n7. ติดตั้ง easyocr (optional, อาจใช้เวลานาน)..." -ForegroundColor Yellow
pip install easyocr

Write-Host "`nเสร็จสิ้น!" -ForegroundColor Green
Write-Host "`nหมายเหตุ: EasyOCR จะดาวน์โหลดโมเดลภาษาไทยและอังกฤษครั้งแรกที่รัน (ประมาณ 200-300 MB)" -ForegroundColor Cyan
