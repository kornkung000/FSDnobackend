document.addEventListener('DOMContentLoaded', () => {
  const backendUrlInput = document.getElementById('backendUrl');
  const apiKeyInput = document.getElementById('apiKey');
  const languageSelect = document.getElementById('languageSelect');
  const saveBtn = document.getElementById('saveBtn');
  const status = document.getElementById('status');

  let currentLanguage = 'th'; // Default language

  // Load values from storage
  chrome.storage.sync.get(['backendBaseUrl', 'apiKey', 'language'], (items) => {
    if (items.backendBaseUrl) {
      backendUrlInput.value = items.backendBaseUrl;
    }
    if (items.apiKey) {
      apiKeyInput.value = items.apiKey;
    }
    if (items.language) {
      currentLanguage = items.language;
      languageSelect.value = items.language;
    }

    // Update UI language
    updateUILanguage(currentLanguage);
  });

  // Handle language change
  languageSelect.addEventListener('change', () => {
    currentLanguage = languageSelect.value;
    updateUILanguage(currentLanguage);
  });

  saveBtn.addEventListener('click', () => {
    const backendBaseUrl = backendUrlInput.value.trim();
    const apiKey = apiKeyInput.value.trim() || null;
    const language = languageSelect.value;

    if (!backendBaseUrl) {
      status.textContent = getText('saveError', currentLanguage);
      status.style.color = '#d9534f';
      return;
    }

    chrome.storage.sync.set({
      backendBaseUrl,
      apiKey,
      language
    }, () => {
      status.textContent = getText('saveSuccess', currentLanguage);
      status.style.color = '#5cb85c';
      setTimeout(() => {
        status.textContent = '';
      }, 2000);
    });
  });

  function updateUILanguage(lang) {
    // Update static text elements
    document.querySelector('h2').textContent = getText('optionsTitle', lang);
    document.querySelectorAll('label')[0].textContent = getText('backendUrlLabel', lang);
    document.querySelectorAll('label')[1].textContent = getText('apiKeyLabel', lang);
    document.querySelectorAll('label')[2].textContent = getText('languageLabel', lang);

    backendUrlInput.placeholder = getText('backendUrlPlaceholder', lang);
    apiKeyInput.placeholder = getText('apiKeyPlaceholder', lang);
    saveBtn.textContent = getText('saveButton', lang);

    // Update instructions
    const infoDiv = document.querySelector('.info');
    infoDiv.innerHTML = `
      <strong>${getText('instructionsTitle', lang)}</strong><br>
      ${getText('instruction1', lang)}<br>
      ${getText('instruction2', lang)}
    `;
  }
});
