// ดึง URL หน้าปัจจุบัน
chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    let currentUrl = tabs[0].url;
    
    // ส่งไปหา Server เรา (สมมติรันบน localhost)
    fetch('http://localhost:5000/fsd/api/check', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({url: currentUrl})
    })
    .then(response => response.json())
    .then(data => {
        // เอากลับมาโชว์บนหน้าจอ
        document.getElementById('score').innerText = data.trust_score + "%";
        document.getElementById('details').innerText = data.details.join(', ');
        
        // เปลี่ยนสีตัวอักษรตามคะแนน
        if(data.trust_score < 50) {
            document.body.style.backgroundColor = "#ffe6e6"; // สีแดงอ่อน
        }
    });
});
