# 🔄 คู่มือ Auto-Update Extension แบบง่าย

## 🎯 เป้าหมาย
ทำให้ extension อัพเดทอัตโนมัติ โดยผู้ใช้โหลดครั้งเดียว หลังจากนั้นจะอัพเดทเอง

---

## 📋 วิธีที่ 1: ใช้ GitHub Releases (แนะนำ - ฟรี)

### ขั้นตอน:

#### 1. เตรียม Extension
```bash
# ไปที่โฟลเดอร์ extension
cd extension

# Pack extension (Windows)
pack-extension.bat

# หรือ (Linux/Mac)
chmod +x pack-extension.sh
./pack-extension.sh
```

#### 2. สร้าง GitHub Repository
1. ไปที่ https://github.com/new
2. สร้าง repository ใหม่ (เช่น `fakeshop-detector`)
3. Push code ขึ้น GitHub

#### 3. สร้าง Release
1. ไปที่ repository → **Releases** → **Create a new release**
2. Tag: `v1.0.0`
3. Title: `Version 1.0.0`
4. อัพโหลดไฟล์ `.zip` หรือ `.crx`
5. **Publish release**

#### 4. ตั้งค่า updates.xml
แก้ไข `extension/updates.xml`:
```xml
<?xml version='1.0' encoding='UTF-8'?>
<gupdate xmlns='http://www.google.com/update2/response' protocol='2.0'>
  <app appid='YOUR_EXTENSION_ID'>
    <updatecheck 
      codebase='https://github.com/YOUR_USERNAME/fakeshop-detector/releases/download/v1.0.1/fakeshop-detector-v1.0.1.crx' 
      version='1.0.1' 
    />
  </app>
</gupdate>
```

#### 5. Host updates.xml
- ใช้ GitHub Pages หรือ
- ใช้ raw.githubusercontent.com:
  ```
  https://raw.githubusercontent.com/YOUR_USERNAME/fakeshop-detector/main/extension/updates.xml
  ```

#### 6. อัพเดท manifest.json
```json
{
  "update_url": "https://raw.githubusercontent.com/YOUR_USERNAME/fakeshop-detector/main/extension/updates.xml"
}
```

---

## 📋 วิธีที่ 2: ใช้ Chrome Web Store (แนะนำสำหรับ Production)

### ขั้นตอน:

#### 1. สร้าง Developer Account
- ไปที่ https://chrome.google.com/webstore/devconsole
- สร้าง account (ครั้งแรก $5)

#### 2. อัพโหลด Extension
1. คลิก **"New Item"**
2. อัพโหลดไฟล์ `.zip` ของ extension
3. กรอกข้อมูล:
   - Name: FakeShop Detector
   - Description: ตรวจสอบความน่าเชื่อถือของร้านค้าออนไลน์
   - Category: Productivity
   - Screenshots
4. **Submit for Review**

#### 3. หลังจากผ่าน Review
- Extension จะมี update URL อัตโนมัติ
- ผู้ใช้ติดตั้งจาก Chrome Web Store
- อัพเดทอัตโนมัติทุกครั้งที่คุณ publish เวอร์ชันใหม่

---

## 📋 วิธีที่ 3: Self-Hosted (สำหรับ Advanced)

### ขั้นตอน:

#### 1. Pack Extension
1. เปิด `chrome://extensions/`
2. เปิด **Developer mode**
3. คลิก **"Pack extension"**
4. เลือกโฟลเดอร์ `extension`
5. คลิก **"Pack Extension"**
6. จะได้ไฟล์ `.crx` และ `.pem`

#### 2. เก็บ Extension ID
- จาก `chrome://extensions/` คัดลอก **Extension ID**

#### 3. อัพเดท updates.xml
```xml
<?xml version='1.0' encoding='UTF-8'?>
<gupdate xmlns='http://www.google.com/update2/response' protocol='2.0'>
  <app appid='YOUR_EXTENSION_ID_HERE'>
    <updatecheck 
      codebase='https://your-domain.com/extension/fakeshop-detector-v1.0.1.crx' 
      version='1.0.1' 
    />
  </app>
</gupdate>
```

#### 4. อัพโหลดไฟล์
- อัพโหลด `.crx` ไปยัง web server
- อัพโหลด `updates.xml` ไปยัง web server
- ตั้งค่า HTTPS (จำเป็น!)

#### 5. อัพเดท manifest.json
```json
{
  "update_url": "https://your-domain.com/extension/updates.xml"
}
```

---

## 🔄 วิธีอัพเดท Extension

### เมื่อต้องการอัพเดท:

1. **อัพเดท version ใน manifest.json:**
   ```json
   {
     "version": "1.0.1"
   }
   ```

2. **Pack extension ใหม่:**
   - ใช้ `pack-extension.bat` หรือ
   - Pack จาก Chrome

3. **อัพโหลด .crx ใหม่:**
   - อัพโหลดไปยัง server หรือ GitHub Releases

4. **อัพเดท updates.xml:**
   ```xml
   <updatecheck 
     codebase='https://.../fakeshop-detector-v1.0.1.crx' 
     version='1.0.1' 
   />
   ```

5. **อัพโหลด updates.xml:**
   - อัพโหลดไฟล์ `updates.xml` ที่อัพเดทแล้ว

6. **เสร็จ!** Extension จะอัพเดทอัตโนมัติภายใน 5-6 ชั่วโมง

---

## ✅ Checklist

### ก่อนอัพเดท:
- [ ] อัพเดท version ใน `manifest.json`
- [ ] ทดสอบ extension ว่าทำงานถูกต้อง
- [ ] Pack extension เป็น `.crx` หรือ `.zip`
- [ ] อัพเดท `updates.xml`
- [ ] อัพโหลดไฟล์ไปยัง server

### หลังอัพเดท:
- [ ] ตรวจสอบว่า `updates.xml` accessible
- [ ] ทดสอบการอัพเดท (รอ 5-6 ชั่วโมง หรือกด "Update extensions now")
- [ ] ตรวจสอบว่า extension ทำงานถูกต้อง

---

## 🧪 ทดสอบ Auto-Update

### วิธีทดสอบ:

1. **ติดตั้ง Extension เวอร์ชันเก่า:**
   - ติดตั้ง extension เวอร์ชัน 1.0.0

2. **อัพเดท updates.xml:**
   - เปลี่ยนเวอร์ชันเป็น 1.0.1
   - อัพโหลด `.crx` เวอร์ชันใหม่

3. **บังคับให้ Chrome ตรวจสอบอัพเดท:**
   - ไปที่ `chrome://extensions/`
   - เปิด Developer mode
   - คลิก **"Update extensions now"**

4. **ตรวจสอบ:**
   - Extension ควรอัพเดทเป็นเวอร์ชัน 1.0.1

---

## ⚠️ ข้อควรระวัง

1. **Extension ID ต้องเหมือนกัน:**
   - ถ้าเปลี่ยน key Extension ID จะเปลี่ยน
   - ต้องใช้ key เดิมทุกครั้ง

2. **HTTPS เท่านั้น:**
   - Update URL ต้องใช้ HTTPS
   - HTTP ไม่ทำงาน

3. **Version Format:**
   - ใช้ `MAJOR.MINOR.PATCH`
   - เช่น: `1.0.0`, `1.0.1`, `1.1.0`

4. **Update Frequency:**
   - Chrome ตรวจสอบทุก 5-6 ชั่วโมง
   - หรือเมื่อเปิด browser ใหม่

---

## 📞 Troubleshooting

### Extension ไม่อัพเดท?

1. **ตรวจสอบ updates.xml:**
   - เปิด URL ใน browser ดูว่า accessible
   - ตรวจสอบว่า version ใหม่กว่า

2. **ตรวจสอบ Extension ID:**
   - ต้องตรงกับ ID ใน updates.xml

3. **ตรวจสอบ .crx file:**
   - ต้อง accessible และ download ได้

4. **ตรวจสอบ HTTPS:**
   - ต้องใช้ HTTPS เท่านั้น

---

## 🎉 เสร็จแล้ว!

หลังจากตั้งค่าแล้ว:
- ✅ Extension จะอัพเดทอัตโนมัติ
- ✅ ไม่ต้องโหลดใหม่ทุกครั้ง
- ✅ ผู้ใช้จะได้เวอร์ชันล่าสุดเสมอ

**แนะนำ:** ใช้ **GitHub Releases** สำหรับเริ่มต้น (ฟรีและง่าย)
