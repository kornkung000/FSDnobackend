// Internationalization (i18n) data
const translations = {
    th: {
        pageTitle: "⚙️ ตั้งค่า Fake Site Detector(FSD)",
        languageLabel: "ภาษา (Language):",
        backendLabel: "Backend Server URL:",
        saveBtnText: "บันทึก",
        usageTitle: "ℹ️ วิธีใช้งาน",
        usageStep1: "รัน Backend Server ก่อนด้วยคำสั่ง: <code>python app.py</code>",
        usageStep2: "ตั้งค่า URL ของ Backend Server ในช่องด้านบน",
        usageStep3: "Extension จะส่ง URL ไปให้ Backend วิเคราะห์",
        usageStep4: "แสดงผลลัพธ์ที่ได้จาก Backend",
        saveSuccess: "✅ บันทึกตั้งค่าสำเร็จ!",
        urlRequired: "⚠️ กรุณากรอก Backend URL",
        urlInvalid: "⚠️ URL ไม่ถูกต้อง",
        testSuccess: "✅ เชื่อมต่อ Backend สำเร็จ!",
        testFail: "⚠️ ไม่สามารถเชื่อมต่อ Backend ได้",
        testTimeout: "⚠️ Backend ไม่ตอบสนอง (Timeout)"
    },
    en: {
        pageTitle: "⚙️ Fake Site Detector(FSD) Settings",
        languageLabel: "Language:",
        backendLabel: "Backend Server URL:",
        saveBtnText: "Save",
        usageTitle: "ℹ️ How to Use",
        usageStep1: "Run Backend Server first with command: <code>python app.py</code>",
        usageStep2: "Set Backend Server URL in the field above",
        usageStep3: "Extension will send URL to Backend for analysis",
        usageStep4: "Display results from Backend",
        saveSuccess: "✅ Settings saved successfully!",
        urlRequired: "⚠️ Please enter Backend URL",
        urlInvalid: "⚠️ Invalid URL format",
        testSuccess: "✅ Backend connection successful!",
        testFail: "⚠️ Cannot connect to Backend",
        testTimeout: "⚠️ Backend not responding (Timeout)"
    }
};

let currentLanguage = 'th';

document.addEventListener('DOMContentLoaded', () => {
    const backendUrlInput = document.getElementById('backendUrl');
    const languageSelect = document.getElementById('languageSelect');
    const saveBtn = document.getElementById('saveBtn');
    const status = document.getElementById('status');

    // โหลดค่าจาก storage
    chrome.storage.sync.get(['backendUrl', 'language'], (items) => {
        if (items.language) {
            currentLanguage = items.language;
            languageSelect.value = currentLanguage;
        }

        if (items.backendUrl) {
            backendUrlInput.value = items.backendUrl;
        } else {
            // ค่า default
            backendUrlInput.value = 'http://127.0.0.1:5000';
        }

        // อัปเดท UI ตามภาษาที่เลือก
        updateLanguage(currentLanguage);
    });

    // เมื่อเปลี่ยนภาษา
    languageSelect.addEventListener('change', () => {
        currentLanguage = languageSelect.value;
        updateLanguage(currentLanguage);

        // บันทึกภาษาที่เลือก
        chrome.storage.sync.set({ language: currentLanguage });
    });

    saveBtn.addEventListener('click', () => {
        const backendUrl = backendUrlInput.value.trim();

        if (!backendUrl) {
            showStatus(translations[currentLanguage].urlRequired, 'error');
            return;
        }

        // ตรวจสอบรูปแบบ URL
        try {
            new URL(backendUrl);
        } catch (e) {
            showStatus(translations[currentLanguage].urlInvalid, 'error');
            return;
        }

        // บันทึกค่า
        chrome.storage.sync.set({
            backendUrl: backendUrl,
            language: currentLanguage
        }, () => {
            showStatus(translations[currentLanguage].saveSuccess, 'success');

            // ทดสอบการเชื่อมต่อ
            testBackendConnection(backendUrl);
        });
    });

    function showStatus(message, type) {
        status.textContent = message;
        status.className = `status ${type}`;
        status.style.display = 'block';

        if (type === 'success') {
            setTimeout(() => {
                status.style.display = 'none';
            }, 3000);
        }
    }

// ฟังก์ชันอัปเดทภาษาใน UI
function updateLanguage(lang) {
    const t = translations[lang];

    document.getElementById('pageTitle').textContent = t.pageTitle;
    document.getElementById('languageLabel').textContent = t.languageLabel;
    document.getElementById('backendLabel').textContent = t.backendLabel;
    document.getElementById('saveBtn').textContent = t.saveBtnText;
    document.getElementById('usageTitle').textContent = t.usageTitle;

    const usageList = document.getElementById('usageList');
    usageList.innerHTML = `
        <li>${t.usageStep1}</li>
        <li>${t.usageStep2}</li>
        <li>${t.usageStep3}</li>
        <li>${t.usageStep4}</li>
    `;
}

async function testBackendConnection(url) {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);

        const response = await fetch(url + '/health', {
            method: 'GET',
            signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (response.ok) {
            showStatus(translations[currentLanguage].testSuccess, 'success');
        } else {
            showStatus(translations[currentLanguage].testFail, 'error');
        }
    } catch (e) {
        if (e.name === 'AbortError') {
            showStatus(translations[currentLanguage].testTimeout, 'error');
        } else {
            showStatus(translations[currentLanguage].testFail, 'error');
        }
    }
}
});